# [CRITICAL] Unauthenticated Control Server — Arbitrary Script Execution and Configuration Modification

## Ringkasan (impact nyata)
The ghostferry control server (`control_server.go`) exposes HTTP endpoints for pausing, unpausing, cutover, verification, custom script execution, and configuration modification **without any authentication**. An attacker who can reach the control server can execute arbitrary OS commands via the `/api/script` endpoint, modify the migration configuration via `/api/config`, and disrupt database migrations — potentially causing data loss, data corruption, or complete migration failure.

## Deskripsi / Root Cause
In `control_server.go`, the `ControlServer.Initialize()` method registers HTTP routes without any authentication middleware:

```go
// control_server.go — Initialize()
func (this *ControlServer) Initialize() (err error) {
  // ...
  this.router = mux.NewRouter()
  this.router.HandleFunc("/", this.HandleIndex).Methods("GET")
  this.router.HandleFunc("/api/status", this.HandleStatus).Headers("Content-Type", "application/json").Methods("GET")
  this.router.HandleFunc("/api/pause", this.HandlePause).Methods("POST")
  this.router.HandleFunc("/api/unpause", this.HandleUnpause).Methods("POST")
  this.router.HandleFunc("/api/cutover", this.HandleCutover).Methods("POST")
  this.router.HandleFunc("/api/stop", this.HandleStop).Methods("POST")
  this.router.HandleFunc("/api/verify", this.HandleVerify).Methods("POST")
  this.router.HandleFunc("/api/script", this.HandleScript).Methods("POST")
  this.router.HandleFunc("/api/config", this.HandleConfigGet).Methods("GET")
  this.router.HandleFunc("/api/config", this.HandleConfigPost).Methods("POST")
  // ...
}
```

None of these routes have authentication, authorization, or IP restriction middleware. The server binds to `this.Config.ServerBindAddr` and listens for incoming connections.

### Critical Endpoints

#### 1. `/api/script` — Arbitrary Script Execution (CRITICAL)
```go
func (this *ControlServer) HandleScript(w http.ResponseWriter, r *http.Request) {
  // ...
  name, err := scriptName(r)
  // ...
  cmd, found := this.Config.CustomScripts[name]
  if !found {
    http.NotFound(w, r)
    return
  }
  this.startScriptInBackground(name, cmd)
  returnSuccess(w, r)
}
```

The `startScriptInBackground` function executes arbitrary OS commands:
```go
func (this *ControlServer) startScriptInBackground(scriptName string, scriptCmd []string) {
  // ...
  go func() {
    cmd := exec.Command(scriptCmd[0], scriptCmd[1:]...)
    // ...
    stdoutStderr, err := cmd.CombinedOutput()
    // ...
  }()
}
```

If `CustomScripts` is configured, an attacker can execute any registered custom script. Even if `CustomScripts` is nil, the endpoint still exists and returns 404, but the configuration endpoint can be used to modify the config.

#### 2. `/api/config` (POST) — Configuration Modification (CRITICAL)
```go
func (this *ControlServer) HandleConfigPost(w http.ResponseWriter, r *http.Request) {
  var decoder = json.NewDecoder(r.Body)
  decoder.DisallowUnknownFields()
  var updatableConfig UpdatableConfig
  err := decoder.Decode(&updatableConfig)
  // ...
  this.F.Config.Update(updatableConfig)
  returnSuccess(w, r)
}
```

An attacker can modify the ferry configuration, potentially changing source/target database connections, batch sizes, or other critical parameters.

#### 3. `/api/pause` / `/api/unpause` — Migration Disruption (HIGH)
```go
func (this *ControlServer) HandlePause(w http.ResponseWriter, r *http.Request) {
  this.F.Throttler.SetPaused(true)
  returnSuccess(w, r)
}

func (this *ControlServer) HandleUnpause(w http.ResponseWriter, r *http.Request) {
  this.F.Throttler.SetPaused(false)
  returnSuccess(w, r)
}
```

An attacker can pause and unpause the migration at will, causing inconsistent data states.

#### 4. `/api/cutover` — Premature Cutover (HIGH)
```go
func (this *ControlServer) HandleCutover(w http.ResponseWriter, r *http.Request) {
  cutover, err := cutoverType(r)
  // ...
  if cutover == "automatic" {
    this.F.AutomaticCutover = true
  } else if cutover == "manual" {
    this.F.AutomaticCutover = false
  }
  // ...
}
```

An attacker can trigger a premature cutover, potentially causing data loss if the migration is not complete.

#### 5. `/api/verify` — Verification Control (MEDIUM)
```go
func (this *ControlServer) HandleVerify(w http.ResponseWriter, r *http.Request) {
  if this.Verifier == nil {
    w.WriteHeader(http.StatusNotImplemented)
    return
  }
  err := this.Verifier.StartInBackground()
  // ...
}
```

An attacker can start or interfere with the verification process.

### Key Issues
1. **No authentication**: All endpoints are accessible without any credentials.
2. **No authorization**: No check that the requester has permission to perform these actions.
3. **No IP restriction**: The server binds to a configurable address but has no built-in IP allowlisting.
4. **No TLS**: The control server uses plain HTTP, making all traffic visible to network attackers.
5. **No rate limiting**: No protection against brute-force or automated attacks.
6. **Arbitrary command execution**: The `/api/script` endpoint can execute arbitrary OS commands if custom scripts are configured.
7. **Configuration modification**: The `/api/config` POST endpoint allows modifying the ferry configuration.

## Steps to Reproduce

### Step 1: Identify the control server
The control server is typically accessible on the configured `ServerBindAddr` (default may be `localhost:8080` or similar).

### Step 2: Check if custom scripts are configured
```bash
curl -s "https://<ghostferry-host>/api/config"
```

### Step 3: Execute a custom script (if configured)
```bash
curl -X POST "https://<ghostferry-host>/api/script" \
  -H "Content-Type: application/json" \
  -d '{"script-name": "my-custom-script"}'
```

### Step 4: Modify configuration
```bash
curl -X POST "https://<ghostferry-host>/api/config" \
  -H "Content-Type: application/json" \
  -d '{"batch_size": 1, "max_parallelism": 1}'
```

### Step 5: Pause the migration
```bash
curl -X POST "https://<ghostferry-host>/api/pause"
```

### Step 6: Trigger premature cutover
```bash
curl -X POST "https://<ghostferry-host>/api/cutover" \
  -H "Content-Type: application/json" \
  -d '{"type": "automatic"}'
```

## PoC / Bukti

### Source Code Evidence
**File**: `control_server.go` — `Initialize()` method

```go
func (this *ControlServer) Initialize() (err error) {
  this.logger = LogWithField("tag", "control_server")
  this.logger.Info("initializing")
  this.wg = &sync.WaitGroup{}

  this.customScriptsRunning = make(map[string]bool)
  this.customScriptsLogs = make(map[string]string)
  this.customScriptsStatus = make(map[string]string)
  this.customScriptsExitCode = make(map[string]int)

  this.router = mux.NewRouter()
  this.router.HandleFunc("/", this.HandleIndex).Methods("GET")
  this.router.HandleFunc("/api/status", this.HandleStatus).Headers("Content-Type", "application/json").Methods("GET")
  this.router.HandleFunc("/api/pause", this.HandlePause).Methods("POST")
  this.router.HandleFunc("/api/unpause", this.HandleUnpause).Methods("POST")
  this.router.HandleFunc("/api/cutover", this.HandleCutover).Methods("POST")
  this.router.HandleFunc("/api/stop", this.HandleStop).Methods("POST")
  this.router.HandleFunc("/api/verify", this.HandleVerify).Methods("POST")
  this.router.HandleFunc("/api/script", this.HandleScript).Methods("POST")
  this.router.HandleFunc("/api/config", this.HandleConfigGet).Methods("GET")
  this.router.HandleFunc("/api/config", this.HandleConfigPost).Methods("POST")
  // NO AUTHENTICATION MIDDLEWARE!
}
```

**File**: `control_server.go` — `HandleScript()` and `startScriptInBackground()`

```go
func (this *ControlServer) HandleScript(w http.ResponseWriter, r *http.Request) {
  if this.Config.CustomScripts == nil {
    http.NotFound(w, r)
    return
  }
  name, err := scriptName(r)
  // ...
  cmd, found := this.Config.CustomScripts[name]
  if !found {
    http.NotFound(w, r)
    return
  }
  this.startScriptInBackground(name, cmd)
  returnSuccess(w, r)
}

func (this *ControlServer) startScriptInBackground(scriptName string, scriptCmd []string) {
  // ...
  go func() {
    cmd := exec.Command(scriptCmd[0], scriptCmd[1:]...)  // <-- ARBITRARY COMMAND EXECUTION
    // ...
    stdoutStderr, err := cmd.CombinedOutput()
    // ...
  }()
}
```

**File**: `control_server.go` — `HandleConfigPost()`

```go
func (this *ControlServer) HandleConfigPost(w http.ResponseWriter, r *http.Request) {
  var decoder = json.NewDecoder(r.Body)
  decoder.DisallowUnknownFields()
  var updatableConfig UpdatableConfig
  err := decoder.Decode(&updatableConfig)
  // ...
  this.F.Config.Update(updatableConfig)  // <-- CONFIGURATION MODIFICATION
  returnSuccess(w, r)
}
```

**File**: `control_server.go` — `HandlePause()` and `HandleCutover()`

```go
func (this *ControlServer) HandlePause(w http.ResponseWriter, r *http.Request) {
  this.F.Throttler.SetPaused(true)  // <-- PAUSE MIGRATION
  returnSuccess(w, r)
}

func (this *ControlServer) HandleCutover(w http.ResponseWriter, r *http.Request) {
  cutover, err := cutoverType(r)
  // ...
  if cutover == "automatic" {
    this.F.AutomaticCutover = true  // <-- TRIGGER CUTOVER
  }
  // ...
}
```

### Configuration Evidence
**File**: `config.go` (referenced in tree)

The `ControlServerConfig` struct includes `ServerBindAddr` which determines where the server listens. There is no authentication configuration in the control server config.

## Impact (user data / finansial / reputasi — konkret)
- **Arbitrary code execution**: If custom scripts are configured, an attacker can execute arbitrary OS commands on the migration server, potentially leading to full server compromise.
- **Data loss**: An attacker can trigger a premature cutover, causing data to be lost if the migration is not complete.
- **Data corruption**: An attacker can modify the configuration to change source/target database connections, potentially causing data to be written to the wrong database.
- **Service disruption**: An attacker can pause/unpause the migration at will, causing inconsistent data states and service disruption.
- **Migration failure**: An attacker can stop or disrupt the migration process, causing it to fail and requiring manual recovery.
- **Information disclosure**: The `/api/status` endpoint exposes internal migration details including source/target host:port, table statuses, and progress information.

## Remediation
1. **Add authentication**: Require authentication (e.g., HTTP Basic Auth, bearer token, or mTLS) on all control server endpoints.
2. **Add authorization**: Verify that the requester has permission to perform these actions.
3. **Add IP allowlisting**: Restrict access to the control server to trusted IPs or internal networks.
4. **Enable TLS**: Use HTTPS for the control server to prevent network-level eavesdropping.
5. **Add rate limiting**: Implement rate limiting to prevent brute-force attacks.
6. **Remove or restrict script execution**: If custom scripts are not needed, remove the `/api/script` endpoint. If needed, require additional authentication for script execution.
7. **Audit logging**: Log all control server actions with requester identity for audit purposes.
8. **Bind to localhost**: By default, bind the control server to `localhost` or `127.0.0.1` to prevent external access.

## CVSS 3.1
**Vector**: `CVSS:3.1/AV:N/AC:L/PR:N/UI:N/S:C/C:H/I:H/A:H`
**Score**: 10.0 (Critical)

Rationale: Network exploitable, low complexity, no privileges required, no user interaction. Scope is changed because the vulnerability affects resources beyond the vulnerable component (database servers, migration data). Confidentiality, integrity, and availability impacts are all high.

## Referensi
- **CWE-306**: Missing Authentication for Critical Function
- **CWE-862**: Missing Authorization
- **CWE-78**: Improper Neutralization of Special Elements used in an OS Command ('OS Command Injection')
- **File**: `control_server.go` — `Initialize()`, `HandleScript()`, `startScriptInBackground()`, `HandleConfigPost()`, `HandlePause()`, `HandleCutover()`
- **OWASP**: https://owasp.org/www-community/attacks/Command_Injection
