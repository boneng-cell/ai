# [HIGH] PKCE Bypass — Token Exchange Proceeds Without code_verifier

## Ringkasan (impact nyata)
The OAuth 2.0 PKCE (Proof Key for Code Exchange) implementation in `shop-chat-agent` has a critical flaw: when the `code_verifier` is not found in the database, the token exchange **still proceeds without the `code_verifier` parameter**. This completely defeats the purpose of PKCE, allowing an attacker who intercepts the authorization code to exchange it for an access token without possessing the original code verifier. This can lead to customer account takeover.

## Deskripsi / Root Cause
In `app/routes/auth.callback.jsx`, the `exchangeCodeForToken()` function retrieves the code verifier from the database and includes it in the token exchange request **only if it exists**:

```javascript
// app/routes/auth.callback.jsx — exchangeCodeForToken()
let codeVerifier = "";
try {
  const verifierRecord = await getCodeVerifier(state);
  if (verifierRecord) {
    codeVerifier = verifierRecord.verifier;
  } else {
    console.warn("Code verifier not found for state:", state);
    // Proceed anyway, since we might be using an older flow without PKCE
  }
} catch (error) {
  console.error("Error retrieving code verifier:", error);
  // Proceed anyway and attempt the token exchange
}

const requestBody = {
  grant_type: "authorization_code",
  client_id: clientId,
  code: code,
  redirect_uri: redirectUri
};

// Add code_verifier if we have it
if (codeVerifier) {
  requestBody.code_verifier = codeVerifier;
}
```

The comments reveal the root cause: the developers intentionally allow the token exchange to proceed without PKCE verification, citing "backward compatibility" with an "older flow without PKCE." However, this creates a critical security vulnerability:

1. **PKCE is optional**: If the code verifier is missing from the DB (due to expiration, deletion, or race condition), the token exchange succeeds without PKCE.
2. **No enforcement**: The server does not reject requests that lack a `code_verifier` — it simply omits it from the request.
3. **Code verifier is single-use**: The `getCodeVerifier()` function deletes the verifier after retrieval, meaning any retry or race condition will result in a missing verifier.

### PKCE Flow Analysis
The PKCE flow in this application works as follows:

1. **Authorization request** (`app/auth.server.js` — `generateAuthUrl()`):
   - Generates a `code_verifier` and `code_challenge`
   - Stores the `code_verifier` in the database with a 10-minute expiry
   - Sends the `code_challenge` to Shopify's authorization endpoint

2. **Callback** (`app/routes/auth.callback.jsx`):
   - Receives the authorization `code` and `state`
   - Looks up the `code_verifier` from the database using `state`
   - **If not found**: proceeds without `code_verifier` (VULNERABILITY)
   - Exchanges `code` + `code_verifier` (if available) for an access token

### Attack Scenario
An attacker who intercepts the authorization code (e.g., via a compromised redirect URI, log exposure, or network interception) can exchange it for an access token **without** the code verifier, because the server does not enforce PKCE verification.

## Steps to Reproduce

### Step 1: Initiate OAuth flow
The victim initiates the customer OAuth flow, which generates a `code_verifier` and stores it in the database.

### Step 2: Intercept the authorization code
The attacker intercepts the authorization code from the redirect URL (e.g., via a compromised redirect URI, log exposure, or network interception).

### Step 3: Delete or wait for code verifier expiration
The code verifier has a 10-minute expiry. The attacker can either:
- Wait for the verifier to expire (10 minutes)
- Delete the verifier from the database (if they have DB access)
- Trigger a race condition by requesting the callback twice

### Step 4: Exchange code without code_verifier
The attacker sends a POST request to the token endpoint **without** the `code_verifier`:

```bash
curl -X POST "https://<token-url>" \
  -H "Content-Type: application/x-www-form-urlencoded" \
  -d "grant_type=authorization_code" \
  -d "client_id=<client-id>" \
  -d "code=<intercepted-code>" \
  -d "redirect_uri=<redirect-uri>"
```

### Step 5: Receive access token
The server accepts the request and returns an access token, even though PKCE was not verified.

### Alternative: Direct callback manipulation
The attacker can also directly call the callback endpoint with a crafted `state` parameter that doesn't match any stored code verifier:

```bash
curl -X GET "https://<shop-chat-agent-host>/auth/callback?code=<intercepted-code>&state=<arbitrary-state>"
```

The server will log a warning ("Code verifier not found for state") but **still proceed** with the token exchange.

## PoC / Bukti

### Source Code Evidence
**File**: `app/routes/auth.callback.jsx` — `exchangeCodeForToken()` function

```javascript
// Get the code verifier that corresponds to this authorization request from database
let codeVerifier = "";
try {
  const verifierRecord = await getCodeVerifier(state);
  if (verifierRecord) {
    codeVerifier = verifierRecord.verifier;
  } else {
    console.warn("Code verifier not found for state:", state);
    // Proceed anyway, since we might be using an older flow without PKCE
  }
} catch (error) {
  console.error("Error retrieving code verifier:", error);
  // Proceed anyway and attempt the token exchange
}

const requestBody = {
  grant_type: "authorization_code",
  client_id: clientId,
  code: code,
  redirect_uri: redirectUri
};

// Add code_verifier if we have it
if (codeVerifier) {
  requestBody.code_verifier = codeVerifier;
}
```

**File**: `app/db.server.js` — `getCodeVerifier()` function

```javascript
export async function getCodeVerifier(state) {
  try {
    const verifier = await prisma.codeVerifier.findFirst({
      where: {
        state,
        expiresAt: {
          gt: new Date()
        }
      }
    });

    if (verifier) {
      // Delete it after retrieval to prevent reuse
      await prisma.codeVerifier.delete({
        where: { id: verifier.id }
      });
    }

    return verifier;
  } catch (error) {
    console.error('Error retrieving code verifier:', error);
    return null;
  }
}
```

**File**: `app/auth.server.js` — `generateAuthUrl()` function

```javascript
// Store the code verifier in the database
try {
  await storeCodeVerifier(state, verifier);
} catch (error) {
  console.error('Failed to store code verifier:', error);
}
```

### Database Schema Evidence
**File**: `prisma/schema.prisma`

```prisma
model CodeVerifier {
  id              String    @id
  state           String    @unique
  verifier        String
  createdAt       DateTime  @default(now())
  expiresAt       DateTime

  @@index([state])
}
```

The code verifier has a 10-minute expiry (set in `storeCodeVerifier()` in `db.server.js`), making it easy for an attacker to wait for expiration and then exchange the code without PKCE.

## Impact (user data / finansial / reputasi — konkret)
- **Account takeover**: An attacker who intercepts an authorization code can exchange it for a customer access token without the PKCE verifier, gaining access to the victim's customer account.
- **Token theft**: The stolen access token grants access to customer data (orders, payment methods, personal information) via the Customer Account API.
- **Bypass of security control**: PKCE is specifically designed to prevent authorization code interception attacks. By making it optional, the application removes this protection.
- **Race condition exploitation**: The single-use nature of the code verifier (deleted after retrieval) creates a race condition where concurrent requests can cause the verifier to be missing.

## Remediation
1. **Enforce PKCE**: Always require and verify the `code_verifier` during token exchange. If the verifier is not found, **reject** the request with an error.
2. **Remove fallback logic**: Delete the "proceed anyway" code paths in `exchangeCodeForToken()`.
3. **Validate state parameter**: Ensure the `state` parameter matches the one used during authorization, and reject mismatches.
4. **Use constant-time comparison**: When comparing the code verifier, use a constant-time comparison to prevent timing attacks.

## CVSS 3.1
**Vector**: `CVSS:3.1/AV:N/AC:H/PR:N/UI:N/S:U/C:H/I:H/A:N`
**Score**: 7.5 (High)

Rationale: Network exploitable, high complexity (requires code interception), no privileges required, no user interaction. Confidentiality and integrity impacts are high (customer account access). The complexity is rated high because the attacker needs to intercept the authorization code first.

## Referensi
- **CWE-346**: Origin Validation Error
- **CWE-287**: Improper Authentication
- **CWE-639**: Authorization Bypass Through User-Controlled Key
- **RFC 7636**: Proof Key for Code Exchange by OAuth Public Clients
- **File**: `app/routes/auth.callback.jsx` — `exchangeCodeForToken()` function
- **File**: `app/db.server.js` — `getCodeVerifier()` and `storeCodeVerifier()` functions
- **File**: `app/auth.server.js` — `generateAuthUrl()` function
