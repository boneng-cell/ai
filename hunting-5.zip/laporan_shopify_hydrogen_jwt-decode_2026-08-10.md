# [MEDIUM] JWT Decoded Without Signature Verification in Hydrogen Customer Account Auth

## Ringkasan (impact nyata)
The `decodeJwt()` function in `packages/hydrogen/src/customer/auth.helpers.ts` decodes JWT tokens **without verifying the signature**. This function is used to extract the `nonce` from the `id_token` during the Customer Account API OAuth flow. While the nonce comparison provides some protection, the lack of JWT signature verification means an attacker who can obtain or forge a JWT can bypass nonce validation and potentially manipulate the OAuth flow.

## Deskripsi / Root Cause
In `packages/hydrogen/src/customer/auth.helpers.ts`, the `decodeJwt()` function decodes a JWT by splitting it into parts and parsing the header and payload as base64-encoded JSON, **without verifying the cryptographic signature**:

```typescript
// packages/hydrogen/src/customer/auth.helpers.ts
function decodeJwt(token: string) {
  const [header, payload, signature] = token.split('.');

  const decodedHeader = JSON.parse(atob(header));
  const decodedPayload = JSON.parse(atob(payload));

  return {
    header: decodedHeader,
    payload: decodedPayload,
    signature,
  };
}
```

This function is called by `getNonce()`:

```typescript
export function getNonce(token: string) {
  return decodeJwt(token).payload.nonce;
}
```

And `getNonce()` is used in the `authorize()` function to validate the nonce from the `id_token`:

```typescript
const sessionNonce = session.get(CUSTOMER_ACCOUNT_SESSION_KEY)?.nonce;
const responseNonce = await getNonce(id_token);

if (sessionNonce !== responseNonce) {
  throw new BadRequest(
    'Unauthorized',
    `Returned nonce does not match: ${sessionNonce} !== ${responseNonce}`,
  );
}
```

### Key Issues
1. **No signature verification**: The JWT is decoded without verifying the signature, meaning any JWT can be forged.
2. **Nonce extraction from unverified JWT**: The nonce is extracted from an unverified JWT and compared against the session nonce. If an attacker can obtain the nonce (e.g., by stealing the session cookie), they can forge a JWT with the correct nonce.
3. **No algorithm validation**: The JWT header is parsed without checking the algorithm, making the code vulnerable to algorithm confusion attacks if the JWT were ever used for authentication.
4. **Base64 decoding without error handling**: The `atob()` function can throw if the input is malformed, potentially causing unhandled errors.

### Why This Matters
While the nonce check provides some protection (the attacker needs to know the nonce to forge a valid JWT), the lack of signature verification is still a security concern:

1. **Nonce leakage**: If the session cookie is stolen (e.g., via the missing `secure` flag vulnerability), the attacker can extract the nonce and forge a JWT.
2. **JWT manipulation**: An attacker can modify the JWT payload (e.g., change the `iss`, `sub`, or `aud` claims) without invalidating the signature, because the signature is never checked.
3. **Defense in depth**: Even if the nonce check is the primary defense, signature verification should be used as a secondary defense.

## Steps to Reproduce

### Step 1: Obtain a valid nonce from the session
If the session cookie is stolen (e.g., via the missing `secure` flag), the attacker can extract the nonce from the session data.

### Step 2: Forge a JWT with the correct nonce
```javascript
// Forge a JWT with the correct nonce
const header = btoa(JSON.stringify({ alg: 'none', typ: 'JWT' }));
const payload = btoa(JSON.stringify({
  nonce: '<stolen-nonce>',
  iss: 'https://shopify.com',
  sub: 'customer-123',
  aud: '<client-id>',
  exp: Math.floor(Date.now() / 1000) + 3600,
}));
const signature = '';
const forgedJwt = `${header}.${payload}.${signature}`;
```

### Step 3: Use the forged JWT in the OAuth callback
The attacker can use the forged JWT as the `id_token` in the OAuth callback. The `getNonce()` function will extract the nonce from the forged JWT and compare it against the session nonce. If they match, the OAuth flow will proceed.

## PoC / Bukti

### Source Code Evidence
**File**: `packages/hydrogen/src/customer/auth.helpers.ts`

```typescript
export function getNonce(token: string) {
  return decodeJwt(token).payload.nonce;
}

function decodeJwt(token: string) {
  const [header, payload, signature] = token.split('.');

  const decodedHeader = JSON.parse(atob(header));
  const decodedPayload = JSON.parse(atob(payload));

  return {
    header: decodedHeader,
    payload: decodedPayload,
    signature,
  };
}
```

### Usage Evidence
**File**: `packages/hydrogen/src/customer/customer.ts` — `authorize()` function

```typescript
const sessionNonce = session.get(CUSTOMER_ACCOUNT_SESSION_KEY)?.nonce;
const responseNonce = await getNonce(id_token);

if (sessionNonce !== responseNonce) {
  throw new BadRequest(
    'Unauthorized',
    `Returned nonce does not match: ${sessionNonce} !== ${responseNonce}`,
  );
}
```

The `id_token` is obtained from the OAuth callback response and is not verified before the nonce is extracted.

## Impact (user data / finansial / reputasi — konkret)
- **OAuth flow bypass**: An attacker who can obtain the nonce (e.g., via session cookie theft) can forge a JWT and bypass the nonce validation in the OAuth flow.
- **Token manipulation**: An attacker can modify the JWT payload without invalidating the signature, potentially changing claims like `iss`, `sub`, or `aud`.
- **Combined with cookie vulnerability**: If combined with the missing `secure` flag on the session cookie, an attacker can steal the session, extract the nonce, and forge a JWT to complete the OAuth flow.

## Remediation
1. **Verify JWT signature**: Use a proper JWT library (e.g., `jose`, `jsonwebtoken`) to verify the JWT signature before extracting any claims.
2. **Validate JWT claims**: Check the `iss`, `aud`, `exp`, and `nonce` claims against expected values.
3. **Use constant-time comparison**: When comparing the nonce, use a constant-time comparison to prevent timing attacks.
4. **Handle errors gracefully**: Add error handling for malformed JWTs to prevent unhandled exceptions.

## CVSS 3.1
**Vector**: `CVSS:3.1/AV:N/AC:H/PR:N/UI:N/S:U/C:L/I:L/A:N`
**Score**: 4.2 (Medium)

Rationale: Network exploitable, high complexity (requires nonce theft), no privileges required, no user interaction. Confidentiality and integrity impacts are low (nonce bypass, JWT manipulation). The complexity is rated high because the attacker needs to obtain the nonce first.

## Referensi
- **CWE-347**: Improper Verification of Cryptographic Signature
- **CWE-345**: Insufficient Verification of Data Authenticity
- **CWE-287**: Improper Authentication
- **File**: `packages/hydrogen/src/customer/auth.helpers.ts` — `decodeJwt()` and `getNonce()` functions
- **File**: `packages/hydrogen/src/customer/customer.ts` — `authorize()` function
- **RFC 7519**: JSON Web Token (JWT)
