# API Request Log - Technical Reconnaissance

**Date**: $(date -u +"%Y-%m-%d %H:%M:%S UTC")
**Target Repos**: shop-chat-agent, subscriptions-reference-app, hydrogen

---

## GitHub API Requests (api.github.com)

| # | Request | Repo | HTTP Status | Timestamp |
|---|--------|------|------------|-----------|
| 1 | GET /repos/Shopify/shop-chat-agent/git/trees/main?recursive=1 | shop-chat-agent | 200 | 2026-08-10 |
| 2 | GET /repos/Shopify/subscriptions-reference-app/git/trees/main?recursive=1 | subscriptions-reference-app | 200 | 2026-08-10 |
| 3 | GET /repos/Shopify/hydrogen/git/trees/main?recursive=1 | hydrogen | 200 | 2026-08-10 |
| 4 | GET /repos/Shopify/shop-chat-agent/git/trees/master?recursive=1 | shop-chat-agent | (not needed, main succeeded) | - |

Note: All three repos use `main` as default branch. No fallback to `master` needed.

---

## Raw Content Requests (raw.githubusercontent.com)

### shop-chat-agent (main branch)
| # | File | Status |
|---|------|--------|
| 1 | README.md | 200 OK |
| 2 | package.json | 200 OK |
| 3 | .env.example | 200 OK |
| 4 | shopify.app.toml | 200 OK |
| 5 | shopify.web.toml | 200 OK |
| 6 | app/entry.server.jsx | 200 OK |
| 7 | app/routes.js | 200 OK |
| 8 | app/shopify.server.js | 200 OK |
| 9 | app/db.server.js | 200 OK |
| 10 | app/auth.server.js | 200 OK |
| 11 | app/mcp-client.js | 200 OK |
| 12 | app/services/claude.server.js | 200 OK |
| 13 | app/services/config.server.js | 200 OK |
| 14 | app/services/streaming.server.js | 200 OK |
| 15 | app/services/tool.server.js | 200 OK |
| 16 | app/routes/chat.jsx | 200 OK |
| 17 | app/routes/api.webhooks.jsx | 200 OK |
| 18 | app/routes/auth.$.jsx | 200 OK |
| 19 | app/routes/auth.callback.jsx | 200 OK |
| 20 | app/routes/auth.token-status.jsx | 200 OK |
| 21 | app/routes/_index/route.jsx | 200 OK |
| 22 | app/root.jsx | 200 OK |
| 23 | app/prompts/prompts.json | 200 OK |
| 24 | Dockerfile | 200 OK |
| 25 | vite.config.js | 200 OK |
| 26 | prisma/schema.prisma | 200 OK |

### subscriptions-reference-app (main branch)
| # | File | Status |
|---|------|--------|
| 1 | README.md | 200 OK |
| 2 | package.json | 200 OK |
| 3 | shopify.app.toml | 200 OK |
| 4 | shopify.web.toml | 200 OK |
| 5 | app/shopify.server.ts | 200 OK |
| 6 | app/routes.ts | 200 OK |
| 7 | app/db.server.ts | 200 OK |
| 8 | config/index.ts | 200 OK |
| 9 | config/types.ts | 200 OK |
| 10 | app/services/AfterAuthService.ts | 200 OK |
| 11 | app/services/DunningService.ts | 200 OK |
| 12 | app/routes/webhooks.selling_plan_groups.create_or_update.tsx | 200 OK |
| 13 | app/routes/webhooks.app.uninstalled.tsx | 200 OK |
| 14 | app/routes/internal.jobs.run.tsx | 200 OK |
| 15 | app/routes/services.ping.tsx | 200 OK |
| 16 | app/routes/maintenance._index/route.tsx | 200 OK |
| 17 | app/routes/missing-scopes._index/route.tsx | 200 OK |
| 18 | app/types/index.ts | 200 OK |
| 19 | test/constants.ts | 200 OK |
| 20 | test/setup-test-env.ts | 200 OK |
| 21 | test/utils/mocks.ts | 200 OK |
| 22 | prisma/schema.prisma | 200 OK |

### hydrogen (main branch)
| # | File | Status |
|---|------|--------|
| 1 | package.json | 200 OK |
| 2 | packages/hydrogen/package.json | 200 OK |
| 3 | packages/cli/package.json | 200 OK |
| 4 | README.md | 200 OK |
| 5 | packages/hydrogen/src/createRequestHandler.ts | 200 OK |
| 6 | packages/hydrogen/src/createHydrogenContext.ts | 200 OK |
| 7 | packages/hydrogen/src/storefront.ts | 200 OK |
| 8 | packages/hydrogen/src/customer/customer.ts | 200 OK |
| 9 | packages/hydrogen/src/customer/auth.helpers.ts | 200 OK |
| 10 | packages/hydrogen/src/customer/customer-account-helper.ts | 200 OK |
| 11 | packages/hydrogen/src/utils/request.ts | 200 OK |
| 12 | packages/hydrogen/src/constants.ts | 200 OK |
| 13 | packages/hydrogen/src/index.ts | 200 OK |
| 14 | packages/cli/src/commands/hydrogen/env/pull.ts | 200 OK |
| 15 | packages/cli/src/commands/hydrogen/env/push.ts | 200 OK |
| 16 | packages/cli/src/lib/auth.ts | 200 OK |
| 17 | packages/cli/src/lib/graphql/admin/client.ts | 200 OK |
| 18 | packages/cli/src/lib/shopify-config.ts | 200 OK |
| 19 | packages/cli/src/lib/graphql/business-platform/user-account.ts | 200 OK |
| 20 | packages/cli/src/index.ts | 200 OK |
| 21 | packages/cli/src/hooks/init.ts | 200 OK |
| 22 | packages/hydrogen/src/vite/hydrogen-middleware.ts | 200 OK |
| 23 | packages/hydrogen/src/storefrontClient.example.ts | 200 OK |
| 24 | packages/hydrogen-react/src/storefront-client.ts | 200 OK |
| 25 | templates/skeleton/server.ts | 200 OK |
| 26 | templates/skeleton/app/lib/context.ts | 200 OK |
| 27 | templates/skeleton/app/lib/session.ts | 200 OK |
| 28 | templates/skeleton/.env | 200 OK |
| 29 | templates/skeleton/package.json | 200 OK |
| 30 | templates/skeleton/react-router.config.ts | 200 OK |
| 31 | e2e/envs/.env.hydrogenPreviewStorefront | 200 OK |
| 32 | e2e/envs/.env.mockShop | 200 OK |
| 33 | e2e/envs/.env.customerAccount | 200 OK |
| 34 | e2e/fixtures/storefront.ts | 200 OK |
| 35 | e2e/fixtures/server.ts | 200 OK |

---

## OSV API Requests (api.osv.dev/v1/query)

| # | Package | Version | Vulnerabilities Found |
|---|---------|--------|-----------------------|
| 1 | @anthropic-ai/sdk | 0.40.0 | 0 (Clean) |
| 2 | prisma | 6.2.1 | 0 (Clean) |
| 3 | eslint | 8.38.0 | 0 (Clean per OSV) |
| 4 | vite | 6.2.2 | 12 vulnerabilities |
| 5 | jsonwebtoken | 9.0.2 | 0 (Clean) |
| 6 | lodash | 4.17.21 | 3 vulnerabilities |
| 7 | @shopify/shopify-api | 11.13.0 | 0 (Clean) |
| 8 | @shopify/shopify-app-remix | 3.8.3 | 0 (Clean) |
| 9 | @prisma/client | 6.10.1 | 0 (Clean) |
| 10 | zod | 3.25.67 | 0 (Clean) |
| 11 | @google-cloud/storage | 7.16.0 | 0 (Clean) |
| 12 | esbuild | 0.27.0 | 0 (Clean) |
| 13 | @oclif/core | 3.26.5 | 0 (Clean) |
| 14 | @shopify/cli | 3.93.2 | 0 (Clean) |
| 15 | diff | 5.1.0 | 1 vulnerability |
| 16 | react-router | 7.16.0 | 5 vulnerabilities |
| 17 | @shopify/oxygen-cli | 4.6.18 | 0 (Clean) |
| 18 | content-security-policy-builder | 2.2.0 | 0 (Clean) |
| 19 | worktop | 0.7.3 | 0 (Clean) |
| 20 | ts-morph | 20.0.0 | 0 (Clean) |

Note: GitHub Advisory API requests returned rate-limited/unclear results (same 30 advisories for all packages). Used OSV.dev API for accurate vulnerability data.
