# Architecture Analysis - shop-chat-agent

**Repo**: https://github.com/Shopify/shop-chat-agent
**Branch**: main
**Total Files**: 77
**Last Analyzed**: $(date -u +"%Y-%m-%d %H:%M:%S UTC")

---

## 1. Entry Point & Bootstrapping

### package.json scripts
| Script | Command | Description |
|--------|---------|-------------|
| `dev` | `shopify app dev` | Start development server with Shopify CLI |
| `build` | `react-router build` | Production build via React Router |
| `start` | `react-router-serve ./build/server/index.js` | Production server entry |
| `docker-start` | `npm run setup && npm run start` | Docker container start |
| `setup` | `prisma generate && prisma migrate deploy` | DB setup |
| `typecheck` | `react-router typegen && tsc --noEmit` | TypeScript type checking |

### Entry Files
- **Server entry**: `app/entry.server.jsx` - React DOM server-side rendering via `renderToPipeableStream`
- **App shell**: `app/root.jsx` - Root component (imports Inter font from CDN, sets up HTML structure)
- **Route config**: `app/routes.js` - Uses `flatRoutes()` from `@react-router/fs-routes` for file-based routing
- **Shopify app**: `app/shopify.server.js` - Initializes Shopify app context with `shopifyApp()`

### Dockerfile
- Base image: `node:18-alpine` (Node 18 is EOL since April 2025)
- Installs `openssl` for dev cert purposes
- EXPOSE 3000
- Runs `npm ci --omit=dev`, removes CLI packages, builds, then `docker-start`

---

## 2. Stack Technology

| Layer | Technology | Version | Source |
|-------|-----------|---------|--------|
| **Framework** | React Router (v7) | ^7.9.1 | package.json |
| **Runtime** | Node.js | >=20.10 | package.json `engines` |
| **Server** | react-router-serve | ^7.9.1 | package.json |
| **ORM** | Prisma | ^6.2.1 | package.json |
| **Database** | SQLite | file:dev.sqlite | prisma/schema.prisma |
| **Session Store** | PrismaSessionStorage | ^7.0.0 | @shopify/shopify-app-session-storage-prisma |
| **AI Model** | Claude (Anthropic) | claude-sonnet-4-20250514 | app/services/config.server.js |
| **AI SDK** | @anthropic-ai/sdk | ^0.40.0 | package.json |
| **Shopify SDK** | @shopify/shopify-app-react-router | ^1.0.0 | package.json |
| **UI** | React | ^18.2.0 | package.json |
| **Build Tool** | Vite | ^6.2.2 | package.json |
| **Theme Extension** | Shopify UI Extensions | workspace | extensions/* workspaces |
| **MCP** | Model Context Protocol | - | app/mcp-client.js |
| **CSS** | CSS Modules | - | app/routes/_index/styles.module.css |

---

## 3. Route Files

### App Routes (authenticated)
| File | Purpose |
|------|---------|
| `app/routes/app.jsx` | Authenticated app layout wrapper |
| `app/routes/app._index.jsx` | App dashboard/index |
| `app/routes/_index/route.jsx` | Public index route (chat widget landing page) |

### Auth Routes
| File | Purpose |
|------|---------|
| `app/routes/auth.$.jsx` | Admin OAuth authentication - delegates to `authenticate.admin()` |
| `app/routes/auth.callback.jsx` | Customer OAuth callback handler (PKCE flow) - exchanges code for token, stores in DB |
| `app/routes/auth.token-status.jsx` | Polls customer auth token status by conversation_id (GET endpoint) |

### API Routes
| File | Purpose |
|------|---------|
| `app/routes/chat.jsx` | Main chat API - SSE streaming endpoint for chat interactions |
| `app/routes/api.webhooks.jsx` | Webhook handler (APP_UNINSTALLED only) |

---

## 4. Service Layer

### Services
| File | Purpose |
|------|---------|
| `app/services/claude.server.js` | Claude AI service - streaming conversation via Anthropic SDK |
| `app/services/config.server.js` | Centralized config - API model, max tokens, error templates |
| `app/services/streaming.server.js` | SSE streaming utilities - createSseStream, error handling |
| `app/services/tool.server.js` | Tool result processing - handles tool success/error, product search |

### MCP Client
| File | Purpose |
|------|---------|
| `app/mcp-client.js` | JSON-RPC MCP client - connects to customer and storefront MCP servers |

---

## 5. Auth Model

### Shopify Admin Auth (OAuth 2.0)
- **Framework**: @shopify/shopify-app-react-router v1.0.0
- **Storage**: PrismaSessionStorage (SQLite)
- **Scopes**: `unauthenticated_read_product_listings` (from shopify.app.toml)
- **API Version**: ApiVersion.October25 (2025-10)
- **Flow**: Standard Shopify OAuth with authPathPrefix="/auth"

### Customer Auth (PKCE + OAuth 2.0)
- **Client ID**: process.env.SHOPIFY_API_KEY
- **Scope**: `customer-account-mcp-api:full` (hardcoded)
- **PKCE**: Full PKCE implementation (code_verifier, code_challenge with S256)
- **State tracking**: `{conversationId}-{shopId}`
- **Code verifier**: Stored in DB, 10-min expiry, single-use (deleted after retrieval)
- **Token storage**: Customer access tokens in DB, keyed by conversationId
- **Discovery**: Well-known endpoints: `/.well-known/customer-account-api` and `/.well-known/openid-configuration`

---

## 6. Data Flow

### Chat Request Flow (SSE Streaming)
```
Client POST /chat (message)
  -> app/routes/chat.jsx -> handleChatRequest()
  -> Generates/reuses conversation_id
  -> Creates SSE stream via createSseStream()
  -> handleChatSession():
    1. Reads X-Shopify-Shop-Id / Origin headers
    2. getCustomerAccountUrls() - queries well-known endpoints, caches in DB
    3. Creates MCPClient with hostUrl, conversationId, shopId, mcpApiUrl
    4. Sends {type: 'id', conversation_id} to client
    5. Connects to storefront MCP (no auth) - tools/list
    6. Connects to customer MCP (with token if available) - tools/list
    7. Saves user message to DB
    8. Fetches conversation history from DB
    9. Streams Claude conversation (onText/onMessage/onToolUse/onContentBlock)
    10. Sends {type: 'end_turn'} and {type: 'product_results'}
```

### Customer OAuth Flow
```
1. 401 from customer MCP tool -> auth_required error
2. Front-end displays auth link
3. User clicks -> opens customer account OAuth URL
4. Callback -> app/routes/auth.callback.jsx
5. Exchanges code for token (x-www-form-urlencoded POST to tokenUrl)
6. Uses PKCE code_verifier from DB (looked up by state)
7. Stores customer token in DB
8. Returns auto-closing HTML
9. Front-end polls /token-status
```

---

## 7. DB Layer (Prisma / SQLite)

### Schema Models
| Model | Fields | Description |
|-------|--------|-------------|
| Session | id, shop, state, isOnline, scope, expires, accessToken, ... | Shopify app sessions |
| CustomerToken | id, conversationId, accessToken, refreshToken, expiresAt | Customer OAuth tokens |
| CodeVerifier | id, state (unique), verifier, createdAt, expiresAt | PKCE verifiers (10-min, single-use) |
| Conversation | id, messages[], createdAt, updatedAt | Conversation containers |
| Message | id, conversationId, role, content, createdAt | Chat messages |
| CustomerAccountUrls | id, conversationId, mcpApiUrl, authorizationUrl, tokenUrl | Discovered CA URLs |

---

## 8. Env Handling

| Variable | Example Value | Description |
|----------|--------------|-------------|
| CLAUDE_API_KEY | YOUR_CLAUDE_API_KEY | Anthropic API key |
| REDIRECT_URL | https://localhost:3458/auth/callback | Customer OAuth redirect |
| SHOPIFY_API_KEY | YOUR_APP_CLIENT_ID | Shopify app client ID |
| SHOPIFY_API_SECRET | (implicit) | Shopify app secret |
| SCOPES | (implicit) | Comma-separated scopes |
| SHOPIFY_APP_URL | (implicit) | App URL |
| SHOP_CUSTOM_DOMAIN | (optional) | Custom shop domain override |

### Config Files
- `shopify.app.toml`: application_url = "https://shop-chat-agent.com", scopes, webhook API version 2025-04
- `shopify.web.toml`: webhooks_path = "/webhooks/app/uninstalled", roles frontend+backend

---

## 9. Test Files
No test files found. No test runner configuration present.

---

## 10. Dependency Versions & CVE Check

### Production dependencies
| Package | Version | CVE Status |
|---------|--------|------------|
| @prisma/client | ^6.2.1 | Clean (OSV) |
| @anthropic-ai/sdk | ^0.40.0 | Clean (OSV) |
| prisma | ^6.2.1 | Clean (OSV) |
| react / react-dom | ^18.2.0 | Standard |
| react-router | ^7.9.1 | - |
| @shopify/shopify-app-react-router | ^1.0.0 | - |

### Dev dependencies with CVEs
| Package | Version | CVE Status |
|---------|--------|------------|
| eslint | ^8.38.0 | CVE-2024-7315 (ReDoS, affects < 8.57.1) |
| vite | ^6.2.2 | 12 vulnerabilities (path traversal, server.fs.deny bypass) |

### Docker
| Base Image | Version | CVE Status |
|-----------|--------|------------|
| node:18-alpine | 18 | CRITICAL - EOL since April 30, 2025 |

### Security-pinned dependencies (resolutions/overrides)
| Package | Version | Purpose |
|---------|--------|---------|
| @graphql-tools/url-loader | 8.0.16 | Security pin |
| @graphql-codegen/client-preset | 4.7.0 | Security pin |
| minimatch | 9.0.5 | ReDoS prevention pin |

### Key Security Findings
1. **CRITICAL**: Dockerfile uses `node:18-alpine` which is EOL (no security updates since April 2025)
2. **HIGH**: Vite 6.2.2 has 12 known CVEs including path traversal (GHSA-356w-63v5-8wf4, GHSA-4r4m-qw57-chr8, GHSA-4w7w-66w2-5vf9, GHSA-859w-5945-r5v3, GHSA-93m4-6634-74q7)
3. **MEDIUM**: ESLint 8.38.0 affected by CVE-2024-7315 (ReDoS)
4. **INFO**: Broad scope `customer-account-mcp-api:full` granted for customer auth
5. **INFO**: CORS headers use permissive wildcard fallback with credentials=true
6. **INFO**: `X-Shopify-Shop-Id` header not validated, potential spoofing

---

## 11. Summary

| Aspect | Detail |
|--------|--------|
| Stack | React Router 7 + Vite + Prisma/SQLite + TypeScript |
| Entry Point | `app/entry.server.jsx` (SSR), `react-router-serve` |
| Main Endpoints | `/chat` (SSE streaming), `/auth/callback`, `/token-status`, `/webhooks/api/app/uninstalled` |
| Auth Model | Shopify Admin OAuth 2.0 + Customer PKCE OAuth 2.0 (MCP API scope) |
| Data Flow | Client -> /chat SSE -> Claude API stream -> MCP tool calls -> DB persistence |
