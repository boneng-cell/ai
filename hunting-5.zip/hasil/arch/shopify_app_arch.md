# Architecture Recon - shopify_app

## Repository Info
- **Name:** Shopify/shopify_app
- **Description:** A Rails Engine for building Shopify Apps
- **Language:** Ruby
- **Default Branch:** main
- **Version:** 23.0.3
- **Ruby Version:** 3.2.2 (`.ruby-version`)
- **Stars:** 1,921 | **Forks:** 733
- **Created:** 2008-10-09 | **Updated:** 2026-08-09

---

## a) File Inventory

Git tree saved to: `/home/runner/work/hunting-5/hunting-5/hasil/trees/shopify_app.json` and `.txt`
Total tracked files: 397

### Key File Listing (lib/)
```
lib/shopify_app.rb                          # Main entry point / module definition
lib/shopify_app/version.rb                  # VERSION = "23.0.3"
lib/shopify_app/configuration.rb            # Configuration object
lib/shopify_app/engine.rb                   # Rails Engine
lib/shopify_app/errors.rb                   # Custom errors
lib/shopify_app/logger.rb                   # Logging wrapper
lib/shopify_app/utils.rb                    # Utility functions (domain sanitization, URL generation)

lib/shopify_app/controller_concerns/        # Controller concerns (middleware-like)
  - app_proxy_verification.rb               # App proxy HMAC verification
  - csrf_protection.rb                      # CSRF protection
  - embedded_app.rb                         # Embedded app layout concern
  - ensure_billing.rb                       # Billing enforcement (GraphQL)
  - ensure_authenticated_links.rb           # Authenticated links concern
  - ensure_has_session.rb                   # Session validation
  - frame_ancestors.rb                      # CSP frame-ancestors directive
  - localization.rb                         # i18n localization
  - login_protection.rb                     # Login/session protection
  - payload_verification.rb                 # Request payload HMAC verification
  - redirect_for_embedded.rb                # Embedded app redirect logic
  - sanitized_params.rb                     # Parameter sanitization
  - token_exchange.rb                       # Token exchange controller concern
  - webhook_verification.rb                 # Webhook HMAC verification
  - with_shopify_id_token.rb                # Session JWT handling

lib/shopify_app/auth/                       # Auth helpers
  - post_authenticate_tasks.rb              # Post-OAuth tasks (webhooks, scripttags, jobs)
  - token_exchange.rb                       # OAuth 2.0 Token Exchange flow

lib/shopify_app/managers/
  - webhooks_manager.rb                     # Webhook registration/deregistration
  - script_tags_manager.rb                  # Script tag registration

lib/shopify_app/session/                    # Session storage strategies
  - session_repository.rb                   # Session repository (shop + user sessions)
  - session_storage.rb                      # SessionStorage interface
  - shop_session_storage.rb                 # Shop session storage (DB)
  - shop_session_storage_with_scopes.rb
  - user_session_storage.rb                 # User session storage (DB)
  - user_session_storage_with_scopes.rb
  - in_memory_session_store.rb
  - in_memory_shop_session_store.rb
  - in_memory_user_session_store.rb
  - null_user_session_store.rb

lib/shopify_app/access_scopes/
  - shop_strategy.rb                        # Shop access scope strategy
  - user_strategy.rb                        # User access scope strategy
  - noop_strategy.rb                        # No-op strategy

lib/shopify_app/admin_api/
  - with_token_refetch.rb                   # Token refetch middleware

lib/shopify_app/test_helpers/               # Test helpers
  - all.rb
  - shopify_session_helper.rb
  - webhook_verification_helper.rb

app/controllers/
  - shopify_app/sessions_controller.rb      # Login/OAuth controller
  - shopify_app/callback_controller.rb      # OAuth callback controller
  - shopify_app/webhooks_controller.rb      # Webhook receiver controller
  - shopify_app/authenticated_controller.rb # Base authenticated controller
  app/controllers/concerns/
    - ensure_authenticated_links.rb
    - ensure_has_session.rb

config/
  - routes.rb                               # Engine routes
  - locales/*.yml                           # 20 locale files

lib/generators/                             # Rails generators
  - app_proxy_controller/
  - authenticated_controller/
  - home_controller/
  - routes/
  - install/
  - add_webhook/
  - add_declarative_webhook/
  - add_after_authenticate_job/
  - add_privacy_jobs/

test/                                       # Test suite (Minitest)
  - test/dummy/                             # Dummy Rails app
    - config/application.rb
    - config/database.yml
    - config/initializers/shopify_app.rb
    - config/routes.rb
  - test/controllers/                       # Controller tests
  - test/shopify_app/                       # Unit tests for lib modules
  - test/generators/                        # Generator tests
  - test/integration/                       # Integration tests
  - test/routes/                            # Route tests (sessions, callback, webhooks)
  - test/javascripts/                       # JS tests (redirect_test.js)
  - test/app_templates/                     # App template tests for generators

docs/shopify_app/
  - authentication.md, engine.md, sessions.md, testing.md, webhooks.md, etc.
```

---

## b) Architecture Map

### Entry Point
- **`lib/shopify_app.rb`** - Main module file that requires all submodules and dependencies
- **`lib/shopify_app/engine.rb`** - Rails::Engine subclass that mounts the engine, registers assets, and configures ActiveJob logging redaction

### Route Files
- **`config/routes.rb`** - Defines engine routes:
  - `GET/POST /login` → SessionsController#new/create
  - `GET /auth/shopify/callback` → CallbackController#callback (OAuth redirect URI)
  - `GET /logout` → SessionsController#destroy
  - `GET /patch_shopify_id_token` → SessionsController#patch_shopify_id_token
  - `POST /webhooks/:type` → WebhooksController#receive

### Middleware
- **`app/controllers/concerns/login_protection.rb`** - Session protection middleware-like concern; loads current session from encrypted cookie, validates JWT tokens, checks session expiry
- **`app/controllers/concerns/csrf_protection.rb`** - CSRF protection
- **`app/controllers/concerns/frame_ancestors.rb`** - Sets CSP frame-ancestors header to allow Shopify domains
- **`app/controllers/concerns/payload_verification.rb`** - HMAC verification of request payloads
- **`app/controllers/concerns/webhook_verification.rb`** - Webhook HMAC verification (skip CSRF, verify X-Shopify-Hmac-Sha256)
- **`app/controllers/concerns/ensure_billing.rb`** - Billing enforcement via GraphQL queries
- **`app/controllers/concerns/token_exchange.rb`** - OAuth 2.0 Token Exchange controller concern
- **`app/controllers/concerns/with_shopify_id_token.rb`** - Session JWT token handling
- **`app/controllers/concerns/redirect_for_embedded.rb`** - Top-level redirect logic for embedded apps
- **`app/controllers/concerns/app_proxy_verification.rb`** - App proxy HMAC verification
- **`lib/shopify_app/admin_api/with_token_refetch.rb`** - Token refetch middleware for Admin API calls

### Service Layer
- **`lib/shopify_app/auth/token_exchange.rb`** - Performs OAuth 2.0 Token Exchange (offline + online tokens) using session tokens
- **`lib/shopify_app/auth/post_authenticate_tasks.rb`** - Post-authentication tasks: installs webhooks, registers script tags, runs after_authenticate_job
- **`lib/shopify_app/managers/webhooks_manager.rb`** - Manages webhook registration/unregistration via ShopifyAPI::Webhooks::Registry
- **`lib/shopify_app/managers/script_tags_manager.rb`** - Manages script tag registration
- **`lib/shopify_app/utils.rb`** - Domain sanitization and URL generation utilities (trusted domains: shopify.com, myshopify.io, myshopify.com, spin.dev, shop.dev)

### DB Layer
- **`lib/shopify_app/session/session_repository.rb`** - SessionRepository class; delegates to shop_storage and user_storage (pluggable ActiveRecord models)
- **`lib/shopify_app/session/shop_session_storage.rb`** - Abstract class for shop session storage (requires ActiveRecord)
- **`lib/shopify_app/session/user_session_storage.rb`** - Abstract class for user session storage (requires ActiveRecord)
- **`test/dummy/config/database.yml`** - SQLite database config for test environment
- Session storage is pluggable; developers implement `store`, `retrieve`, `retrieve_by_shopify_domain` (shop) and `retrieve_by_shopify_user_id` (user) methods

### Env Handling
- **`lib/shopify_app/configuration.rb`** - Configuration object loaded from `config/initializers/shopify_app.rb`:
  - `api_key` = Shopify API key (must be set by developer)
  - `secret` = Shopify API secret key (must be set by developer)
  - `scope` = access scopes array
  - `embedded_app` = boolean for embedded app mode
  - `new_embedded_auth_strategy` = enable token exchange flow
  - `myshopify_domain` = default "myshopify.com"
  - `unified_admin_domain` = default "shopify.com"
  - `webhooks` = webhook configuration
  - `billing` = BillingConfiguration object
  - `root_url`, `login_url`, `login_callback_url` = customizable URLs
  - `reauth_on_access_scope_changes` = boolean
  - `check_session_expiry_date` = boolean
  - `log_level` = logging level

### Auth Model
1. **Legacy OAuth 2.0 Authorization Code Grant** - Standard OAuth flow via `/login` → redirect to `https://{shop}.myshopify.com/admin/oauth/authorize` → callback at `https://{app}/auth/shopify/callback` → exchange code for access token at `https://{shop}.myshopify.com/admin/oauth/access_token`
2. **New Embedded Auth Strategy (Token Exchange)** - Uses [Shopify managed installation](https://shopify.dev/docs/apps/auth/installation#shopify-managed-installation) + [OAuth 2.0 Token Exchange](https://shopify.dev/docs/apps/auth/get-access-tokens/token-exchange) with session tokens (JWTs)
3. **Session Token Validation** - JWT validation via `with_shopify_id_token.rb` concern
4. **Webhook HMAC Verification** - SHA256 HMAC verification of webhook payloads using app secret

### Test Files
- Test framework: **Minitest** + **WebMock** (HTTP mocking) + **SQLite3** (test DB)
- Test directories: `test/controllers/`, `test/shopify_app/`, `test/generators/`, `test/integration/`, `test/routes/`, `test/javascripts/`
- Dummy app: `test/dummy/` with Rails 7.1 application
- Test helpers: `lib/shopify_app/test_helpers/` (ShopifySessionHelper, WebhookVerificationHelper)
- CI: Ruby 3.2, 3.3, 3.4 tested on macOS

---

## d) Dependency Versions + CVE Check

### Runtime Dependencies (from shopify_app.gemspec)
| Dependency | Version Constraint | Latest Resolved | CVE Status |
|---|---|---|---|
| **rails** | `>= 7.1, < 9` | 7.1.6 (in Gemfile.lock) | Rails 7.1.6 - check CVE-2024-21129, CVE-2024-25126, CVE-2024-25305, CVE-2024-26141, CVE-2024-34954 (all in Rails 7.1.x) |
| **shopify_api** | `~> 16.0` | 16.0.0 (in Gemfile.lock) | Depends on transitive deps |
| **addressable** | `~> 2.7` | 2.8.0+ (in Gemfile.lock: >= 2.8.0) | CVE-2021-46853? No - this is URI parsing lib, monitor for ReDoS |
| **redirect_safely** | `~> 1.0` | 1.0.x | Check for open redirect vulnerabilities |
| **sprockets-rails** | (no pin) | latest | Sprockets CVE-2022-24080 type issues - monitor version |
| **Ruby** | `>= 3.2` | 3.2.2 (.ruby-version) | N/A |

### Development Dependencies
| Dependency | Version Constraint |
|---|---|
| **jwt** | `>= 2.2.3` (resolved: 3.1.2 in Gemfile.lock) |
| **minitest** | latest |
| **mocha** | `>= 2.1.0` |
| **webmock** | 3.18.1 |
| **sqlite3** | 2.7.4 |
| **byebug** | 11.1.3 |
| **pry** | 0.14.2 |
| **ruby-lsp** | 0.5.1 |
| **rb-readline** | 0.5.5 |

### CI Environment
- **Ruby versions:** 3.2, 3.3, 3.4
- **Rails version:** `~> 7.1.0` (Gemfile pins Rails 7.1.6)
- **Node:** 18 (for JS tests)
- **Platform:** macOS (for Chrome testing)
- **Database:** SQLite3 (test environment)

### CVE Risk Summary
1. **Rails 7.1.6** - Multiple CVEs exist in Rails 7.1.x series; recommend updating to latest 7.1.x or 7.2.x
2. **jwt 3.1.2** - Ensure not vulnerable to key confusion attacks (verify algorithm constraints)
3. **addressable 2.8.0+** - Monitor for ReDoS vulnerabilities in URI parsing
4. **sprockets-rails** - Monitor for path traversal (CVE-2022-24080 pattern)

---

## e) Summary Output

**Stack:** Ruby 3.2 | Rails 7.1 Engine | ActiveRecord (SQLite3/Rails DB agnostic) | Minitest + WebMock

**Endpoints (Engine Routes):**
- `GET/POST /login` → OAuth initiation
- `GET /auth/shopify/callback` → OAuth callback (code exchange)
- `GET /logout` → Session termination
- `POST /webhooks/:type` → Webhook receiver
- `GET /patch_shopify_id_token` → ID token refresh

**Auth Model:** Dual-mode (Legacy OAuth 2.0 Authorization Code Grant + New Token Exchange via session JWTs). Cookie-based encrypted session storage. Webhook HMAC-SHA256 verification. App proxy verification.

**Data Flow:**
1. User visits `/login` → SessionsController begins OAuth (or starts Shopify managed install for embedded apps)
2. Redirect to `https://{shop}.myshopify.com/admin/oauth/authorize?client_id=...&redirect_uri=...&scope=...` (or unified admin install URL)
3. Shopify redirects back to `/auth/shopify/callback` with `code`, `shop`, `state`, `hmac`
4. CallbackController validates HMAC, exchanges code for access token via `ShopifyAPI::Auth::Oauth.validate_auth_callback`
5. PostAuthenticateTasks installs webhooks + script tags, runs optional after_authenticate_job
6. User accesses app → LoginProtection concern loads session from encrypted cookie → validates JWT → activates ShopifyAPI::Context session
7. Webhooks arrive at `/webhooks/:type` → WebhookVerification concern validates HMAC → dispatches to ShopifyAPI::Webhooks::Registry
8. For embedded apps with new auth: TokenExchange performs OAuth 2.0 token exchange with session JWT → stores session via SessionRepository

**Session Storage:** Pluggable (shop sessions + user sessions via ActiveRecord). Session IDs: `offline_{shop}` for shop sessions, `{user_id}` for user sessions.
