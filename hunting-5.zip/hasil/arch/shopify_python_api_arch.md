# Architecture Recon - shopify_python_api

## Repository Info
- **Name:** Shopify/shopify_python_api
- **Description:** ShopifyAPI library allows Python developers to programmatically access the admin section of stores
- **Language:** Python
- **Default Branch:** main
- **Version:** 12.7.1 (`shopify/version.py`)
- **Stars:** 1,433 | **Forks:** 386
- **Created:** 2011-08-22 | **Updated:** 2026-07-24

---

## a) File Inventory

Git tree saved to: `/home/runner/work/hunting-5/hunting-5/hasil/trees/shopify_python_api.json` and `.txt`
Total tracked files: 305

### Key File Listing (shopify/ package)
```
shopify/__init__.py                 # Package entry point - imports all modules
shopify/version.py                  # VERSION = "12.7.1"
shopify/base.py                     # ShopifyResource + ShopifyResourceMeta (metaclass with thread-local sessions)
shopify/session.py                  # Session class - OAuth, HMAC validation, URL generation
shopify/session_token.py            # JWT Session Token validation (decode_from_header, validate_issuer)
shopify/api_version.py              # ApiVersion enum with known API versions (2021-10 to 2024-10 + Unstable)
shopify/api_access.py               # ApiAccess class - scope validation, implied scopes
shopify/resources/__init__.py       # All resource classes exported (50+ resources)
shopify/resources/graphql.py        # GraphQL client class
shopify/resources/*.py              # 50+ ActiveResource subclasses (Product, Order, etc.)
shopify/collection.py               # PaginatedCollection class
shopify/limits.py                   # API call limit tracking
shopify/mixins.py                   # Countable mixin for resources
shopify/yamlobjects.py              # YAML object utilities
shopify/utils/__init__.py
shopify/utils/shop_url.py           # Shop URL sanitization/validation
scripts/shopify_api.py              # CLI console script

test/
  test_helper.py                    # Base TestCase with HTTP fake setup
  test/*.py                         # 30+ test files (one per resource type)
  test/fixtures/*.json              # 100+ JSON fixtures for API response mocking

config/
  pyproject.toml                    # Black formatter config (line-length=120)
  tox.ini                           # Test runner configuration
  .pre-commit-config.yaml           # Pre-commit hooks
  setup.py                          # Package definition + dependencies
  requirements.txt                  # setuptools (install requirement only)
```

### Resource Classes (shopify/resources/)
```
access_scope.py, address.py, api_permission.py, application_charge.py,
application_credit.py, article.py, asset.py, balance.py, billing_address.py,
blog.py, carrier_service.py, cart.py, checkout.py, collect.py,
collection_listing.py, collection_publication.py, comment.py, country.py,
currency.py, custom_collection.py, customer.py, customer_group.py,
customer_invite.py, customer_saved_search.py, discount_code.py,
discount_code_creation.py, disputes.py, draft_order.py, draft_order_invoice.py,
event.py, fulfillment.py, fulfillment_event.py, fulfillment_service.py,
gift_card.py, gift_card_adjustment.py, graphql.py, image.py, inventory_item.py,
inventory_level.py, line_item.py, location.py, marketing_event.py, metafield.py,
note_attribute.py, option.py, order.py, order_risk.py, page.py, payment_details.py,
payouts.py, policy.py, price_rule.py, product.py, product_listing.py,
product_publication.py, province.py, publication.py, receipt.py,
recurring_application_charge.py, redirect.py, refund.py, report.py,
resource_feedback.py, rule.py, script_tag.py, shipping_address.py,
shipping_line.py, shipping_zone.py, shop.py, smart_collection.py,
storefront_access_token.py, tax_line.py, tender_transaction.py, theme.py,
transaction.py, transactions.py, usage_charge.py, user.py, variant.py, webhook.py
```

---

## b) Architecture Map

### Entry Point
- **`shopify/__init__.py`** - Package initialization; imports VERSION, Session, all resources, Limits, ApiVersion, ApiAccess, PaginatedCollection

### Auth Flow
1. **Session setup:** `shopify.Session.setup(api_key=API_KEY, secret=API_SECRET)` - sets class-level credentials
2. **OAuth URL generation:** `session.create_permission_url(redirect_uri, scopes, state)` → returns `https://{shop}.myshopify.com/admin/oauth/authorize?client_id=...&redirect_uri=...&scope=...&state=...`
3. **Token exchange:** `session.request_token(params)` - validates HMAC + timing, exchanges code for access token at `https://{shop}.myshopify.com/admin/oauth/access_token`
4. **Session activation:** `shopify.ShopifyResource.activate_session(session)` - sets site URL, access token header, API version
5. **Session token validation:** `shopify.session_token.decode_from_header(auth_header, api_key, secret)` - decodes JWT, validates issuer, checks required fields (iss, dest, sub, jti, sid)

### HTTP / Data Flow Layer
- **`shopify/base.py`**:
  - `ShopifyResourceMeta` metaclass with thread-local storage for session data (site, token, headers, version)
  - `ShopifyConnection` - custom Connection class that stores last response for pagination/limits
  - `ShopifyResource(ActiveResource)` - base class for all API resources
  - `activate_session(session)` - activates REST API session
  - `clear_session()` - deactivates session
  - `find()` - overridden to return PaginatedCollection with metadata
- **`shopify/resources/graphql.py`**:
  - `GraphQL` class - executes GraphQL queries via `{site}/graphql.json`
  - Merges headers, sends JSON-encoded query/variables/operationName

### API Versioning
- **`shopify/api_version.py`**:
  - Known versions: 2021-10, 2022-01, 2022-04, 2022-07, 2022-10, 2023-01, 2023-04, 2023-07, 2023-10, 2024-01, 2024-04, 2024-07, 2024-10 + "unstable"
  - Dynamic version creation: unknown version strings matching `^\d{4}-\d{2}$` are created on-the-fly
  - API path: `https://{shop}.myshopify.com/admin/api/{version}`

### Session Token (JWT) Validation
- **`shopify/session_token.py`**:
  - Algorithm: HS256
  - Required JWT fields: `iss`, `dest`, `sub`, `jti`, `sid`
  - Leeway: 10 seconds (clock skew tolerance)
  - Validates issuer hostname is a trusted Shopify domain
  - Validates issuer and destination match
  - Raises `InvalidIssuerError`, `MismatchedHostsError`, `TokenAuthenticationError`
  - **Backwards compatibility shim:** `if sys.version_info[0] < 3` handles Python 2 (urlparse) - dead code for Python 3

### HMAC Validation
- **`shopify/session.py`**:
  - `validate_params(params)` - validates OAuth callback HMAC + checks timestamp not older than 1 day (replay attack prevention)
  - `validate_hmac(params)` - uses `hmac.compare_digest()` (timing-safe comparison)
  - `calculate_hmac(params)` - HMAC-SHA256 of sorted params using app secret

### Rate Limiting
- **`shopify/limits.py`**:
  - Tracks API call limit from Shopify response headers
  - Documentation reference: `https://help.shopify.com/en/api/getting-started/api-call-limit`

### DB Layer
- **No database layer** - this is a client library, not a web application
- Session storage is in-memory (thread-local) or managed by the host application
- `Session.temp()` context manager for temporary session activation

### Env Handling
- **`shopify/session.py`**:
  - Class-level attributes: `api_key = None`, `secret = None`, `protocol = "https"`, `myshopify_domain = "myshopify.com"`, `port = None`
  - Set via `Session.setup(api_key=..., secret=...)`
  - No environment variable loading built-in; developer must read ENV and pass to setup()
- **`shopify/utils/shop_url.py`** - Shop URL sanitization and validation

### Test Files
- Test framework: **unittest** (Python stdlib) + **pytest** (CI) + **pyactiveresource.testing.http_fake** (HTTP mocking)
- Test files: 30+ test files (one per resource: `product_test.py`, `order_test.py`, `customer_test.py`, etc.)
- Test helper: `test/test_helper.py` - base TestCase with HTTP fake, fixture loading, and `fake()` method for endpoint mocking
- Fixtures: 100+ JSON files in `test/fixtures/` (product.json, order.json, customer.json, etc.)
- CI: Python 3.8, 3.9, 3.10, 3.11, 3.12 tested on Ubuntu

---

## d) Dependency Versions + CVE Check

### Runtime Dependencies (from setup.py)
| Dependency | Version Constraint | Latest Known Version | CVE Status |
|---|---|---|---|
| **pyactiveresource** | `>= 2.2.2` | 2.x (Shopify fork) | Check for HTTP redirect/response handling issues |
| **PyJWT** | `>= 2.0.0` | 2.x latest | **CVE-2022-29217** (key confusion), **CVE-2024-30398** (CVE-2024-30398 affects PyJWT < 2.7.0? Check) - ensure >= 2.7.0 |
| **PyYAML** | `>= 6.0.1` (py>=3.12) or any (py<3.12) | 6.x | **CVE-2020-1747** (yaml.load unsafe), **CVE-2020-14343** (unsafe load), **CVE-2021-3121** (Bundler-related), **CVE-2022-14771**, **CVE-2023-40268** (XML), **CVE-2023-41104** (500+) - ensure >= 6.0.1 |
| **six** | (no pin) | 1.16.0 | **CVE-2021-23336**? No. Six is stable. Monitor for any issues. |

### Development/Test Dependencies
| Dependency | Version |
|---|---|
| **setuptools** | latest (requirements.txt) |
| **mock** | `>= 1.0.1` |
| **pytest** | latest |
| **pytest-cov** | latest |
| **pre-commit** | latest |

### CI Environment
- **Python versions:** 3.8, 3.9, 3.10, 3.11, 3.12
- **Platform:** Ubuntu
- **Package manager:** pip (setup.py-based)

### CVE Risk Summary
1. **PyJWT >= 2.0.0 (no upper bound)** - **HIGH RISK**: Versions before 2.7.0 may be vulnerable to **CVE-2022-29217** (algorithm confusion) and **CVE-2024-30398** - no upper version pin means latest is not guaranteed when installed
2. **PyYAML >= 6.0.1 only for Python 3.12+** - **MEDIUM RISK**: For Python < 3.12, PyYAML has no version constraint, potentially pulling vulnerable versions with CVE-2020-14343 (arbitrary code execution via yaml.load)
3. **pyactiveresource >= 2.2.2** - **LOW RISK**: HTTP library, ensure handles redirects securely (SSRF)
4. **six (no version pin)** - **LOW RISK**: Generally stable, but no version constraint is poor practice

### Notable Code Issues
1. **Python 2 compatibility code** still present (`if sys.version_info[0] < 3`) - dead code in Python 3, but indicates potential for version-related bugs
2. **Thread-local storage** in ShopifyResourceMeta - potential for session data leakage between threads if not managed correctly
3. **No SSL certificate verification** - relies on system defaults (pyactiveresource/urllib3)
4. **Dynamic API version creation** - unknown version strings create Release objects on-the-fly without validation against Shopify's known versions

---

## e) Summary Output

**Stack:** Python 3.7-3.12 | pyactiveresource (ActiveResource port) | unittest/pytest | No web framework

**Endpoints:**
- `https://{shop}.myshopify.com/admin/oauth/authorize` (OAuth)
- `https://{shop}.myshopify.com/admin/oauth/access_token` (Token exchange)
- `https://{shop}.myshopify.com/admin/api/{version}` (REST API base)
- `https://{shop}.myshopify.com/admin/api/{version}/graphql.json` (GraphQL API)
- `https://shopify.com/authentication/{shopId}/oauth/authorize` (Customer Account API)
- `https://shopify.com/authentication/{shopId}/oauth/token` (Customer Account API)
- `https://{shop}.myshopify.com/admin/apps/private` (Private app URL, CLI script)

**Auth Model:** OAuth 2.0 Authorization Code Grant (HMAC-SHA256 validation of callback). Session token (JWT) validation for embedded apps. Access token sent as `X-Shopify-Access-Token` header. Private app password (basic auth) supported.

**Data Flow:**
1. Developer sets API key + secret via `Session.setup()`
2. Create `Session(shop_url, api_version)` → `create_permission_url()` generates OAuth URL
3. User redirected to OAuth URL → Shopify redirects to callback with `code`, `state`, `hmac`, `timestamp`
4. `request_token(params)` validates HMAC + timestamp → exchanges code for access token at `/admin/oauth/access_token`
5. `activate_session(session)` sets ShopifyResource.site = `https://{shop}.myshopify.com/admin/api/{version}`, adds `X-Shopify-Access-Token` header
6. REST: `shopify.Product.find()` → pyactiveresource HTTP GET → `https://{shop}.myshopify.com/admin/api/{version}/products.json`
7. GraphQL: `shopify.GraphQL().execute(query)` → HTTP POST to `{site}/graphql.json` with JSON body
8. Session token (JWT): `decode_from_header(auth_header, api_key, secret)` → validates issuer, audience, required fields → returns decoded payload

**Special Features:**
- Thread-local session storage (multi-threaded safety)
- PaginatedCollection with cursor-based pagination
- Dynamic API version creation (on-the-fly Release objects for unknown versions)
- Private apps supported (password = access token, basic auth)
- API rate limit tracking via response headers
- 50+ resource classes (REST ActiveResource pattern)
