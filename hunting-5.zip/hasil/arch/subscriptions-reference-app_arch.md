# Architecture Analysis - subscriptions-reference-app

**Repo**: https://github.com/Shopify/subscriptions-reference-app
**Branch**: main
**Total Files**: 1,338
**Last Analyzed**: $(date -u +"%Y-%m-%d %H:%M:%S UTC")

---

## 1. Entry Point & Bootstrapping

### package.json scripts
| Script | Command | Description |
|--------|---------|-------------|
| `dev` | `dotenv -c development pnpm shopify app dev` | Development server |
| `build` | `NODE_ENV=production remix vite:build` | Production build (Remix + Vite) |
| `start` | `remix-serve ./build/server/index.js` | Production server (Remix serve) |
| `setup` | `prisma generate && prisma migrate deploy` | DB setup |
| `test` | `LC_ALL=en_US.UTF-8 TZ=UTC dotenv -c test vitest` | Run tests |
| `test:ci:buyer-subscriptions` | vitest extensions/buyer-subscriptions | Extension tests |
| `test:ci:admin-subs-action` | vitest extensions/admin-subs-action | Extension tests |
| `test:ci:thank-you-page` | vitest extensions/thank-you-page | Extension tests |
| `type-check` | tsc --project (multiple tsconfigs) | Multi-project type checking |
| `graphql-codegen` | graphql-codegen | GraphQL type generation |

### Entry Files
- **Framework**: Remix (`@remix-run/*`) v2.16.8 with Vite v6.3.5
- **Route config**: `app/routes.ts` - Uses `flatRoutes()` from `@remix-run/fs-routes`
- **Shopify app**: `app/shopify.server.ts` - `shopifyApp()` from `@shopify/shopify-app-remix/server`
- **DB**: `app/db.server.ts` - Prisma client singleton
- **Config**: `config/index.ts` + `config/types.ts` - Centralized configuration

### Build System
- **Monorepo workspace**: pnpm workspaces (includes extensions/*)
- **Package manager**: pnpm (uses pnpm-workspace.yaml)
- **GraphQL codegen**: Multi-project config (shopifyCustomerApi, adminSubsActionExtension)

---

## 2. Stack Technology

| Layer | Technology | Version | Source |
|-------|-----------|---------|--------|
| **Framework** | Remix (v2.16) + React Router 7 | 2.16.8 | package.json |
| **Build Tool** | Vite | 6.3.5 | package.json |
| **Package Mgr** | pnpm | workspace | pnpm-workspace.yaml |
| **ORM** | Prisma | 6.10.1 | package.json |
| **Database** | SQLite | file:./data.db | prisma/schema.prisma |
| **Session** | PrismaSessionStorage / MemorySessionStorage | 6.0.7 | deps |
| **Shopify API** | @shopify/shopify-api | 11.13.0 | package.json |
| **Shopify App** | @shopify/shopify-app-remix | 3.8.3 | package.json |
| **UI Framework** | @shopify/polaris | 13.9.5 | package.json |
| **UI Extensions** | @shopify/ui-extensions | 2025.7.0 | package.json |
| **State Mgmt** | i18next | <24.0.0 | package.json |
| **Validation** | zod | 3.25.67 | package.json |
| **GraphQL** | graphql | 16.11.0 (resolved 16.8.1) | package.json + resolutions |
| **Testing** | vitest + jest + @shopify/react-testing | 3.2.4 / 30.0.3 | package.json |
| **Logging** | pino | 9.7.0 | package.json |
| **Cloud Tasks** | @google-cloud/tasks | 6.1.0 | package.json |
| **Cloud Storage** | @google-cloud/storage | 7.16.0 | package.json |
| **JWT** | jsonwebtoken | 9.0.2 | package.json |
| **Lodash** | lodash | 4.17.21 | package.json |

---

## 3. Route Files (Map of /app/routes)

### App Routes (authenticated admin area)
| File | Purpose |
|------|---------|
| `app/routes/app/route.tsx` | Main app layout (authenticated) |
| `app/routes/app._index/route.tsx` | App dashboard |
| `app/routes/app.plans._index/route.tsx` | Selling plans list |
| `app/routes/app.plans.$id/route.tsx` | Plan details/edit |
| `app/routes/app.contracts._index/route.tsx` | Subscription contracts list |
| `app/routes/app.contracts.$id/route.tsx` | Contract details |
| `app/routes/app.contracts.$id.cancel/route.tsx` | Cancel contract |
| `app/routes/app.contracts.$id.edit/route.tsx` | Edit contract |
| `app/routes/app.contracts.$id.pause/route.tsx` | Pause contract |
| `app/routes/app.contracts.$id.resume/route.tsx` | Resume contract |
| `app/routes/app.contracts.$id.payment-update/route.tsx` | Update payment |
| `app/routes/app.contracts.$id.poll-bill-attempt/route.tsx` | Poll billing attempt |
| `app/routes/app.settings._index/route.tsx` | Settings page |
| `app/routes/maintenance._index/route.tsx` | Maintenance mode |
| `app/routes/missing-scopes._index/route.tsx` | Missing scopes handler |

### Auth Routes
| File | Purpose |
|------|---------|
| `app/routes/auth.$.jsx` | Catch-all auth (Remix convention) |
| `app/routes/auth.login/route.tsx` | Login page with error handling |

### Webhook Routes
| File | Webhook Topic | Purpose |
|------|--------------|---------|
| `app/routes/webhooks.app.uninstalled.tsx` | APP_UNINSTALLED | Session cleanup |
| `app/routes/webhooks.subscription_contracts.create.tsx` | subscription_contracts/create | Handle new contracts |
| `app/routes/webhooks.subscription_contracts.activate.tsx` | subscription_contracts/activate | Activate contracts |
| `app/routes/webhooks.subscription_contracts.cancel.tsx` | subscription_contracts/cancel | Cancel contracts |
| `app/routes/webhooks.subscription_contracts.pause.tsx` | subscription_contracts/pause | Pause contracts |
| `app/routes/webhooks.subscription_billing_cycles.skip.tsx` | subscription_billing_cycles/skip | Skip billing cycle |
| `app/routes/webhooks.subscription_billing_attempts.success.tsx` | subscription_billing_attempts/success | Dunning: success |
| `app/routes/webhooks.subscription_billing_attempts.failure.tsx` | subscription_billing_attempts/failure | Dunning: failure |
| `app/routes/webhooks.selling_plan_groups.create_or_update.tsx` | selling_plan_groups/create_or_update | Plan group sync |
| `app/routes/webhooks.customer_redact.ts` | CUSTOMERS_REDACT | GDPR compliance |
| `app/routes/webhooks.shop_redact.ts` | SHOP_REDACT | GDPR compliance |
| `app/routes/webhooks.cli.tsx` | (CLI) | CLI-specific webhooks |

### Other Routes
| File | Purpose |
|------|---------|
| `app/routes/internal.jobs.run.tsx` | Internal job runner (GCP Cloud Tasks trigger) |
| `app/routes/services.ping.tsx` | Health check endpoint |
| `app/routes/customerAccount.emails.ts` | Customer email handler |

### Extension Routes (in extensions/)
| Extension | Purpose |
|-----------|---------|
| `extensions/buyer-subscriptions/` | Buyer-facing subscription management (React) |
| `extensions/admin-subs-action/` | Admin purchase options extension |
| `extensions/order-action-extension/` | Order status subscription action |
| `extensions/pos-extension/` | POS integration |
| `extensions/thank-you-page/` | Thank you page subscription links |
| `extensions/theme-extension/` | Theme app block for chat bubble |

---

## 4. Service Layer (app/services/)

### Core Business Services
| File | Purpose |
|------|---------|
| `app/services/AfterAuthService.ts` | Post-authorization setup (billing schedule, settings metaobject) |
| `app/services/DunningService.ts` | Payment failure handling with retry logic |
| `app/services/FinalAttemptDunningService.ts` | Final dunning attempt before cancellation |
| `app/services/PenultimateAttemptDunningService.ts` | Penultimate dunning attempt |
| `app/services/RetryDunningService.ts` | Retry dunning attempt |
| `app/services/InventoryService.ts` | Inventory synchronization |
| `app/services/CustomerSendEmailService.ts` | Customer email notifications |
| `app/services/MerchantSendEmailService.ts` | Merchant email notifications |
| `app/services/MerchantSendSubscriptionInventoryEmailService.ts` | Inventory alert emails |
| `app/services/SendPaymentMethodUpdateEmailService.ts` | Payment method update emails |
| `app/services/SubscriptionBillingCycleEditService.ts` | Billing cycle editing |
| `app/services/SubscriptionContractCancelService.ts` | Contract cancellation |
| `app/services/SubscriptionContractPauseService.ts` | Contract pausing |
| `app/services/SubscriptionContractResumeService.ts` | Contract resumption |
| `app/services/BillingScheduleCalculatorService.ts` | Billing schedule calculation |
| `app/services/AddOrderTagsService.ts` | Order tagging |

---

## 5. Auth Model

### Shopify Admin OAuth 2.0
- **Framework**: @shopify/shopify-app-remix v3.8.3
- **API Version**: `ApiVersion.Unstable` (from shopify.server.ts)
- **Session Storage**: Configurable - PrismaSessionStorage or MemorySessionStorage (test only)
- **Distribution**: AppDistribution.AppStore
- **Auth Path Prefix**: `/auth`
- **Access Scopes** (from shopify.app.toml):
  - Customer: `customer_read_customers, customer_read_orders, customer_read_own_subscription_contracts, customer_write_customers, customer_write_own_subscription_contracts`
  - Store: `read_all_orders, read_locales, read_locations, read_themes, write_customer_payment_methods, write_customers, write_metaobject_definitions, write_metaobjects, write_orders, write_own_subscription_contracts, write_products, write_translations, read_analytics`

### Webhook Authentication
- Uses `authenticate.webhook(request)` from Shopify SDK
- Validates HMAC signature from Shopify webhook headers
- API version: `unstable` (in shopify.app.toml)

### Customer Auth
- **Framework**: @shopify/shopify-app-remix (Shopify API)
- **Session Storage**: PrismaSessionStorage
- **Flow**: Standard Shopify OAuth with embedded app strategy (`unstable_newEmbeddedAuthStrategy: true`)

---

## 6. Data Flow

### Request Flow (Authenticated Admin Route)
```
Request -> /app/*
  -> authenticate.admin() middleware (remix route)
  -> Shopify session validation (session token or cookie)
  -> Admin API client injected into loader/action context
  -> Business logic (services)
  -> Prisma DB queries
  -> Shopify Admin GraphQL API (mutations/queries)
  -> Response to client
```

### Webhook Flow
```
Webhook (POST /webhooks/...)
  -> authenticate.webhook(request) - validates HMAC
  -> Topic-specific handler
  -> Business service (e.g., DunningService for billing failure)
  -> Shopify Admin GraphQL mutations
  -> GCP Cloud Tasks (for async job scheduling)
  -> Prisma DB updates
```

### Dunning Flow (Payment Failure)
```
1. Webhook: subscription_billing_attempts/failure
  -> webhook handler (app/routes/webhooks.subscription_billing_attempts.failure.tsx)
  -> DunningService.run()
  -> Determines dunning step (retry/penultimate/final)
  -> If retry needed: schedules GCP Cloud Task
  -> Sends merchant email (pino logger)
  -> Updates Prisma DunningTracker
```

### Job Scheduling (GCP Cloud Tasks)
- Config: `config/jobs` with `CLOUD_TASKS` scheduler (production), `INLINE` (dev), `TEST` (test)
- Endpoint: `/internal/jobs/run` (POST) - internal job trigger
- Uses `@google-cloud/tasks` library

---

## 7. DB Layer (Prisma / SQLite)

### Schema Models (prisma/schema.prisma)
| Model | Fields | Description |
|-------|--------|-------------|
| Session | id, shop, state, isOnline, scope, expires, accessToken, ... | Shopify app sessions |
| BillingSchedule | id, shop (unique), hour, timezone, active, ... | Per-shop billing schedule |
| DunningTracker | id, shop, contractId, billingCycleIndex, failureReason, completedAt, completedReason | Dunning state tracking |

### Configuration (config/index.ts)
| Environment Mode | Scheduler | Session Storage | Logger |
|-----------------|-----------|-----------------|--------|
| production | INLINE | Prisma | {} (default) |
| development | INLINE | Prisma | pino-pretty (trace level) |
| test | TEST | Memory | silent |

---

## 8. Test Files

### Test Infrastructure
| File | Purpose |
|------|---------|
| `test/constants.ts` | Test constants (API keys, shop domains, GraphQL URLs) |
| `test/setup-test-env.ts` | Vitest setup with @testing-library, Shopify matchers |
| `test/test-utils.tsx` | React Testing Library utilities |
| `test/setup-graphql-matchers.ts` | Custom GraphQL test matchers |
| `test/setup-app-bridge.tsx` | App Bridge mocking |
| `test/setup-address-mocks.tsx` | Address field mocking |
| `test/setup-i18n.ts` | i18n test setup |
| `test/setup-valid-session.ts` | Valid session factory |

### Test Files by Location
- Service tests: `app/services/tests/*.test.ts` (14 test files)
- Route tests: `app/routes/tests/*.test.ts` (9 webhook/contract tests)
- Helper tests: `app/utils/helpers/tests/*.test.ts` (7 test files)
- Bulk operation tests: `app/utils/bulkOperations/tests/*.test.ts` (4 test files)
- Metaobject tests: `app/utils/metaobjects/tests/*.test.ts` (3 test files)
- App component tests: `app/routes/app/tests/app.test.tsx`
- Plan/selling plan tests: `app/routes/app.plans._index/tests/*.test.tsx`
- Extension tests: `extensions/*/src/**/tests/*.test.tsx`, `extensions/*/tests/`

---

## 9. Env Handling

### Test Constants (test/constants.ts)
| Variable | Value | Purpose |
|----------|-------|---------|
| API_SECRET_KEY | 'testApiSecretKey' | Test secret |
| API_KEY | 'testApiKey' | Test API key |
| APP_URL | 'https://my-test-app.myshopify.io' | Test app URL |
| SHOPIFY_HOST | 'totally-real-host.myshopify.io' | Test shop host |
| TEST_SHOP | 'test-shop.myshopify.com' | Test shop domain |
| SCOPE | 'testScope' | Test scope |

### Config (config/index.ts)
| Variable | Description |
|----------|-------------|
| NODE_ENV | Environment mode (development/test/production) |
| APP_GID | App global ID |
| SCOPES | Comma-separated Shopify scopes |
| SHOPIFY_API_KEY | Shopify API key |
| SHOPIFY_API_SECRET | Shopify API secret |
| SHOPIFY_APP_URL | Application URL |
| SHOP_CUSTOM_DOMAIN | Custom domain override |

### Shopify Config Files
- `shopify.app.toml`: application_url = "https://example.com", scopes, webhook version = "unstable"
- `shopify.web.toml`: webhooks_path = "/webhooks/cli", roles frontend+backend

---

## 10. Dependency Versions & CVE Check

### Production dependencies
| Package | Version | CVE Status |
|---------|--------|------------|
| @google-cloud/storage | 7.16.0 | Clean (OSV) |
| @google-cloud/tasks | 6.1.0 | - |
| @prisma/client | 6.10.1 | Clean (OSV) |
| @shopify/shopify-api | 11.13.0 | Clean (OSV) |
| @shopify/shopify-app-remix | 3.8.3 | Clean (OSV) |
| @shopify/polaris | 13.9.5 | - |
| @shopify/ui-extensions | 2025.7.0 | - |
| graphql | 16.11.0 (resolved 16.8.1) | - |
| jsonwebtoken | 9.0.2 | Clean (OSV) |
| zod | 3.25.67 | Clean (OSV) |

### Dependencies with CVEs
| Package | Version | CVE Status | Vulnerability |
|---------|--------|------------|---------------|
| lodash | 4.17.21 | **3 vulnerabilities** | GHSA-f23m-r3pf-42rh: Prototype pollution via _.unset/_.omit; GHSA-r5fr-rjxr-66jc: Code injection via _.template; GHSA-xxjr-mmjv-4gpg: Prototype pollution |
| diff | (not direct dep) | 1 vuln (in CLI) | GHSA-73rr-hh4g-fpgx: DoS in parsePatch and applyPatch |

Note: lodash 4.17.21 is the final release. Some CVEs may still flag it due to incomplete fixes in the prototype pollution vectors. Recommend replacing with a maintained alternative (e.g., just, radash, or lodash-es if available).

### Key Security Notes
- API version: `unstable` - uses unstable Shopify Admin GraphQL API (may break)
- Webhooks API version: `unstable` - not recommended for production
- Broad access scopes requested (customer_read, write_metaobjects, write_orders, etc.)
- `i18next`: `<24.0.0` - version range is very broad (may resolve to latest 23.x)
- `remix-i18next`: `<7.0.0` - broad version range
- `graphql`: 16.11.0 declared, but resolution pins to 16.8.1 (potential conflict)

---

## 11. Summary

| Aspect | Detail |
|--------|--------|
| Stack | Remix v2 + Vite + React + Prisma/SQLite + TypeScript |
| Entry Point | `app/entry.server.tsx` (via Remix), `app/shopify.server.ts` |
| Endpoint | 15+ webhook routes, authenticated `/app/*` routes, `/internal/jobs/run` |
| Auth Model | Shopify Admin OAuth 2.0 (embedded, unstable_newEmbeddedAuthStrategy) |
| Data Flow | Request → authenticate.admin() → Service layer → Prisma DB + Shopify Admin GraphQL API |
