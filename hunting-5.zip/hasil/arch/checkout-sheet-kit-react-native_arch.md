# Architecture Recon - checkout-sheet-kit-react-native

## Repository Info
- **Name:** Shopify/checkout-sheet-kit-react-native
- **Description:** Shopify's Checkout Sheet Kit for React Native - simplifying the process of adding checkout to your native apps.
- **Language:** TypeScript (with native iOS Swift + Android Java)
- **Default Branch:** main
- **Package Version:** 4.0.0 (`@shopify/checkout-sheet-kit`)
- **Stars:** 77 | **Forks:** 17
- **Created:** 2023-11-08 | **Updated:** 2026-08-04

---

## a) File Inventory

Git tree saved to: `/home/runner/work/hunting-5/hunting-5/hasil/trees/checkout-sheet-kit-react-native.json` and `.txt`
Total tracked files: 287

### Key File Listing
```
package.json                          # Root workspace package (private: true)
modules/@shopify/checkout-sheet-kit/  # Main library
  package.json                        # v4.0.0, published as @shopify/checkout-sheet-kit
  src/
    index.ts                          # Main class: ShopifyCheckoutSheet (present, preload, dismiss, invalidate)
    index.d.ts                        # Type definitions for public API
    context.tsx                       # React Context Provider + hook
    errors.d.ts                       # Error type definitions
    events.d.ts                       # Checkout event types
    pixels.d.ts                       # Web pixel event types
    components/
      AcceleratedCheckoutButtons.tsx  # Apple Pay + Shop Pay buttons component
      AcceleratedCheckoutButtons+Extensions.swift  # iOS extensions (not in src/)
    specs/
      NativeShopifyCheckoutSheetKit.ts   # TurboModule spec (all native methods)
      RCTAcceleratedCheckoutButtonsNativeComponent.ts
  ios/
    ShopifyCheckoutSheetKit.swift     # iOS native module (RCTShopifyCheckoutSheetKit)
    ShopifyCheckoutSheetKit+EventSerialization.swift
    ShopifyCheckoutSheetKit+Extensions.swift
    ShopifyCheckoutSheetKit-Bridging-Header.h
    ShopifyCheckoutSheetKit.mm
    AcceleratedCheckoutButtons.swift
    AcceleratedCheckoutButtons+Extensions.swift
  android/
    build.gradle                      # AGP 8.11.0, minSdk 23, compileSdk 36, targetSdk 35
    proguard-rules.pro
    src/main/AndroidManifest.xml      # package: com.shopify.reactnative.checkoutsheetkit
    src/main/AndroidManifestNew.xml   # namespace-aware manifest
    src/main/java/com/shopify/reactnative/checkoutsheetkit/
      ShopifyCheckoutSheetKitModule.java   # Main Android native module
      ShopifyCheckoutSheetKitPackage.java  # RN package registration
      CustomCheckoutEventProcessor.java    # Event processing
    gradle.properties                 # SHOPIFY_CHECKOUT_SDK_VERSION=3.6.0
  tests/
    index.test.ts
    context.test.tsx
    linking.test.ts
    AcceleratedCheckoutButtons.test.tsx
  RNShopifyCheckoutSheetKit.podspec   # iOS podspec, dep: ShopifyCheckoutSheetKit ~> 3.8.0

sample/                               # Full sample app
  .env.example                        # STOREFRONT_DOMAIN, ACCESS_TOKEN, etc.
  package.json                        # Sample app React Native app
  src/
    App.tsx
    src/auth/
      customerAccountManager.ts       # Customer Account API OAuth
      pkce.ts                         # PKCE challenge generation
      tokenStorage.ts                 # Secure token storage
      types.ts
    src/context/
      Auth.tsx                        # Auth context
      Config.tsx                      # Config context
  android/                            # Android sample app
    app/build.gradle
    app/src/main/AndroidManifest.template.xml
  ios/
    AppDelegate.swift
    ReactNative/Info.plist

scripts/
  ci.yml workflow references .github/actions/setup

.github/workflows/
  ci.yml, cla.yml, deprecate.yml, publish.yml, stale.yml
```

### Native Dependencies (iOS)
- `ShopifyCheckoutSheetKit` (CocoaPods) - `~> 3.8.0` (podspec)
- `ShopifyCheckoutSheetKit/AcceleratedCheckouts` - `~> 3.8.0`
- `React-Core`

### Native Dependencies (Android)
- `com.shopify:checkout-sheet-kit:3.6.0` (SHOPIFY_CHECKOUT_SDK_VERSION in gradle.properties)
- `com.fasterxml.jackson.core:jackson-databind:2.12.5`
- `com.facebook.react:react-native:+`

---

## b) Architecture Map

### Entry Point
- **`modules/@shopify/checkout-sheet-kit/src/index.ts`** - Exports `ShopifyCheckoutSheet` class
  - Constructor takes optional Configuration + Features
  - Methods: `present(checkoutUrl)`, `preload(checkoutUrl)`, `dismiss()`, `invalidate()`, `getConfig()`, `setConfig()`, `addEventListener()`, `removeEventListeners()`, `teardown()`
  - All methods delegate to `RNShopifyCheckoutSheetKit` TurboModule
  - Event handling via `NativeEventEmitter` listening to native events: `close`, `completed`, `error`, `pixel`
  - Geolocation request handling for Android (auto-request or custom callback)

### React Context
- **`modules/@shopify/checkout-sheet-kit/src/context.tsx`** - `ShopifyCheckoutSheetProvider`
  - Creates singleton `ShopifyCheckoutSheet` instance
  - Exposes context with all methods + `version`, `acceleratedCheckoutsAvailable`
  - Hook: `useShopifyCheckoutSheet()` throws error if used outside provider

### TurboModule Bridge
- **`modules/@shopify/checkout-sheet-kit/src/specs/NativeShopifyCheckoutSheetKit.ts`** - TypeScript spec
  - Interface extends `TurboModule`
  - Methods: present, preload, dismiss, invalidateCache, setConfig, getConfig
  - configureAcceleratedCheckouts (iOS only, returns boolean)
  - isAcceleratedCheckoutAvailable, isApplePayAvailable (iOS only)
  - initiateGeolocationRequest (Android only)
  - addListener, removeListeners (event listener registration)
  - getConstants: { version: string }
  - Registered via `TurboModuleRegistry.getEnforcing<Spec>('ShopifyCheckoutSheetKit')`

### iOS Native Module
- **`modules/@shopify/checkout-sheet-kit/ios/ShopifyCheckoutSheetKit.swift`** - `RCTShopifyCheckoutSheetKit: RCTEventEmitter, CheckoutDelegate`
  - Configures native `ShopifyCheckoutSheetKit` SDK with `.reactNative` platform
  - Event emission: `close`, `completed`, `error`, `pixel` via `sendEvent(withName:body:)`
  - Methods: present (CheckoutViewController), preload, dismiss, invalidateCache
  - Config: setConfig via native ShopifyCheckoutSheetKit.configuration object
  - Color scheme mapping: web_default→web, automatic→automatic, light→light, dark→dark
  - Accelerated checkouts: configures customer identity + Apple Pay merchant ID (iOS 16+)
  - Geolocation: iOS handles natively (no-op for initiateGeolocationRequest)

### Android Native Module
- **`modules/@shopify/checkout-sheet-kit/android/.../ShopifyCheckoutSheetKitModule.java`** - extends `NativeShopifyCheckoutSheetKitSpec`
  - Configures native `ShopifyCheckoutSheetKit` SDK with `.REACT_NATIVE` platform
  - Methods: present, preload, dismiss, invalidateCache, getConfig, setConfig
  - **All accelerated checkout methods return `false`** (not supported on Android)
  - Geolocation: emits `geolocationRequest` event, auto-handles permission if `handleGeolocationRequests` enabled
  - Color parsing: `parseColor()` - converts hex strings to native Color objects (NumberFormatException caught with warning)

### Accelerated Checkout Buttons Component
- **`modules/@shopify/checkout-sheet-kit/src/components/AcceleratedCheckoutButtons.tsx`**
  - Native component (React Native codegen)
  - Props: cartId or variantId, wallets array [ApplePay, ShopPay], applePayLabel, applePayStyle, cornerRadius, onComplete, onFail, onCancel, onRenderStateChange, onWebPixelEvent, onClickLink
  - Renders native Apple Pay + Shop Pay buttons
  - Event flow: native events → JS callbacks

### Sample App Auth Flow
- **`sample/src/auth/customerAccountManager.ts`** - OAuth flow for customer accounts
  - URLs: `https://shopify.com/authentication/{shopId}/oauth/authorize`, `https://shopify.com/authentication/{shopId}/oauth/token`, `https://shopify.com/authentication/{shopId}/logout`
  - Uses PKCE (`sample/src/auth/pkce.ts`) for OAuth security
  - Token storage: `sample/src/auth/tokenStorage.ts` (likely SecureStore)
- **`sample/src/context/Auth.tsx`** - Auth state management
- **`sample/src/context/Config.tsx`** - App configuration context

### Checkout Data Flow
1. App obtains `checkoutUrl` from Storefront GraphQL API
2. `shopifyCheckout.present(checkoutUrl)` → TurboModule.present → Native SDK presents CheckoutViewController (iOS) or CheckoutSheetKitDialog (Android)
3. Checkout events (close, completed, error, pixel) emitted via NativeEventEmitter back to JS
4. Preloading: `shopifyCheckout.preload(checkoutUrl)` → native SDK initializes checkout in background
5. Cache invalidation: `shopifyCheckout.invalidate()` clears preloaded checkout

### Web Pixel / Behavioral Data
- Pixel events relayed via `pixel` event listener
- Custom event data returned as JSON string (must be parsed by consumer)
- GDPR/consent responsibility lies with the app developer

### Checkout Lifecycle Events
| Event | Callback | Description |
|-------|----------|-------------|
| `close` | `() => void` | Checkout closed |
| `completed` | `(event: CheckoutCompletedEvent) => void` | Checkout completed |
| `error` | `(error: {message: string}) => void` | Checkout error |
| `pixel` | `(event: PixelEvent) => void` | Web pixel event |

### DB Layer
- **None** - This is a client-side UI library, no database persistence

### Env Handling
- **`sample/.env.example`** - Runtime env vars:
  - `STOREFRONT_DOMAIN` - Shopify store domain
  - `STOREFRONT_ACCESS_TOKEN` - Storefront API access token
  - `STOREFRONT_MERCHANT_IDENTIFIER` - Apple Pay merchant ID
  - `STOREFRONT_VERSION` = "2025-07" - Storefront API version
  - Customer account credentials (email, address, etc.)
  - `CUSTOMER_ACCOUNT_API_CLIENT_ID` and `CUSTOMER_ACCOUNT_API_SHOP_ID`
- Env loaded via `react-native-dotenv` (devDependencies include `@types/react-native-dotenv`)

### Test Files
- **Framework:** Jest 30.0.5 + React Native Testing Library 13.3.1
- **Test files:**
  - `modules/@shopify/checkout-sheet-kit/tests/index.test.ts` - Main module tests
  - `modules/@shopify/checkout-sheet-kit/tests/context.test.tsx` - Context provider tests
  - `modules/@shopify/checkout-sheet-kit/tests/linking.test.ts` - Deep link handling
  - `modules/@shopify/checkout-sheet-kit/tests/AcceleratedCheckoutButtons.test.tsx` - Native component tests
  - `sample/src/auth/__tests__/CustomerAccountManager.test.ts` - Auth manager tests
  - `sample/src/auth/__tests__/PKCE.test.ts` - PKCE tests
  - `sample/android/app/src/test/java/.../ShopifyCheckoutSheetKitModuleTest.java` - Android unit test
- **Mock:** `__mocks__/react-native-config.ts` - mocks react-native-config for env vars

---

## d) Dependency Versions + CVE Check

### npm Dependencies (root package.json)
| Dependency | Version | CVE Status |
|---|---|---|
| **react** | 19.1.0 | React 19 - monitor for any CVEs |
| **react-native** | 0.80.2 | RN 0.80.2 - check for native security fixes |
| **@react-native-community/cli** | 19.1.1 | CLI tooling |
| **@react-native/babel-preset** | 0.80.2 | Build tooling |
| **@react-native/metro-config** | 0.80.2 | Metro bundler |
| **typescript** | 5.9.2 | TS 5.x - monitor |
| **jest** | 30.0.5 | Testing framework |
| **eslint** | 8.57.1 | Linter |
| **prettier** | 3.2.5 | Formatter |

### Package Module Dependencies (@shopify/checkout-sheet-kit)
| Dependency | Version |
|---|---|
| **typescript** | ^5.9.2 |
| **react-native-builder-bob** | ^0.23.2 |

### Peer Dependencies
| Dependency | Version |
|---|---|
| **react** | * |
| **react-native** | * |

### Android Native Dependencies
| Dependency | Version | CVE Status |
|---|---|---|
| **com.shopify:checkout-sheet-kit** | 3.6.0 | Native SDK from Shopify |
| **com.fasterxml.jackson.core:jackson-databind** | 2.12.5 | **CVE-2022-42003** (RCE via deserialization), **CVE-2022-42003**, **CVE-2017-17485**, **CVE-2018-12019**, **CVE-2019-10091**, **CVE-2020-9576** - Jackson 2.12.5 is **VULNERABLE** to multiple CVEs. Recommend upgrade to >= 2.13.4 or latest 2.15.x+ |
| **com.android.tools.build:gradle** | 8.11.0 | AGP - monitor |
| **Android Gradle Plugin** | 8.11.0 | Monitor for security patches |

### iOS Native Dependencies
| Dependency | Version | CVE Status |
|---|---|---|
| **ShopifyCheckoutSheetKit** | ~> 3.8.0 | Native SDK |
| **ShopifyCheckoutSheetKit/AcceleratedCheckouts** | ~> 3.8.0 | Native SDK |
| **React-Core** | (auto-resolved) | React Native core |

### Build Configuration
- **Android:** minSdk 23, compileSdk 36, targetSdk 35, AGP 8.11.0, NDK 23.1.7779620
- **iOS:** platform 13.0, CocoaPods
- **Node:** `>= 22.14.0` (packageManager: pnpm@10.33.1)

### CVE Risk Summary
1. **jackson-databind 2.12.5** - **HIGH RISK**: Multiple known CVEs including RCE via deserialization (CVE-2022-42003). This is the most critical finding. Should upgrade to >= 2.15.2.
2. **React Native 0.80.2** - Recent release, monitor for patch updates
3. **No version pinning for native SDK** in gradle.properties uses variable `SHOPIFY_CHECKOUT_SDK_VERSION=3.6.0` - ensure staying updated
4. **Node 22.14.0** - Ensure OpenSSL 3 compatibility (Node 17+ has breaking changes)

---

## e) Summary Output

**Stack:** TypeScript 5.9.2 | React Native 0.80.2 | React 19.1.0 | iOS Swift + Android Java (Native Modules via TurboModules) | Jest 30.0.5

**Endpoints:**
- `https://{storefront_domain}.myshopify.com/api/{version}/graphql.json` (Storefront GraphQL API)
- `https://shopify.com/authentication/{shopId}/oauth/authorize` (Customer Account API - sample app)
- `https://shopify.com/authentication/{shopId}/oauth/token` (Customer Account API - sample app)
- Checkout URL (web checkout URL passed as parameter, e.g. `https://{shop}.myshopify.com/...`)

**Auth Model:** 
- Storefront API: Anonymous (Storefront Access Token) or Customer Account API (OAuth 2.0 with PKCE)
- No server-side auth in library itself - auth handled by host app
- Checkout URLs obtained externally via Storefront GraphQL API
- Apple Pay (requires merchant identifier + certificates)
- Shop Pay (wallet preference in cart buyer identity)

**Data Flow:**
1. Host app obtains `checkoutUrl` from Storefront GraphQL API (Apollo Client example in README)
2. `ShopifyCheckoutSheetProvider` creates `ShopifyCheckoutSheet` instance wrapping TurboModule
3. `shopifyCheckout.present(checkoutUrl)` → JS → TurboModule → Native SDK → presents CheckoutViewController (iOS) / CheckoutSheetKitDialog (Android)
4. Native checkout events (close, completed, error, pixel) → NativeEventEmitter → JS event listeners
5. `preload(checkoutUrl)` → background init of checkout session (performance optimization)
6. `invalidate()` → clears preload cache
7. Accelerated checkouts (iOS 16+): `configureAcceleratedCheckouts()` with storefront domain, access token, customer identity, Apple Pay merchant config
8. Geolocation (Android): native module emits `geolocationRequest` event → JS handles permission → calls `initiateGeolocationRequest(allow)`

**Configuration:**
- `colorScheme`: automatic | light | dark | web
- `preloading`: boolean (default true)
- `logLevel`: debug | error
- `colors`: iOS and Android separate color overrides
- `title`: Custom checkout sheet title (iOS only)
- `acceleratedCheckouts`: Storefront domain + access token + customer identity + Apple Pay config

**Key Risks:**
1. `jackson-databind:2.12.5` on Android - multiple CVEs including RCE
2. No upper version bounds on React/React Native peer deps
3. Geolocation permission handling on Android (user consent required)
4. Pixel events may include behavioral data - GDPR/consent responsibility on app developer
