# Architecture Analysis - hydrogen

**Repo**: https://github.com/Shopify/hydrogen
**Branch**: main
**Total Files**: 1,622
**Last Analyzed**: $(date -u +"%Y-%m-%d %H:%M:%S UTC")

---

## 1. Entry Point & Bootstrapping

### Root package.json scripts
| Script | Command | Description |
|--------|---------|-------------|
| `dev` | `pnpm run dev:pkg` | Start all packages in dev mode |
| `build` | `pnpm run build:pkg` | Build all packages |
| `test` | `turbo run test --parallel` | Run all tests |
| `e2e` | `playwright test` | E2E tests |
| `ci:checks` | `turbo run lint test format:check typecheck` | CI checks |
| `version` | Changeset-based calver versioning | Release process |

### Package Workspace Structure (pnpm monorepo)
| Package | Path | Version | Description |
|---------|------|--------|-------------|
| @shopify/hydrogen | packages/hydrogen | 2026.4.4 | Core library (storefront client, cart, customer, CSP, SEO) |
| @shopify/hydrogen-react | packages/hydrogen-react | - | React components (Cart, Product, etc.) |
| @shopify/cli-hydrogen | packages/cli | 13.0.3 | Shopify CLI extension for Hydrogen |
| @shopify/create-hydrogen | packages/create-hydrogen | - | App generation CLI |
| @shopify/hydrogen-codegen | packages/hydrogen-codegen | - | GraphQL type generation |
| @shopify/mini-oxygen | packages/mini-oxygen | - | Local runtime for Hydrogen apps |
| @shopify/remix-oxygen | packages/remix-oxygen | - | Remix adapter for Oxygen |
| skeleton (template) | templates/skeleton | 2026.4.5 | Default app scaffold |

### Entry Points
- **Skeleton template server**: `templates/skeleton/server.ts` - Cloudflare Worker fetch handler
- **Skeleton context**: `templates/skeleton/app/lib/context.ts` - `createHydrogenRouterContext()`
- **Core handler**: `packages/hydrogen/src/createRequestHandler.ts` - Wraps React Router, forwards SFAPI & MCP
- **Context factory**: `packages/hydrogen/src/createHydrogenContext.ts` - Creates storefront, customerAccount, cart
- **CLI entry**: `packages/cli/src/index.ts` - Oclif command registration

### CLI Commands (packages/cli/src/commands/hydrogen/)
| Command | File | Purpose |
|---------|------|---------|
| hydrogen init | init.ts | Initialize new project |
| hydrogen dev | dev.ts | Development server |
| hydrogen build | build.ts | Production build |
| hydrogen deploy | deploy.ts | Deploy to Oxygen |
| hydrogen codegen | codegen.ts | GraphQL type generation |
| hydrogen env pull | env/pull.ts | Pull env vars from store |
| hydrogen env push | env/push.ts | Push env vars to store |
| hydrogen env list | env/list.ts | List env vars |
| hydrogen link | link.ts | Link to Shopify store |
| hydrogen unlink | unlink.ts | Unlink from Shopify |
| hydrogen login | login.ts | Login to Shopify |
| hydrogen setup | setup.ts | Scaffold CSS, routes, markets |
| hydrogen generate route | generate/route.ts | Generate new routes |
| hydrogen debug | debug/* | Debugging utilities (cpu, etc.) |

---

## 2. Stack Technology

| Layer | Technology | Version | Source |
|-------|-----------|---------|--------|
| Framework | React Router 7 | 7.16.0 | package.json |
| Runtime | Node.js / Cloudflare Workers | ^22 || ^24 | package.json engines |
| Package Mgr | pnpm | 10.16.1 | package.json |
| Build Orchestration | Turbo | 2.8.9 | package.json |
| Build Tool | Vite | ^5.1-8.0 (peer) | package.json |
| Bundler | tsup | 8.4.0 | devDeps |
| TypeScript | TypeScript | 5.9.2 | package.json |
| React | React | 18.3.1 | package.json |
| Mini Oxygen | Custom runtime | - | packages/mini-oxygen |
| CLI Framework | Oclif | 3.26.5 | packages/cli deps |
| CLI Kit | @shopify/cli-kit | ^3.80.4 | packages/cli deps |
| Oxygen CLI | @shopify/oxygen-cli | 4.6.18 | packages/cli deps |
| Testing | vitest + Playwright | 3.2.4 / ^1.57.0 | package.json |
| CSS | CSS / Vanilla Extract / Tailwind | - | templates/skeleton |
| GraphQL | graphql | ^16.12.0 | packages/hydrogen deps |
| GraphQL Codegen | @graphql-codegen/cli | 5.0.7 | devDeps |
| GraphQL Client | @shopify/graphql-client | 1.4.1 | packages/hydrogen deps |
| esbuild (bundler) | esbuild | ^0.27.0 | packages/cli deps |

---

## 3. Route Files

### Skeleton Template Routes (templates/skeleton/app/routes.ts)
| Route | Purpose |
|-------|---------|
| / | Home page with featured products |
| /products.$handle | Product detail page |
| /collections.$handle._index | Collection listing |
| /collections.all | All collections |
| /cart | Cart page |
| /cart.$lines | Cart with line items |
| /blogs.$blogHandle._index | Blog article list |
| /blogs.$blogHandle.$articleHandle | Blog article |
| /pages.$handle | Page |
| /policies.$handle | Policy page |
| /search | Search |
| /discount.$code | Discount redirect |
| /sitemap.$type.$page.xml | Sitemap |
| /[robots.txt] | Robots |
| /[sitemap.xml] | Sitemap index |
| /account | User account dashboard |
| /account.addresses | Address management |
| /account.orders.$id | Order detail |
| /account.profile | Profile |
| /account_.login | Login |
| /account_.logout | Logout |
| /account_.authorize | OAuth callback |
| /$.tsx | Catch-all 404 handler |

### Dev-Only Virtual Routes (packages/hydrogen/src/vite/virtual-routes)
| Route | Purpose |
|-------|---------|
| /graphiql | GraphiQL IDE (dev only) |
| /subrequest-profiler | Subrequest profiling |
| /well-known/appspecific.com.chrome.devtools.json | Chrome DevTools well-known |

---

## 4. Service Layer

### Core Services (packages/hydrogen/src/)
| File | Purpose |
|------|---------|
| createRequestHandler.ts | Main request handler - wraps React Router, proxies Storefront API & MCP |
| createHydrogenContext.ts | Context factory - creates storefront, customerAccount, cart clients |
| storefront.ts | Storefront client - GraphQL query/mutate, SFAPI proxy, MCP forwarding, caching |
| customer/customer.ts | Customer Account API client - OAuth login/authorize/logout, GraphQL |
| customer/auth.helpers.ts | PKCE helpers, token exchange/refresh, nonce validation, JWT decode |
| customer/customer-account-helper.ts | Customer Account URL construction (shopify.com/{shopId}) |
| cart/createCartHandler.ts | Cart CRUD via Storefront API |
| cache/strategies.ts | Cache strategies (None, Short, Long, Custom) |
| cache/in-memory.ts | In-memory cache implementation |
| csp/csp.ts | Content Security Policy generation |
| seo/generate-seo-tags.ts | SEO tag generation |
| sitemap/sitemap.ts | Sitemap generation |
| analytics-manager/AnalyticsProvider.tsx | Analytics event management |
| pagination/Pagination.ts | Pagination utilities |
| routing/redirect.ts | Storefront URL redirect (404 fallback) |
| routing/graphiql.ts | GraphiQL dev tool |
| utils/graphql.ts | GraphQL utilities (minifyQuery, assertQuery, etc.) |
| utils/request.ts | Request utilities (SFAPI_RE, MCP_RE regex patterns) |
| context-keys.ts | React context keys for hybrid access pattern |
| utils/callsites.ts | Stack trace utilities |
| utils/server-timing.ts | Server-Timing header utils |
| utils/uuid.ts | UUID generation (crypto.randomUUID) |
| utils/hash.ts | Hashing utilities |

### Vite Plugin & Middleware
| File | Purpose |
|------|---------|
| src/vite/plugin.ts | Vite plugin for Hydrogen (routes, middleware, dev tools) |
| src/vite/hydrogen-middleware.ts | Middleware for dev server |
| src/vite/virtual-routes/ | Dev-only virtual routes (GraphiQL, profiler, devtools JSON) |
| src/vite/request-events.ts | Request event types |

### CLI Services (packages/cli/src/lib/)
| File | Purpose |
|------|---------|
| lib/auth.ts | CLI authentication - Business Platform + Admin API auth |
| lib/graphql/admin/client.ts | Admin GraphQL client |
| lib/shopify-config.ts | Shopify config management (.shopify/project.json) |
| lib/graphql/admin/list-environments.ts | List storefront environments |
| lib/graphql/admin/pull-variables.ts | Pull env variables from store |
| lib/graphql/admin/push-variables.ts | Push env variables to store |
| lib/graphql/admin/create-storefront.ts | Create storefront |
| lib/graphql/admin/link-storefront.ts | Link storefront |
| lib/graphql/admin/fetch-job.ts | Fetch job status |
| lib/graphql/business-platform/user-account.ts | Business platform user account |
| lib/onboarding/ | Onboarding flows (local, remote) |
| lib/template-downloader.ts | Template download |
| lib/template-pack.ts | Template pack management |
| lib/package-managers.ts | Package manager detection |
| lib/environment-variables.ts | Env var validation |
| lib/flags.ts | CLI flag definitions |
| lib/shell.ts | Shell command execution |
| lib/log.ts | Logging |

---

## 5. Auth Model

### Shopify CLI Auth (packages/cli/src/lib/auth.ts)
- **Business Platform Auth**: `ensureAuthenticatedBusinessPlatform()` - for CLI user auth
- **Admin API Auth**: `ensureAuthenticatedAdmin(shop)` - for store-level operations
- **Session Storage**: Local config in `.shopify/project.json` (shop, email, storefront info)
- **User Account**: `getUserAccount(token)` - fetches active shops from Business Platform API

### Customer Account API Auth (packages/hydrogen/src/customer/)
- **Framework**: First-party `createCustomerAccountClient()`
- **OAuth 2.0 + PKCE**: Full PKCE flow (S256 code challenge)
- **Token Exchange**: Two-step: auth code → access_token → customer-specific token via `urn:ietf:params:oauth:grant-type:token-exchange`
- **Token Refresh**: Automatic refresh via `refresh_token` grant type
- **URLs**: Constructed from shopId:
  - Base: `https://shopify.com/{shopId}`
  - Auth: `https://shopify.com/authentication/{shopId}`
  - GraphQL: `https://shopify.com/{shopId}/account/customer/api/{version}/graphql`
- **Session**: Customer Account session stored in `CUSTOMER_ACCOUNT_SESSION_KEY`
- **Scope**: `openid email customer-account-api:full`

### App Proxy / Storefront API Auth
- **Storefront API**: Token-based via `X-Shopify-Storefront-Access-Token` header
- **MCP**: Server-to-server only (no CORS preflight, OPTIONS returns 404)

### Tunnel Domain Requirement (Dev Only)
- Customer Account API OAuth requires `.tryhydrogen.dev` tunnel domain in development
- Custom domains allowed with `useCustomAuthDomain` flag

---

## 6. Data Flow

### HTTP Request Flow (Production - Cloudflare Worker/Oxygen)
```
Worker.fetch(request) [server.ts]
  -> createHydrogenRouterContext(request, env, ctx)
    -> createHydrogenContext()
      -> createStorefrontClient() (Storefront API client)
      -> createCustomerAccountClient() (Customer Account API client)
      -> createCartHandler() (Cart handler)
  -> createRequestHandler({build, getLoadContext: () => hydrogenContext})
    -> Checks if request matches Storefront API URL (/api/{version}/graphql.json)
      -> FORWARDS to Storefront API (proxy)
    -> Checks if request matches MCP URL (/api/mcp)
      -> FORWARDS to Storefront MCP endpoint
    -> Otherwise: delegates to React Router
      -> Route loader/action executes
      -> Can access context.storefront, context.customerAccount, context.cart, etc.
  -> Response returned (with collected subrequest headers, server-timing, etc.)
```

### Customer Account Login Flow
```
1. Browser navigates to /account_.authorize
2. customerAccount.authorize() called
3. Checks code + state params in URL
4. Validates state matches session
5. POST to token endpoint with grant_type=authorization_code + code_verifier (PKCE)
6. Receives access_token + id_token + refresh_token from CAA
7. If shopId present: token exchange (urn:ietf:params:oauth:grant-type:token-exchange)
8. Stores tokens in session (CUSTOMER_ACCOUNT_SESSION_KEY)
9. Validates nonce from id_token
10. Redirects to account page
```

### Subrequest / SFAPI Proxy Flow
```
Browser -> App (e.g., /products/handle)
  -> Loader calls context.storefront.query()
  -> Fetch to Storefront API with headers (X-Shopify-Storefront-Access-Token, etc.)
  -> Server-Timing headers propagate _y (unique token) and _s (visit token)
  -> Cookies collected from SFAPI response
  -> Set-Cookie headers forwarded to browser on document response
```

---

## 7. Env Handling

### Skeleton Template .env
| Variable | Example | Description |
|----------|---------|-------------|
| SESSION_SECRET | foobar | Session encryption secret |
| PUBLIC_STOREFRONT_ID | - | Storefront ID for API |
| PUBLIC_STORE_DOMAIN | - | Shop domain |
| PUBLIC_STOREFRONT_API_TOKEN | - | Storefront API token |
| PUBLIC_CUSTOMER_ACCOUNT_API_CLIENT_ID | - | CA API client ID |
| PUBLIC_CUSTOMER_ACCOUNT_API_URL | - | CA API base URL |
| SHOP_ID | - | Shop global ID |

### E2E Test Env Files (e2e/envs/)
| File | Purpose |
|------|---------|
| .env.mockShop | Mock shop for testing (mock.shop) |
| .env.customerAccount | Customer Account test store |
| .env.hydrogenPreviewStorefront | Preview storefront config |
| .env.defaultConsentAllowed_cookiesDisabled | Consent tests (allowed, cookies disabled) |
| .env.defaultConsentAllowed_cookiesEnabled | Consent tests (allowed, cookies enabled) |
| .env.defaultConsentDisallowed_cookiesDisabled | Consent tests (disallowed, cookies disabled) |
| .env.defaultConsentDisallowed_cookiesEnabled | Consent tests (disallowed, cookies enabled) |

---

## 8. Test Files

### E2E Test Structure (e2e/)
| Directory/File | Purpose |
|----------------|---------|
| e2e/envs/ | Environment variable files for different test scenarios |
| e2e/fixtures/ | Shared test fixtures (storefront, cart, customer account, etc.) |
| e2e/fixtures/msw/ | Mock Service Worker (msw) for intercepting network requests |
| e2e/specs/smoke/ | Basic smoke tests (cart, account, home, pages) |
| e2e/specs/recipes/ | Recipe-specific tests (b2b, bundles, subscriptions, etc.) |
| e2e/specs/new-cookies/ | Cookie consent tests (new cookie system) |
| e2e/specs/old-cookies/ | Cookie consent tests (old cookie system) |
| e2e/specs/skeleton/ | Skeleton template default route tests |
| e2e/types/ | TypeScript type definitions |

### Unit Test Structure (packages/*/)
| Package | Test Files | Runner |
|---------|-----------|--------|
| hydrogen | packages/hydrogen/src/**/*.test.ts(x) | vitest |
| hydrogen-react | packages/hydrogen-react/src/**/*.test.tsx | vitest |
| cli | packages/cli/src/**/*.test.ts(x) | vitest |
| codegen | packages/hydrogen-codegen/tests/*.test.ts | vitest |
| mini-oxygen | packages/mini-oxygen/**/*.test.ts | vitest + e2e.test.ts |

---

## 9. Dependency Versions & CVE Check

### Root package.json
| Package | Version | CVE Status |
|---------|--------|------------|
| react / react-dom | 18.3.1 | - |
| react-router / react-router-dom | 7.16.0 | **5 vulnerabilities** |
| @shopify/cli | 3.93.2 | Clean (OSV) |
| turbo | 2.8.9 | - |
| typescript | 5.9.2 | - |
| eslint | 9.19.0 | - |
| esbuild | ^0.27.0 | Clean (OSV) |
| @playwright/test | ^1.57.0 | - |
| msw | ^2.12.10 | - |

### @shopify/hydrogen package
| Package | Version | CVE Status |
|---------|--------|------------|
| @shopify/hydrogen-react | workspace:* | - |
| @shopify/graphql-client | 1.4.1 | - |
| worktop | ^0.7.3 | Clean (OSV), but unmaintained |
| content-security-policy-builder | ^2.2.0 | Clean (OSV) |
| flame-chart-js | 2.3.1 | - |
| isbot | ^5.1.21 | - |
| source-map-support | ^0.5.21 | - |
| type-fest | ^4.33.0 | - |
| use-resize-observer | ^9.1.0 | - |
| graphql (dev) | ^16.12.0 | - |

### @shopify/cli-hydrogen (packages/cli)
| Package | Version | CVE Status |
|---------|--------|------------|
| @oclif/core | 3.26.5 | Clean (OSV) |
| @shopify/cli-kit | ^3.80.4 | - |
| @shopify/oxygen-cli | 4.6.18 | Clean (OSV) |
| @shopify/plugin-cloudflare | ^3.78.1 | - |
| chokidar | 3.5.3 | - |
| diff | ^5.1.0 | **GHSA-73rr-hh4g-fpgx** - DoS in parsePatch/applyPatch |
| esbuild | ^0.27.0 | Clean (OSV) |
| get-port | ^7.0.0 | - |
| semver | ^7.7.1 | - |
| source-map-support | ^0.5.21 | - |
| tar-fs | ^2.1.1 | - |
| ts-morph | 20.0.0 | Clean (OSV) |

### react-router 7.16.0 - 5 vulnerabilities
| CVE | Summary | Severity |
|-----|---------|----------|
| GHSA-337j-9hxr-rhxg | React Router: Arbitrary Constructor Injection via deserializeErrors() in SSR Hydration | - |
| GHSA-chx6-hx7r-mcp5 | React Router: Unauthenticated DoS via Inefficient Route Matching | - |
| GHSA-h8fp-f39c-q6mh | React Router: RSCErrorHandler Missing Protocol Validation (XSS) | - |
| GHSA-qwww-vcr4-c8h2 | React Router: RSC Mode CSRF Bypass Allows Action Execution Before 400 Response | - |
| GHSA-wrjc-x8rr-h8h6 | React Router: Open redirect via backslash in <Link> and useNavigate (CVE-2025-68470 bypass) | - |

Note: The root package.json declares react-router 7.16.0, but the skeleton template also uses 7.16.0. These CVEs affect React Router 7.x up to certain patch versions. Recommend upgrading to latest 7.x patch.

### Key Security Findings
1. **MEDIUM-HIGH**: react-router 7.16.0 has 5 known vulnerabilities including SSR constructor injection, DoS, XSS, CSRF bypass, and open redirect
2. **LOW**: diff 5.1.0 has DoS vulnerability (GHSA-73rr-hh4g-fpgx) in parsePatch/applyPatch (likely transitive via CLI tooling)
3. **INFO**: worktop 0.7.3 is unmaintained (last published 2020) - potential supply chain risk
4. **INFO**: ejson secrets.ejson file present in repo root (requires decryption with secrets.ejson)
5. **INFO**: Mini Oxygen Worker runtime exposes devtools inspector (packages/mini-oxygen/src/worker/inspector.ts)

---

## 10. Summary

| Aspect | Detail |
|--------|--------|
| Stack | React Router 7 + Vite + TypeScript + pnpm monorepo |
| Entry Point | templates/skeleton/server.ts (Cloudflare Worker / Oxygen) |
| Endpoint | /api/{version}/graphql.json (SFAPI proxy), /api/mcp (MCP proxy), /account/* (customer auth) |
| Auth Model | Shopify CLI Business Platform auth + PKCE/OAuth2 for Customer Account API |
| Data Flow | Worker fetch -> createHydrogenContext -> createRequestHandler -> React Router or SFAPI/MCP proxy |
