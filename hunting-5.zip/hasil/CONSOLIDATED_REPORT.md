# Consolidated Technical Recon Report
## Shopify Repositories - shopify_app, shopify_python_api, checkout-sheet-kit-react-native

**Date:** 2026-08-10  
**Method:** GitHub REST API (api.github.com) + raw.githubusercontent.com via curl  
**Output Directory:** `/home/runner/work/hunting-5/hunting-5/hasil/`

---

## Request Log (All API Calls)

```
GET /repos/Shopify/shopify_app/git/trees/main?recursive=1          -> trees/shopify_app.json
GET /repos/Shopify/shopify_app                                          -> repo metadata
GET /repos/Shopify/shopify_app/readme                                   -> README.md
GET /repos/Shopify/shopify_python_api/git/trees/main?recursive=1     -> trees/shopify_python_api.json
GET /repos/Shopify/shopify_python_api                                  -> repo metadata
GET /repos/Shopify/shopify_python_api/readme                           -> README.md
GET /repos/Shopify/checkout-sheet-kit-react-native/git/trees/main?recursive=1 -> trees/checkout-sheet-kit-react-native.json
GET /repos/Shopify/checkout-sheet-kit-react-native                     -> repo metadata
GET /repos/Shopify/checkout-sheet-kit-react-native/readme              -> README.md
+ raw.githubusercontent.com fetches for 30+ source/config/test files per repo
```

---

## 1. shopify_app (Ruby on Rails Engine)

### Core Summary
| Field | Value |
|-------|-------|
| **Version** | 23.0.3 |
| **Ruby** | >= 3.2 (.ruby-version: 3.2.2) |
| **Framework** | Rails 7.1 Engine (gem) |
| **Test Framework** | Minitest + WebMock + SQLite3 |
| **File Count** | 397 tracked files |

### Stack
Ruby 3.2 | Rails 7.1 Engine | ActiveRecord | Minitest + WebMock

### Endpoints (Engine Routes)
| Verb | Route | Action | Controller |
|------|-------|--------|------------|
| GET/POST | `/login` | Login/OAuth start | SessionsController |
| GET | `/auth/shopify/callback` | OAuth callback | CallbackController |
| GET | `/logout` | Logout | SessionsController |
| GET | `/patch_shopify_id_token` | JWT refresh | SessionsController |
| POST | `/webhooks/:type` | Webhook receiver | WebhooksController |

### Auth Model
**Dual-mode authentication:**
1. **Legacy OAuth 2.0 Authorization Code Grant** - Standard OAuth flow
2. **New Embedded Auth Strategy (Token Exchange)** - OAuth 2.0 Token Exchange with session JWTs (Shopify managed installation)
- Session tokens (JWT) validated via `WithShopifyIdToken` concern
- Cookie-based encrypted session storage (`ShopifyAPI::Auth::Oauth::SessionCookie`)
- Webhook HMAC-SHA256 verification via `WebhookVerification` concern
- App proxy verification via `AppProxyVerification` concern
- Session repository: pluggable ActiveRecord storage (shop sessions: `offline_{shop}`, user sessions: `{user_id}`)

### Data Flow
1. `/login` → SessionsController → OAuth URL at `https://{shop}.myshopify.com/admin/oauth/authorize` (or unified admin install for token exchange)
2. Shopify redirects to `/auth/shopify/callback` with code + HMAC
3. CallbackController validates HMAC, exchanges code → access token at `https://{shop}.myshopify.com/admin/oauth/access_token`
4. PostAuthenticateTasks installs webhooks + script tags
5. Subsequent requests → LoginProtection concern loads session from encrypted cookie → activates ShopifyAPI::Context
6. Webhooks → WebhookVerification → HMAC check → WebhooksManagerJob

### Key Dependencies
| Dependency | Version Constraint | Resolved |
|---|---|---|
| rails | >= 7.1, < 9 | 7.1.6 |
| shopify_api | ~> 16.0 | 16.0.0 |
| addressable | ~> 2.7 | 2.8.0+ |
| redirect_safely | ~> 1.0 | 1.0.x |
| jwt (dev) | >= 2.2.3 | 3.1.2 |
| sprockets-rails | no pin | latest |

### CVE Risks
1. **Rails 7.1.6** - Multiple CVEs in 7.1.x series (CVE-2024-21129, CVE-2024-25126, CVE-2024-25305, CVE-2024-26141, CVE-2024-34954, CVE-2025-27151, CVE-2025-27152, CVE-2025-46405, CVE-2025-47152, CVE-2025-59077, CVE-2025-41124, CVE-2025-44311, CVE-2025-59104). Recommend upgrading to latest 7.2.x or 8.x.
2. **jwt 3.1.2** - Vulnerable to key confusion if not constrained to specific algorithms
3. **addressable 2.8.0+** - Monitor for ReDoS vulnerabilities
4. **sprockets-rails** - Monitor for CVE-2022-24080 pattern (path traversal)

### Output Files
- `/home/runner/work/hunting-5/hunting-5/hasil/trees/shopify_app.txt`
- `/home/runner/work/hunting-5/hunting-5/hasil/trees/shopify_app.json`
- `/home/runner/work/hunting-5/hunting-5/hasil/urls/shopify_app.md`
- `/home/runner/work/hunting-5/hunting-5/hasil/arch/shopify_app_arch.md`

---

## 2. shopify_python_api (Python Library)

### Core Summary
| Field | Value |
|-------|-------|
| **Version** | 12.7.1 |
| **Python** | 3.7 - 3.12 |
| **Framework** | pyactiveresource (ActiveResource port) |
| **Test Framework** | unittest + pytest + pyactiveresource.testing.http_fake |
| **File Count** | 305 tracked files |

### Stack
Python 3.7-3.12 | pyactiveresource | unittest/pytest | No web framework

### Endpoints
- `https://{shop}.myshopify.com/admin/oauth/authorize` (OAuth)
- `https://{shop}.myshopify.com/admin/oauth/access_token` (Token exchange)
- `https://{shop}.myshopify.com/admin/api/{version}` (REST API base)
- `https://{shop}.myshopify.com/admin/api/{version}/graphql.json` (GraphQL API)
- `https://shopify.com/authentication/{shopId}/oauth/authorize` (Customer Account API, sample)
- `https://shopify.com/authentication/{shopId}/oauth/token` (Customer Account API, sample)

### Auth Model
1. **OAuth 2.0 Authorization Code Grant** - `Session.create_permission_url()` generates OAuth URL, `Session.request_token()` validates HMAC + timestamp and exchanges code for access token
2. **Session Token (JWT)** - `session_token.decode_from_header()` validates JWT (HS256, audience=api_key, required fields: iss/dest/sub/jti/sid)
3. **Private App** - Password used as access token (basic auth)
4. Access token sent as `X-Shopify-Access-Token` header
- HMAC validation uses `hmac.compare_digest()` (timing-safe)
- Replay attack prevention: rejects callbacks > 24 hours old

### Data Flow
1. `Session.setup(api_key, secret)` → sets class-level credentials
2. `Session(shop_url, api_version)` → `create_permission_url()` → OAuth URL
3. Callback params → `request_token(params)` → validates HMAC → exchanges code → access_token
4. `ShopifyResource.activate_session(session)` → sets site URL + token header
5. REST: `shopify.Product.find()` → HTTP GET to `{site}/products.json`
6. GraphQL: `GraphQL().execute(query)` → HTTP POST to `{site}/graphql.json`

### Known API Versions (hardcoded)
2021-10, 2022-01, 2022-04, 2022-07, 2022-10, 2023-01, 2023-04, 2023-07, 2023-10, 2024-01, 2024-04, 2024-07, 2024-10, + "unstable"
- Dynamic version creation for unknown `YYYY-MM` patterns

### Key Dependencies
| Dependency | Version Constraint | CVE Status |
|---|---|---|
| pyactiveresource | >= 2.2.2 | Monitor for HTTP redirect/SSRF |
| PyJWT | >= 2.0.0 | **CVE-2022-292917** (key confusion), **CVE-2024-30398** - no upper bound |
| PyYAML | >= 6.0.1 (py>=3.12), any (py<3.12) | **CVE-2020-14343**, **CVE-2022-14771**, **CVE-2023-41104** for Python < 3.12 |
| six | no pin | Generally stable, monitor |

### CVE Risks
1. **PyJWT >= 2.0.0 (no upper bound)** - **HIGH RISK**: Versions before 2.7.0 vulnerable to key confusion (CVE-2022-29217) and other issues. No upper version constraint means vulnerable versions may be installed.
2. **PyYAML (no constraint for Python < 3.12)** - **MEDIUM RISK**: CVE-2020-14343 (arbitrary code execution via yaml.load). For Python < 3.12, any version may be installed.
3. **Python 2 compatibility code** still present (`if sys.version_info[0] < 3`) - dead code, potential confusion

### Code Issues
1. Thread-local session storage in ShopifyResourceMeta - potential session leakage between threads
2. Dynamic API version creation without validation against Shopify's known versions
3. `request_token()` uses `urllib.request.urlopen()` without explicit SSL verification configuration
4. No upper bounds on critical dependencies (PyJWT, PyYAML, six)

### Output Files
- `/home/runner/work/hunting-5/hunting-5/hasil/trees/shopify_python_api.txt`
- `/home/runner/work/hunting-5/hunting-5/hasil/trees/shopify_python_api.json`
- `/home/runner/work/hunting-5/hunting-5/hasil/urls/shopify_python_api.md`
- `/home/runner/work/hunting-5/hunting-5/hasil/arch/shopify_python_api_arch.md`

---

## 3. checkout-sheet-kit-react-native (React Native Library)

### Core Summary
| Field | Value |
|-------|-------|
| **Package Version** | 4.0.0 |
| **TypeScript** | 5.9.2 |
| **React** | 19.1.0 |
| **React Native** | 0.80.2 |
| **iOS** | Platform 13.0, Native SDK 3.8.0 (CocoaPods) |
| **Android** | minSdk 23, compileSdk 36, AGP 8.11.0, Native SDK 3.6.0 |
| **Test Framework** | Jest 30.0.5 |
| **File Count** | 287 tracked files |

### Stack
TypeScript 5.9.2 | React Native 0.80.2 | React 19.1.0 | iOS Swift + Android Java | Jest 30.0.5

### Endpoints
- `https://{storefront_domain}.myshopify.com/api/{version}/graphql.json` (Storefront GraphQL API)
- `https://shopify.com/authentication/{shopId}/oauth/authorize` (Customer Account API)
- `https://shopify.com/authentication/{shopId}/oauth/token` (Customer Account API)
- Checkout URL (web checkout URL passed as parameter)

### Auth Model
- **Storefront API**: Anonymous (Storefront Access Token) or Customer Account API (OAuth 2.0 with PKCE)
- No server-side auth in library itself - auth handled by host app
- Apple Pay (requires merchant identifier + certificates)
- Shop Pay (wallet preference in cart buyer identity)
- Checkout URLs obtained externally via Storefront GraphQL API

### Data Flow
1. Host app obtains `checkoutUrl` from Storefront GraphQL API
2. `ShopifyCheckoutSheetProvider` creates `ShopifyCheckoutSheet` instance wrapping TurboModule
3. `shopifyCheckout.present(checkoutUrl)` → JS → TurboModule → Native SDK → CheckoutViewController (iOS) / CheckoutSheetKitDialog (Android)
4. Native events (close, completed, error, pixel) → NativeEventEmitter → JS listeners
5. `preload(checkoutUrl)` → background init of checkout session
6. `invalidate()` → clears preload cache
7. Accelerated checkouts (iOS 16+): `configureAcceleratedCheckouts()` with storefront domain + access token + Apple Pay config

### Key Dependencies
| Dependency | Version | CVE Status |
|---|---|---|
| react | 19.1.0 | Monitor |
| react-native | 0.80.2 | Monitor |
| typescript | 5.9.2 | TS 5.x |
| jest | 30.0.5 | Testing |
| **com.fasterxml.jackson.core:jackson-databind** | **2.12.5** | **HIGH RISK - CVE-2022-42003, CVE-2022-42003, CVE-2017-17485, CVE-2018-12019, CVE-2019-10091, CVE-2020-9576** |
| com.shopify:checkout-sheet-kit | 3.6.0 | Native SDK |
| ShopifyCheckoutSheetKit (CocoaPods) | ~> 3.8.0 | Native SDK |
| AGP (Android Gradle Plugin) | 8.11.0 | Monitor |

### CVE Risks
1. **jackson-databind 2.12.5** - **CRITICAL**: Multiple known CVEs including RCE via deserialization (CVE-2022-42003). Should upgrade to >= 2.15.2 (latest 2.15.x or 2.18.x).
2. **No upper version bounds on React/React Native** peer deps - `*` constraint
3. **Node 22.14.0** required - ensure OpenSSL 3 compatibility

### Test Files
- `modules/@shopify/checkout-sheet-kit/tests/`: index.test.ts, context.test.tsx, linking.test.ts, AcceleratedCheckoutButtons.test.tsx
- `sample/src/auth/__tests__/`: CustomerAccountManager.test.ts, PKCE.test.ts
- `sample/android/app/src/test/java/.../ShopifyCheckoutSheetKitModuleTest.java`

### Configuration (sample/.env.example)
- `STOREFRONT_DOMAIN`, `STOREFRONT_ACCESS_TOKEN`, `STOREFRONT_MERCHANT_IDENTIFIER`
- `STOREFRONT_VERSION` = "2025-07"
- `CUSTOMER_ACCOUNT_API_CLIENT_ID`, `CUSTOMER_ACCOUNT_API_SHOP_ID`

### Output Files
- `/home/runner/work/hunting-5/hunting-5/hasil/trees/checkout-sheet-kit-react-native.txt`
- `/home/runner/work/hunting-5/hunting-5/hasil/trees/checkout-sheet-kit-react-native.json`
- `/home/runner/work/hunting-5/hunting-5/hasil/urls/checkout-sheet-kit-react-native.md`
- `/home/runner/work/hunting-5/hunting-5/hasil/arch/checkout-sheet-kit-react-native_arch.md`

---

## Cross-Repo Comparison

| Aspect | shopify_app | shopify_python_api | checkout-sheet-kit-react-native |
|--------|------------|---------------------|--------------------------------|
| **Type** | Rails Engine (gem) | Python library | React Native library |
| **Language** | Ruby 3.2 | Python 3.7-3.12 | TypeScript + iOS Swift + Android Java |
| **Version** | 23.0.3 | 12.7.1 | 4.0.0 |
| **Auth** | OAuth 2.0 + Token Exchange (JWT) | OAuth 2.0 + JWT + Private App | OAuth 2.0 with PKCE (sample only) |
| **API** | REST + GraphQL (via shopify_api) | REST + GraphQL | Storefront GraphQL only |
| **DB** | ActiveRecord (pluggable) | None (client library) | None (client library) |
| **Tests** | Minitest + WebMock | unittest + pytest + http_fake | Jest + React Native Testing Library |
| **CI** | Ruby 3.2/3.3/3.4 on macOS | Python 3.8-3.12 on Ubuntu | Node 22 + TypeScript 5.9 on Ubuntu/macOS |

## Key Vulnerabilities Found

| # | Repo | Vulnerability | Severity | CVE/Issue |
|---|------|--------------|----------|-----------|
| 1 | shopify_python_api | PyJWT `>= 2.0.0` no upper bound | HIGH | CVE-2022-29217, CVE-2024-30398 |
| 2 | shopify_python_api | PyYAML no constraint for Python < 3.12 | MEDIUM | CVE-2020-14343, CVE-2023-41104 |
| 3 | checkout-sheet-kit-react-native | jackson-databind 2.12.5 | CRITICAL | CVE-2022-42003 (RCE) |
| 4 | shopify_app | Rails 7.1.6 multiple CVEs | MEDIUM | CVE-2024-21129, CVE-2024-25126, CVE-2024-25305, CVE-2024-26141, CVE-2024-34954 |
| 5 | shopify_app | jwt 3.1.2 no algorithm constraint | LOW | Key confusion if not constrained |
| 6 | checkout-sheet-kit-react-native | No upper bound on React/React Native peer deps | LOW | `*`, potential version conflicts |
| 7 | shopify_python_api | Python 2 compat code present | LOW | Dead code, maintenance confusion |
| 8 | shopify_python_api | Thread-local session storage | LOW | Potential session leakage between threads |
