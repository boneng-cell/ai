# URL / Endpoint / Domain Extraction - shop-chat-agent

Source: README.md, .env.example, package.json, shopify.app.toml, shopify.web.toml,
app/shopify.server.js, app/auth.server.js, app/db.server.js, app/mcp-client.js,
app/services/claude.server.js, app/services/config.server.js, app/services/streaming.server.js,
app/services/tool.server.js, app/routes/chat.jsx, app/routes/api.webhooks.jsx,
app/routes/auth.$.jsx, app/routes/auth.callback.jsx, app/routes/auth.token-status.jsx,
app/routes/_index/route.jsx, app/root.jsx, app/entry.server.jsx, app/routes.js,
vite.config.js, Dockerfile, prisma/schema.prisma, app/prompts/prompts.json

## Application URLs
| URL | Source | Notes |
|-----|--------|-------|
| https://shop-chat-agent.com | shopify.app.toml (application_url) | Hardcoded application URL |
| https://shop-chat-agent.com/api/auth | shopify.app.toml (auth.redirect_urls) | OAuth redirect URL |
| https://shop-chat-agent.com/callback | shopify.app.toml (customer_authentication.redirect_uris) | Customer auth callback |
| https://shop-chat-agent.com/webhooks/app/uninstalled | shopify.web.toml (webhooks_path) | Webhook endpoint |
| https://localhost:3458/auth/callback | .env.example (REDIRECT_URL) | Local dev redirect URL |

## API / Service Endpoints
| URL | Source | Notes |
|-----|--------|-------|
| https://${hostname}/.well-known/customer-account-api | app/routes/chat.jsx | Well-known endpoint for customer account MCP API discovery |
| https://${hostname}/.well-known/openid-configuration | app/routes/chat.jsx | OpenID Connect discovery endpoint |
| ${hostUrl}/api/mcp | app/mcp-client.js | Storefront MCP endpoint (template URL) |
| ${accountHostUrl}/customer/api/mcp | app/mcp-client.js | Customer MCP endpoint (template URL) |

## Route Endpoints
| Endpoint | Method | Source | Notes |
|----------|--------|--------|-------|
| /chat | GET, POST | app/routes/chat.jsx | Chat API with SSE streaming; GET for SSE, POST for chat, ?history=true for fetch |
| /chat?history=true&conversation_id=XYZ | GET | app/routes/chat.jsx | Conversation history fetch |
| /auth (and child routes) | - | app/routes/auth.$.jsx | Admin OAuth authentication (Shopify Admin API) |
| /auth/callback | GET | app/routes/auth.callback.jsx | Customer OAuth callback (PKCE flow) |
| /api/webhooks/app/uninstalled | POST | app/routes/api.webhooks.jsx | App uninstalled webhook handler |
| /token-status?conversation_id=XYZ | GET | app/routes/auth.token-status.jsx | Poll customer auth token status |
| /_index | GET | app/routes/_index/route.jsx | App index route |

## External Documentation / References
| URL | Source | Notes |
|-----|--------|-------|
| https://shopify.dev/docs/apps/build/storefront-mcp | README.md | Developer docs for storefront MCP |
| https://modelcontextprotocol.io/ | README.md | MCP protocol documentation |
| https://www.anthropic.com/claude | README.md | Claude AI model |
| https://reactrouter.com/ | README.md, vite.config.js | React Router framework |
| https://shopify.dev/docs/apps/deployment/web | README.md | App deployment docs |

## Infrastructure / Dev URLs
| URL | Source | Notes |
|-----|--------|-------|
| http://localhost | vite.config.js | Default dev server URL |
| http://localhost:${this.port} | vite.config.js | Dev server with dynamic port |
| ws://localhost:64999 | vite.config.js | HMR WebSocket (localhost) |
| https://*:8002 / wss:HOST:443 | vite.config.js | HMR config for custom host |

## External Library / Service URLs
| URL | Source | Notes |
|-----|--------|-------|
| https://cdn.shopify.com/ | app/routes/_index/route.jsx | CDN asset references |
| https://cdn.shopify.com/static/fonts/inter/v4/styles.css | app/root.jsx | Inter font CSS |
| https://api.anthropic.com | app/services/claude.server.js (implicit) | Claude API base URL (via SDK) |
| https://api.github.com/repos/Shopify/shop-chat-agent/git/trees/main | GitHub API | Tree API call (recon) |

## Environment Variables (referencing URLs)
| Var | Value Pattern | Source |
|-----|---------------|--------|
| REDIRECT_URL | https://localhost:3458/auth/callback | .env.example |
