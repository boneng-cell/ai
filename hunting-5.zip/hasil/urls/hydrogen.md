# URL / Endpoint / Domain Extraction - hydrogen

Source: README.md, package.json, packages/*/package.json, templates/skeleton/.env,
templates/skeleton/server.ts, templates/skeleton/app/lib/context.ts,
packages/hydrogen/src/createRequestHandler.ts, packages/hydrogen/src/storefront.ts,
packages/hydrogen/src/customer/customer.ts, packages/hydrogen/src/customer/auth.helpers.ts,
packages/hydrogen/src/customer/customer-account-helper.ts, packages/hydrogen/src/utils/request.ts,
packages/hydrogen/src/constants.ts, packages/hydrogen/src/index.ts,
packages/cli/src/lib/auth.ts, packages/cli/src/lib/graphql/admin/client.ts,
packages/cli/src/commands/hydrogen/env/pull.ts,
packages/cli/src/commands/hydrogen/env/push.ts, packages/cli/src/index.ts,
e2e/envs/.env.*, e2e/fixtures/storefront.ts, e2e/fixtures/server.ts

## Application / Platform URLs
| URL | Source | Notes |
|-----|--------|-------|
| https://hydrogen.shopify.dev | README.md | Hydrogen documentation site |
| https://shopify.dev/custom-storefronts/hydrogen | README.md | Hydrogen docs on Shopify |
| https://shopify.dev/custom-storefronts/hydrogen/cli | README.md, CLI | Hydrogen CLI docs |
| https://apps.shopify.com/hydrogen | README.md | Hydrogen on Shopify App Store |
| https://shopify.dev/hydrogen | README.md | Short form docs link |

## Storefront API Endpoints
| URL Pattern | Source | Notes |
|-------------|--------|-------|
| https://{shop}.myshopify.com/api/{version}/graphql.json | packages/hydrogen/src/storefront.ts | Storefront API GraphQL endpoint (forwarded) |
| https://{shop}.myshopify.com/api/mcp | packages/hydrogen/src/storefront.ts, packages/hydrogen/src/utils/request.ts (MCP_RE) | Storefront MCP endpoint |
| https://cdn.shopify.com/ | packages/hydrogen/src/storefront.ts | CDN asset domain |

## Customer Account API Endpoints
| URL Pattern | Source | Notes |
|-------------|--------|-------|
| https://shopify.com/{shopId} | packages/hydrogen/src/customer/customer-account-helper.ts | Customer Account API GraphQL base URL |
| https://shopify.com/authentication/{shopId} | packages/hydrogen/src/customer/customer-account-helper.ts | Customer Account auth base URL |
| https://shopify.com/authentication/{shopId}/oauth/authorize | packages/hydrogen/src/customer/customer-account-helper.ts | OAuth authorize endpoint |
| https://shopify.com/authentication/{shopId}/oauth/token | packages/hydrogen/src/customer/customer-account-helper.ts | Token exchange endpoint |
| https://shopify.com/authentication/{shopId}/oauth/token (refresh) | packages/hydrogen/src/customer/auth.helpers.ts | Token refresh (refresh_token grant) |
| https://shopify.com/authentication/{shopId}/logout | packages/hydrogen/src/customer/customer-account-helper.ts | Logout endpoint |
| https://shopify.com/{shopId}/account/customer/api/{version}/graphql | packages/hydrogen/src/customer/customer-account-helper.ts | Customer Account GraphQL API |
| https://api.customers.com/auth/customer.graphql | packages/hydrogen/src/customer/customer-account-helper.ts, auth.helpers.ts | Customer API scope |

## Admin API Endpoints
| URL Pattern | Source | Notes |
|-------------|--------|-------|
| https://{shopDomain}/admin/api/{LATEST_API_VERSION}/graphql.json | packages/cli/src/lib/graphql/admin/client.ts | Admin GraphQL API URL |
| https://{storeFqdn}/admin/api/unstable/graphql.json | packages/cli/src/lib/graphql/admin/client.ts | Admin API URL (unstable) |

## CLI / Auth Endpoints
| URL | Source | Notes |
|-----|--------|-------|
| Business Platform API (via @shopify/cli-kit) | packages/cli/src/lib/auth.ts, packages/cli/src/lib/graphql/business-platform/user-account.ts | Shopify Business Platform API for CLI auth |

## Route Endpoints
| Endpoint | Source | Notes |
|----------|--------|-------|
| /api/{version}/graphql.json | packages/hydrogen/src/createRequestHandler.ts | Storefront API proxy (forwarded) |
| /api/mcp | packages/hydrogen/src/createRequestHandler.ts, utils/request.ts | Storefront MCP proxy (forwarded) |
| /account/login | packages/hydrogen/src/customer/customer.ts | Customer login (default) |
| /account/login?return_to=... | packages/hydrogen/src/customer/customer.ts | Login with return path |
| /account/authorize | packages/hydrogen/src/customer/customer.ts | OAuth callback (default authorizePath) |
| /account | packages/hydrogen/src/customer/customer.ts | Account dashboard (default redirect) |
| /_routes/graphiql.tsx | packages/hydrogen/src/vite/virtual-routes/routes/graphiql.tsx | GraphiQL IDE (dev only) |
| /_routes/[.]well-known.appspecific.com[.]chrome[.]devtools[.]json.tsx | packages/hydrogen/src/vite/virtual-routes/ | Chrome DevTools well-known |
| /_routes/subrequest-profiler.tsx | packages/hydrogen/src/vite/virtual-routes/routes/ | Subrequest profiler (dev only) |
| /_routes/index.tsx | packages/hydrogen/src/vite/virtual-routes/routes/ | Index route (dev only) |

## Template Routes (templates/skeleton/app/routes.ts)
| Route | Method | Notes |
|-------|--------|-------|
| / | GET | Home page |
| /products/$handle | GET | Product page |
| /collections/$handle | GET | Collection page |
| /collections/all | GET | All collections |
| /cart | GET, POST | Cart page |
| /cart/$lines | GET, POST | Cart with line items |
| /account | GET | User account |
| /account/login | GET | Customer login |
| /account/logout | GET | Customer logout |
| /account/authorize | GET | OAuth callback (customer) |
| /account/orders | GET | Order history |
| /account/orders/$id | GET | Order detail |
| /blogs/$blogHandle | GET | Blog page |
| /blogs/$blogHandle/$articleHandle | GET | Article page |
| /blogs | GET | Blog list |
| /pages/$handle | GET | Page |
| /policies/$handle | GET | Policy page |
| /search | GET | Search |
| /discount/$code | GET | Discount redirect |
| /sitemap.xml | GET | Sitemap index |
| /sitemap/$type.$page.xml | GET | Sitemap pages |
| /robots.txt | GET | SEO robots |
| /$.tsx | - | Catch-all (404 handler) |

## Documentation / Reference URLs
| URL | Source | Notes |
|-----|--------|-------|
| https://shopify.dev/api/storefront | packages/hydrogen/src/storefront.ts | Storefront API docs |
| https://shopify.dev/api/storefront#authentication | packages/hydrogen-react/storefront.schema.json | Storefront API auth |
| https://shopify.dev/api/usage/versioning | README.md | API versioning |
| https://shopify.dev/api/usage/versioning#release-schedule | README.md | Release schedule |
| https://shopify.dev/docs/api/customer | packages/hydrogen/src/customer/customer.ts | Customer API docs |
| https://shopify.dev/docs/api/customer#authorization-propertydetail-uilocales | packages/hydrogen/src/customer/customer.ts | Customer API locale docs |
| https://shopify.dev/apps/auth/oauth/delegate-access-tokens | packages/hydrogen/src/customer/customer.ts | OAuth delegate tokens |
| https://shopify.dev/docs/api/shopify-cli/hydrogen | packages/cli/src/lib/auth.ts | Shopify CLI Hydrogen API |
| https://shopify.dev/docs/api/shopify-cli/hydrogen/hydrogen-env-pull | packages/cli/src/commands/hydrogen/env/pull.ts | CLI env pull command |
| https://shopify.dev/docs/api/shopify-cli/hydrogen/hydrogen-env-list | packages/cli/src/commands/hydrogen/env/list.ts | CLI env list command |
| https://shopify.dev/docs/api/shopify-cli/hydrogen/hydrogen-dev | packages/cli/src/commands/hydrogen/dev.ts | CLI dev command |
| https://shopify.dev/docs/api/shopify-cli/hydrogen/hydrogen-unlink | packages/cli/src/commands/hydrogen/unlink.ts | CLI unlink command |
| https://shopify.dev/docs/custom-storefronts/hydrogen/cli | packages/cli/src/index.ts | CLI docs |
| https://shopify.dev/docs/storefronts/headless/hydrogen | README.md | Headless storefronts doc |
| https://github.com/Shopify/hydrogen-v1 | README.md | Legacy v1 repo |
| https://github.com/Shopify/hydrogen/discussions | README.md | Community discussions |
| https://shopify.github.io/hydrogen-v1/tutorials/getting-started | README.md | v1 docs site |
| https://npmcharts.com/compare/@shopify/hydrogen?minimal=true | README.md | npm downloads chart |
| https://www.npmjs.com/package/@shopify/cli-hydrogen | README.md | CLI package on npm |
| https://www.npmjs.com/package/@shopify/create-hydrogen | README.md | Create package on npm |
| https://www.npmjs.com/package/@shopify/hydrogen | README.md | Core package on npm |
| https://www.npmjs.com/package/@shopify/hydrogen-codegen | README.md | Codegen package on npm |
| https://www.npmjs.com/package/@shopify/hydrogen-react | README.md | React package on npm |
| https://www.npmjs.com/package/@shopify/mini-oxygen | README.md | Mini oxygen on npm |
| https://developer.mozilla.org/en-US/docs/Web/API/Cache | packages/hydrogen/src/createHydrogenContext.ts | Cache API docs |
| https://remix.run/docs/en/main/utils/sessions | packages/hydrogen/src/createHydrogenContext.ts | Remix sessions docs |
| https://remix.run/docs/en/main/utils/redirect | packages/hydrogen/src/customer/customer.ts | Remix redirect docs |
| https://calver.org/ | README.md | Calendar versioning spec |
| https://monorepo.tools/ | README.md | Monorepo tools |
| https://spec.graphql.org/June2018/#sec-Response-Format | packages/hydrogen/src/storefront.ts | GraphQL spec response format |
| https://vitejs.dev/config/server-options.html#server-fs-allow | vite.config.js (skeleton) | Vite fs allow docs |
| https://github.com/remix-run/remix/issues/2835 | vite.config.js (skeleton) | Remix issue reference |

## Dev / Tunnel / Local URLs
| URL | Source | Notes |
|-----|--------|-------|
| http://localhost | templates/skeleton/.env | Default local URL |
| http://localhost:3000 | packages/hydrogen/src/vite/virtual-routes/layout.tsx, e2e fixtures | Dev server default |
| http://localhost:${this.port} | e2e/fixtures/server.ts | Dynamic port for dev server |
| https://*.tryhydrogen.dev | packages/hydrogen/src/customer/customer.ts | Hydrogen dev tunnel domain (.tryhydrogen.dev) |
| https://shopify.com/${shopId} | packages/hydrogen/src/customer/customer-account-helper.ts | Customer Account API base (from env PUBLIC_CUSTOMER_ACCOUNT_API_URL) |
| https://shopify.com/authentication/${shopId} | packages/hydrogen/src/customer/customer-account-helper.ts | CA auth base |

## E2E Test URLs
| URL | Source | Notes |
|-----|--------|-------|
| https://mock.shop | e2e/envs/.env.mockShop | Mock shop for e2e tests |
| https://drru00-at.myshopify.com | e2e/envs/.env.customerAccount | Customer Account test store |
| https://checkout.hydrogen.shop | e2e/envs/.env.hydrogenPreviewStorefront | Checkout domain (preview) |
| https://cdn.shopify.com/shopifycloud/perf-kit | e2e/fixtures/storefront.ts | Perf-kit script CDN |
| /produce_batch | e2e/fixtures/storefront.ts | Monorail batch analytics endpoint |
| /v1/produce | e2e/fixtures/storefront.ts | Perf-kit produce endpoint |
| /graphql.json | e2e/fixtures/storefront.ts | GraphQL URL pattern for tracking |
| /cart | e2e/fixtures/storefront.ts | Cart page URL pattern |
| /cart/c/ | e2e/fixtures/storefront.ts | Checkout URL pattern (/cart/c/...) |
| http://e.c | packages/hydrogen/src/utils/request.ts | Base URL for safe path extraction |

## Environment Variables (referencing URLs)
| Var | Value Pattern | Source |
|-----|---------------|--------|
| SESSION_SECRET | mock-session | templates/skeleton/.env, e2e env files |
| PUBLIC_STORE_DOMAIN | checkout.hydrogen.shop / mock.shop | e2e envs |
| PUBLIC_STOREFRONT_API_TOKEN | (token) | e2e envs |
| PUBLIC_STOREFRONT_ID | (id) | e2e envs |
| PUBLIC_CHECKOUT_DOMAIN | checkout.hydrogen.shop / mock.shop | e2e envs |
| PUBLIC_CUSTOMER_ACCOUNT_API_CLIENT_ID | UUID | e2e/.env.customerAccount |
| PUBLIC_CUSTOMER_ACCOUNT_API_URL | https://shopify.com/95062458424 | e2e/.env.customerAccount |
| SHOP_ID | 95062458424 | e2e/.env.customerAccount |
| SHOPIFY_HYDROGEN_FLAG_PORT | (port) | e2e/fixtures/server.ts (env var for port) |
| PNPM_HOME | (path) | e2e/fixtures/server.ts (env var for pnpm) |
| npm_execpath | (path) | e2e/fixtures/server.ts (env var for npx/pnpm detection) |
