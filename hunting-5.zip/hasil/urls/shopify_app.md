# shopify_app - Extracted URLs / Domains / Endpoints

## Source: README.md

### Shopify Domains & Endpoints
- https://www.shopify.com/partners
- https://shopify.dev/concepts/shopify-introduction
- https://shopify.dev/concepts/apps
- https://shopify.dev/concepts/apps/building-embedded-apps-using-session-tokens
- https://shopify.dev/docs/apps/build/cli-for-apps
- https://shopify.dev/docs/apps/build/cli-for-apps/app-structure
- https://shopify.dev/docs/apps/build/cli-for-apps/development
- https://shopify.dev/docs/apps/tools/cli/configuration
- https://shopify.dev/docs/apps/tools/cli/configuration#access_scopes
- https://shopify.dev/concepts/about-apis/versioning
- https://shopify.dev/concepts/about-apis/versioning#deprecation-practices
- https://shopify.dev/docs/api/checkout-extensions
- https://shopify.dev/docs/apps/build/authentication-authorization/access-tokens/token-exchange
- https://shopify.dev/docs/apps/auth/get-access-tokens/token-exchange
- https://shopify.dev/docs/apps/auth/get-access-tokens/authorization-code-grant
- https://shopify.dev/docs/apps/auth/installation#shopify-managed-installation
- https://partners.shopify.com/organizations

### OAuth Redirect URLs (from README config example)
- https://localhost:3000
- https://localhost:3000/api/auth
- https://localhost:3000/api/auth/callback
- https://localhost:3000/auth/callback
- https://localhost:3000/auth/shopify/callback

### Documentation & References
- https://github.com/Shopify/shopify-api-ruby/
- https://github.com/Shopify/shopify_app/actions?query=workflow%3ACI
- https://github.com/Shopify/shopify_app/blob/main/docs/shopify_app/sessions.md#expiry-date
- https://github.com/Shopify/shopify_app/workflows/CI/badge.svg
- https://rubygems.org/gems/shopify_app
- https://img.shields.io/gem/v/shopify_app.svg

## Source: lib/shopify_app/utils.rb

### Trusted Shopify Domains
- shopify.com
- myshopify.io
- myshopify.com
- spin.dev
- shop.dev
- myshopify.com (configurable via configuration.myshopify_domain)

### Unified Admin Domain (configurable)
- https://admin.{unified_admin_domain}/store/{shop}
- https://admin.web.{SPIN_FQDN}/store/{shop}  (SPIN_FQDN env var)

## Source: lib/shopify_app/configuration.rb

### Default Domains
- myshopify_domain = "myshopify.com"
- unified_admin_domain = "shopify.com"
- root_url = "/"

## Source: lib/shopify_app/session/session_repository.rb

### Documentation URLs (in error messages)
- https://github.com/Shopify/shopify_app/blob/main/docs/shopify_app/sessions.md#sessions

## Source: app/controllers/shopify_app/sessions_controller.rb

### OAuth Flow URLs
- OAuth authorize URL: https://{shop}.myshopify.com/admin/oauth/authorize?client_id={api_key}&redirect_uri={callback}&scope={scopes}&state={state}
- Unified admin install path: https://admin.{unified_admin_domain}/store/{shop}/oauth/install?client_id={api_key}
- SPIN environment: https://admin.web.{SPIN_FQDN}/store/{shop}/oauth/install?client_id={api_key}

## Source: app/controllers/shopify_app/callback_controller.rb

### OAuth Callback
- OAuth access token URL: https://{shop}.myshopify.com/admin/oauth/access_token
- Webhook delivery endpoint (route): /webhooks/:type  (POST)

## Source: lib/shopify_app/auth/token_exchange.rb

### Token Exchange (OAuth 2.0 Token Exchange)
- Token exchange endpoint (delegated to ShopifyAPI::Auth::TokenExchange)
- Uses ShopifyAPI gem internals for token exchange with session tokens

## Source: lib/shopify_app/controller_concerns/webhook_verification.rb

### Webhook Verification
- Shopify webhook delivery header: X-Shopify-Shop-Domain
- Webhook HMAC verification via X-Shopify-Hmac-Sha256 header

## Source: Gemfile/gemspec

### Dependency Sources
- https://rubygems.org (gem source)

## Source: lib/shopify_app.rb

### CSP / CDN URLs
- https://cdn.shopify.com/shopifycloud/app-bridge.js (App Bridge script for CSP)

## Source: Docs

### Documentation Links
- https://shopify.dev/concepts/apps/building-embedded-apps-using-session-tokens
- https://shopify.dev/docs/apps/auth/installation#shopify-managed-installation
- https://shopify.dev/docs/apps/auth/get-access-tokens/token-exchange

## Summary

| Category | Count |
|----------|-------|
| Total unique URLs | ~40 |
| Shopify API endpoints | 5+ (oauth/authorize, oauth/access_token, webhooks, token exchange) |
| Trusted domains | 5 (shopify.com, myshopify.io, myshopify.com, spin.dev, shop.dev) |
| CDN/external resources | 2 (rubygems.org, cdn.shopify.com) |
| Localhost URLs | 4 |
| Documentation URLs | 15+ |
