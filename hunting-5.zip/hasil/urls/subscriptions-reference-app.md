# URL / Endpoint / Domain Extraction - subscriptions-reference-app

Source: README.md, package.json, shopify.app.toml, shopify.web.toml,
app/shopify.server.ts, app/routes.ts, app/services/*.ts, app/routes/*.tsx,
config/index.ts, config/types.ts, test/constants.ts, test/utils/*.ts,
prisma/schema.prisma

## Application URLs (from shopify.app.toml)
| URL | Purpose | Notes |
|-----|---------|-------|
| https://example.com | application_url | Placeholder application URL |
| https://example.com/auth/callback | auth.redirect_urls | OAuth callback URL |
| https://example.com/auth/shopify/callback | auth.redirect_urls | Shopify OAuth callback URL |
| https://example.com/api/auth/callback | auth.redirect_urls | API OAuth callback URL |
| https://example.com/webhooks/app/uninstalled | webhook subscription | App uninstalled webhook |
| https://example.com/webhooks/subscription_contracts/create | webhook subscription | Contract created |
| https://example.com/webhooks/subscription_contracts/activate | webhook subscription | Contract activated |
| https://example.com/webhooks/subscription_contracts/cancel | webhook subscription | Contract cancelled |
| https://example.com/webhooks/subscription_contracts/pause | webhook subscription | Contract paused |
| https://example.com/webhooks/subscription_billing_cycles/skip | webhook subscription | Billing cycle skip |
| https://example.com/webhooks/subscription_billing_attempts/success | webhook subscription | Billing attempt success |
| https://example.com/webhooks/subscription_billing_attempts/failure | webhook subscription | Billing attempt failure |
| https://example.com/webhooks/selling_plan_groups/create_or_update | webhook subscription | Selling plan groups update |
| https://example.com/webhooks/customer_redact | compliance webhook | Customer data request/redaction |
| https://example.com/webhooks/shop_redact | compliance webhook | Shop redaction |
| https://example.com/webhooks/cli | shopify.web.toml (webhooks_path) | CLI webhook endpoint |

## API / Service Endpoints
| URL | Source | Notes |
|-----|--------|-------|
| https://${TEST_SHOP}/admin/api/${LATEST_API_VERSION}/graphql.json | test/constants.ts | Admin GraphQL API URL |
| https://${session.storeFqdn}/admin/api/unstable/graphql.json | packages/cli/src/lib/graphql/admin/client.ts | Admin API GraphQL URL |
| https://github.com/Shopify/subscriptions-reference-app | README.md | Init template URL |
| https://my-test-app.myshopify.io | test/constants.ts | Test app URL |

## Route Endpoints
| Endpoint | Method | Source | Notes |
|----------|--------|--------|-------|
| /app/* | GET, POST | app/routes/app/route.tsx | Main app routes (authenticated admin area) |
| /auth/* | GET | app/routes/auth.login/route.tsx | Authentication routes (Shopify OAuth) |
| /webhooks/app/uninstalled | POST | app/routes/webhooks.app.uninstalled.tsx | App uninstalled webhook |
| /webhooks/subscription_contracts/create | POST | app/routes/webhooks.subscription_contracts.create.tsx | Contract created webhook |
| /webhooks/subscription_contracts/activate | POST | app/routes/webhooks.subscription_contracts.activate.tsx | Contract activated webhook |
| /webhooks/subscription_contracts/cancel | POST | app/routes/webhooks.subscription_contracts.cancel.tsx | Contract cancelled webhook |
| /webhooks/subscription_contracts/pause | POST | app/routes/webhooks.subscription_contracts.pause.tsx | Contract paused webhook |
| /webhooks/subscription_billing_cycles/skip | POST | app/routes/webhooks.subscription_billing_cycles.skip.tsx | Billing cycle skip webhook |
| /webhooks/subscription_billing_attempts/success | POST | app/routes/webhooks.subscription_billing_attempts.success.tsx | Billing success webhook |
| /webhooks/subscription_billing_attempts/failure | POST | app/routes/webhooks.subscription_billing_attempts.failure.tsx | Billing failure webhook |
| /webhooks/selling_plan_groups/create_or_update | POST | app/routes/webhooks.selling_plan_groups.create_or_update.tsx | Selling plan groups webhook |
| /webhooks/customer_redact | POST | app/routes/webhooks.customer_redact.ts | Customer data redaction webhook |
| /webhooks/shop_redact | POST | app/routes/webhooks.shop_redact.ts | Shop redaction webhook |
| /webhooks/cli | POST | app/routes/webhooks.cli.tsx | CLI webhook |
| /internal/jobs/run | POST | app/routes/internal.jobs.run.tsx | Internal job runner (GCP Cloud Tasks) |
| /services/ping | GET | app/routes/services.ping.tsx | Health check endpoint |
| /customerAccount/emails | POST | app/routes/customerAccount.emails.ts | Customer email handler |
| /maintenance/* | GET | app/routes/maintenance._index/route.tsx | Maintenance mode route |
| /missing-scopes/* | GET | app/routes/missing-scopes._index/route.tsx | Missing scopes redirect |
| /app/contracts/$id/* | GET, POST | app/routes/app.contracts.$id/*/route.ts(x) | Subscription contract management |
| /app/plans/$id/* | GET, POST | app/routes/app.plans.$id/*/route.tsx | Selling plan management |
| /app/settings/* | GET, POST | app/routes/app.settings._index/route.tsx | App settings |
| /app/contracts.bulk-operation | - | app/routes/app.contracts.bulk-operation.ts | Bulk operations endpoint |

## External Documentation / References
| URL | Source | Notes |
|-----|--------|-------|
| https://apps.shopify.com/shopify-subscriptions | README.md | Shopify Subscriptions app on App Store |
| https://shopify.dev/docs/apps/build/purchase-options/subscriptions | README.md | Subscriptions overview docs |
| https://shopify.dev/docs/api/admin-graphql/2024-04/queries/sellingPlanGroups | README.md | Selling plans API reference |
| https://shopify.dev/docs/api/admin-graphql/2024-04/queries/subscriptionContracts | README.md | Subscription contracts API reference |
| https://shopify.dev/docs/apps/build/purchase-options/subscriptions/subscriptions-app/core-system-components | README.md | Core system components docs |
| https://shopify.dev/docs/api/shopify-cli | README.md | Shopify CLI reference |
| https://remix.run/docs/en/main | README.md | Remix framework docs |
| https://shopify.dev/docs/apps/getting-started | README.md | Shopify app development getting started |
| https://shopify.dev/docs/apps/app-extensions/list | README.md | Shopify app extensions list |
| https://shopify.dev/docs/apps/auth | README.md | Shopify authentication docs |
| https://shopify.dev/docs/apps/build/purchase-options/subscriptions/subscriptions-app/start-building | README.md | Start building subscriptions docs |
| https://shopify.dev/docs/apps/build/purchase-options/subscriptions/subscriptions-app | README.md | Subscriptions app docs |
| https://shopify.dev/docs/apps/build/purchase-options/subscriptions/subscriptions-app#uniqueness-from-other-apps | README.md | App uniqueness requirements |
| https://shopify.dev/docs/apps/build/purchase-options/subscriptions/subscriptions-app/core-system-components | README.md | Core building blocks |
| https://github.com/Shopify/shopify-app-js/blob/release-candidate/packages/shopify-app-remix/README.md | README.md | shopify-app-remix README |

## External Service / API URLs (GCP, etc.)
| URL | Source | Notes |
|-----|--------|-------|
| https://cloud.google.com/tasks/docs | app/services/*.ts (implicit) | GCP Cloud Tasks for job scheduling (Cloud TaskSchedulerConfig) |

## Environment Variables (referencing URLs)
| Var | Value Pattern | Source |
|-----|---------------|--------|
| SHOPIFY_API_KEY | testApiKey (test) | test/constants.ts |
| SHOPIFY_API_SECRET | testApiSecretKey (test) | test/constants.ts |
| SHOPIFY_APP_URL | https://my-test-app.myshopify.io | test/constants.ts |
| SHOPIFY_HOST | totally-real-host.myshopify.io | test/constants.ts |
| TEST_SHOP | test-shop.myshopify.com | test/constants.ts |
