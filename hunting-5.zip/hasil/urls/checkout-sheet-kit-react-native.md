# checkout-sheet-kit-react-native - Extracted URLs / Domains / Endpoints

## Source: README.md

### Shopify API & Documentation
- https://shopify.dev/docs/api/storefront
- https://shopify.dev/docs/api/storefront#directives
- https://shopify.dev/docs/api/storefront/2023-10/objects/Cart#field-cart-checkouturl
- https://shopify.dev/docs/api/storefront/latest/mutations/cartBuyerIdentityUpdate#field-cartbuyeridentityinput-walletpreferences
- https://shopify.dev/docs/api/web-pixels-api/standard-events
- https://shopify.dev/docs/api/web-pixels-api#custom-web-pixels
- https://shopify.dev/docs/api/multipass
- https://shopify.dev/docs/custom-storefronts/mobile-kit
- https://shopify.dev/docs/custom-storefronts/building-with-the-storefront-api/cart/manage
- https://shopify.dev/docs/storefronts/mobile/create-apple-payment-processing-certificates
- https://shopify.dev/docs/api/storefront (mentioned)

### Apple/Google Platform URLs
- https://developer.apple.com/documentation/passkit/setting-up-apple-pay
- https://reactnative.dev/docs/the-new-architecture/use-the-new-architecture

### Shopify Community & Blog
- https://www.shopify.com/partners/blog/mobile-checkout-sdks-for-ios-and-android
- https://www.shopify.com/partners/blog/introducing-customer-account-api-for-headless-stores

### Shopify Help Docs
- https://help.shopify.com/en/manual/intro-to-shopify/pricing-plans/plans-features/shopify-plus-plan
- https://help.shopify.com/en/manual/customers/customer-accounts/classic-customer-accounts
- https://help.shopify.com/en/manual/products/details/cart-permalink

### AppSheet (Accelerated Checkouts)
- https://www.appsheet.com/start/1ff317b6-2da1-4f39-b041-c01cfada6098

### GitHub References
- https://github.com/Shopify/checkout-sheet-kit-react-native/blob/main/LICENSE
- https://github.com/Shopify/checkout-sheet-kit-react-native/blob/main/documentation/universal_links_ios.md
- https://github.com/user-attachments/assets/156492b7-5a64-43d2-b574-2e8f29ed8780
- https://github.com/Shopify/checkout-sheet-kit-react-native (repository URL in package.json)

### Badges
- https://img.shields.io/badge/license-MIT-lightgrey.svg?style=flat
- https://img.shields.io/github/release/shopify/checkout-sheet-kit-react-native.svg?style=flat

## Source: sample/.env.example

### Storefront Configuration
- STOREFRONT_DOMAIN="YOUR_STORE.myshopify.com"
- STOREFRONT_ACCESS_TOKEN="YOUR_PUBLIC_STOREFRONT_ACCESS_TOKEN"
- STOREFRONT_MERCHANT_IDENTIFIER=example.merchant.com.shopify

### Storefront API Version
- STOREFRONT_VERSION="2025-07" (API version used in sample)

## Source: sample/src/auth/customerAccountManager.ts

### Customer Account API URLs
- https://shopify.com/authentication/{shopId}/logout
- https://shopify.com/authentication/{shopId}/oauth/authorize
- https://shopify.com/authentication/{shopId}/oauth/token

## Source: modules/@shopify/checkout-sheet-kit/src/index.ts

### No hardcoded URLs (all URLs are passed by consumer via checkoutUrl parameter)

## Source: modules/@shopify/checkout-sheet-kit/android/build.gradle

### SDK Dependencies
- com.shopify:checkout-sheet-kit:${SHOPIFY_CHECKOUT_SDK_VERSION} (version: 3.6.0)
- com.fasterxml.jackson.core:jackson-databind:2.12.5
- com.facebook.react:react-native:+
- Google Maven: google()
- Maven Central: mavenCentral()

## Source: React Native Test Files

### Test URLs
- https://shopify.com
- https://shopify.com/checkout

## Source: iOS Files

### No external URLs in source code (uses native ShopifyCheckoutSheetKit framework)

## Source: Android Manifest

### No external URLs in manifest files

## Summary

| Category | Count |
|----------|-------|
| Total unique URLs | ~20 |
| Storefront API URLs | 5+ (storefront API, directives, objects) |
| Shopify domain URLs | 8+ (shopify.com, shopify.dev, help.shopify.com) |
| Apple/Google platform URLs | 3 |
| SDK dependency URLs | 3 (Google Maven, Maven Central, Shopify SDK) |
| Test URLs | 2 |
| Customer Account API URLs | 3 |
| NPM/registry URLs | 3 |
| Image/badge URLs | 3 |
| API Version | 1 (2025-07, used in sample) |
| Native iOS SDK version | 3.8.0 (via podspec dependency) |
| Native Android SDK version | 3.6.0 (SHOPIFY_CHECKOUT_SDK_VERSION) |
