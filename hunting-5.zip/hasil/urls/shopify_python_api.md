# shopify_python_api - Extracted URLs / Domains / Endpoints

## Source: README.md

### Shopify API References
- https://shopify.dev/docs/admin-api
- https://shopify.dev/docs/apps/build/graphql/migrate/new-product-model
- https://shopify.dev/changelog/auto-activation-of-charges-and-subscriptions
- https://help.shopify.com/en/api/graphql-admin-api
- https://shopify.dev/docs/apps/build/graphql/migrate/new-product-model

### OAuth & Authentication
- https://partner-dashboard.shopify.com (Partners Dashboard)
- https://partners.shopify.com
- https://www.shopify.com/partners
- http://myapp.com/auth/shopify/callback (example redirect_uri)
- https://localhost.myshopify.com/admin/oauth/authorize?client_id=My_test_key&redirect_uri=my_redirect_uri.com (test)
- https://localhost.myshopify.com/admin/oauth/access_token (test)

### Billing
- https://domain.com/approve (example return_url for billing)
- https://shopify.dev/changelog/auto-activation-of-charges-and-subscriptions (auto-activation note)

### GraphQL
- https://shopify.dev/docs/api/storefront (mentioned in context of GraphQL)
- https://shopify.dev/docs/api/storefront/2023-10/objects/Cart#field-cart-checkouturl (referenced in RN kit but relevant here)

### Resources & Community
- https://developers.shopify.com
- https://shopify.dev
- http://ecommerce.shopify.com/c/shopify-apis-and-technology
- https://community.shopify.dev/t/rethinking-support-for-php-python-packages/28325
- https://github.com/Shopify/pyactiveresource (pyactiveresource dependency)
- https://github.com/pre-commit/pre-commit
- https://pre-commit.com/
- https://github.com/shopify/sample-django-app (sample app)

### Installation & Badges
- https://badge.fury.io/py/ShopifyAPI
- https://badge.fury.io/py/ShopifyAPI.svg
- https://img.shields.io/badge/python-3.7%20|%203.8%20|%203.9%20|%203.10%20|%203.11%20|%203.12-brightgreen
- https://img.shields.io/badge/License-MIT-yellow.svg
- https://github.com/Shopify/shopify_python_api/workflows/CI/badge.svg
- https://img.shields.io/badge/pre--commit-enabled-brightgreen?logo=pre-commit&logoColor=white
- https://pypi.org/project/shopifyapp/
- https://codecov.io/gh/Shopify/shopify_python_api
- https://github.com/Shopify/shopify_python_api

## Source: setup.py

### Package Metadata
- https://github.com/Shopify/shopify_python_api

## Source: test/test_helper.py

### Test Endpoints
- https://this-is-my-test-show.myshopify.com
- https://this-is-my-test-show.myshopify.com/admin/api/unstable
- https://%s:%s@this-is-my-test-show.myshopify.com/admin

## Source: test/session_test.py

### OAuth & Session Endpoints
- https://localhost.myshopify.com/admin/oauth/authorize?client_id=My_test_key&redirect_uri=my_redirect_uri.com
- https://localhost.myshopify.com/admin/oauth/authorize?client_id=My_test_key&redirect_uri=my_redirect_uri.com&scope=write_customers&state=mystate
- https://localhost.myshopify.com/admin/oauth/authorize?client_id=My_test_key&redirect_uri=my_redirect_uri.com&scope=write_products
- https://localhost.myshopify.com/admin/oauth/authorize?client_id=My_test_key&redirect_uri=my_redirect_uri.com&scope=write_products%2Cwrite_customers
- https://localhost.myshopify.com/admin/oauth/authorize?client_id=My_test_key&redirect_uri=my_redirect_uri.com&state=mystate
- https://localhost.myshopify.com/admin/oauth/access_token
- https://test.myshopify.com
- https://test.myshopify.com/admin/api/{future_version}
- https://shop1.myshopify.com/admin/api/unstable
- https://shop2.myshopify.com/admin/api/2019-04
- https://testshop.myshopify.com/admin/api/unstable
- http://localhost.myshopify.com
- http://user:pass@testshop.notshopify.net/path
- https://none/admin/api/unstable
- https://fakeshop.myshopify.com/admin/api/2019-04
- https://fakeshop.localhost:3000/admin/api/unstable

## Source: test/session_token_test.py

### Session Token Endpoints
- https://test-shop.myshopify.com
- https://test-shop.myshopify.com/admin

## Source: test/base_test.py

### Resource Endpoint
- https://shop1.myshopify.com/admin/api/unstable
- https://shop2.myshopify.com/admin/api/2019-04
- https://this-is-my-test-show.myshopify.com/admin/shop.json

## Source: shopify/session.py

### OAuth & API Endpoints
- https://{shop}.myshopify.com/admin/oauth/authorize?client_id={api_key}&redirect_uri={redirect_uri}&scope={scopes}&state={state}
- https://{shop}.myshopify.com/admin/oauth/access_token?client_id={api_key}&client_secret={secret}&code={code}
- http://docs.shopify.com/api/authentication/oauth#verification

## Source: shopify/resources/graphql.py

### GraphQL Endpoint
- {site}/graphql.json (where site is the session API path, e.g., https://{shop}.myshopify.com/admin/api/{version}/graphql.json)
- Note: endpoint is dynamically constructed from ShopifyResource.get_site()

## Source: shopify/limits.py

### API Documentation
- https://help.shopify.com/en/api/getting-started/api-call-limit

## Source: scripts/shopify_api.py

### Private App URL
- https://{shop}.myshopify.com/admin/apps/private

## Source: shopify/utils/shop_url.py

### Placeholder
- http://{hostname} (template string in sanitization logic)

## Summary

| Category | Count |
|----------|-------|
| Total unique URLs | ~35 |
| Shopify API endpoints | 8+ (oauth/authorize, oauth/access_token, graphql.json, REST API) |
| OAuth-related | 6+ |
| Test/mock URLs | 15+ |
| Documentation/help URLs | 8 |
| Package/registry URLs | 10+ |
