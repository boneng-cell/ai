# [MEDIUM] Missing Secure Flag on Session Cookie in Hydrogen Skeleton Template

## Ringkasan (impact nyata)
The Hydrogen skeleton template's session cookie configuration in `templates/skeleton/app/lib/session.ts` does not set the `secure` flag, meaning the session cookie can be transmitted over unencrypted HTTP connections. In production deployments where HTTPS is expected, this allows session hijacking via man-in-the-middle attacks if any HTTP endpoint exists on the same domain or if the user accesses the app over HTTP.

## Deskripsi / Root Cause
In `templates/skeleton/app/lib/session.ts`, the `createCookieSessionStorage` configuration omits the `secure` flag:

```typescript
// templates/skeleton/app/lib/session.ts
static async init(request: Request, secrets: string[]) {
  const storage = createCookieSessionStorage({
    cookie: {
      name: 'session',
      httpOnly: true,
      path: '/',
      sameSite: 'lax',
      secrets,
      // MISSING: secure: true
    },
  });
  // ...
}
```

### Key Issues
1. **Missing `secure` flag**: The `secure` flag is not set, meaning the cookie can be sent over HTTP.
2. **Default behavior**: Without the `secure` flag, browsers will send the cookie over both HTTP and HTTPS connections.
3. **Session hijacking**: If an attacker can intercept HTTP traffic (e.g., via a man-in-the-middle attack, compromised WiFi, or HTTP downgrade), they can steal the session cookie.
4. **Template default**: This is the default template used by all Hydrogen apps, meaning all apps generated from this template inherit this vulnerability unless manually fixed.

### Cookie Security Comparison

| Flag | Set | Missing | Impact |
|------|-----|---------|--------|
| `httpOnly` | ✅ | — | Prevents JavaScript access to cookie |
| `sameSite` | ✅ | — | Prevents CSRF for most cases |
| `secure` | ❌ | ✅ | Cookie can be sent over HTTP — **VULNERABILITY** |
| `secrets` | ✅ | — | Cookie is encrypted |

## Steps to Reproduce

### Step 1: Deploy a Hydrogen app with the skeleton template
The default skeleton template does not set the `secure` flag on the session cookie.

### Step 2: Inspect the Set-Cookie header
```bash
curl -v "https://<hydrogen-app>/account_.login" 2>&1 | grep -i "set-cookie"
```

**Response**:
```
Set-Cookie: session=...; Path=/; HttpOnly; SameSite=Lax
```

Note the absence of the `Secure` flag.

### Step 3: Intercept the cookie over HTTP
If the app has any HTTP endpoint (e.g., due to a misconfiguration or load balancer issue), the cookie can be intercepted:

```bash
# If the app is accessible over HTTP
curl -v "http://<hydrogen-app>/account_.login" 2>&1 | grep -i "set-cookie"
```

The cookie will be sent over HTTP, allowing a network attacker to intercept it.

### Step 4: Session hijacking
An attacker who intercepts the session cookie can use it to impersonate the victim:

```bash
curl -H "Cookie: session=<intercepted-cookie>" "https://<hydrogen-app>/account"
```

## PoC / Bukti

### Source Code Evidence
**File**: `templates/skeleton/app/lib/session.ts`

```typescript
static async init(request: Request, secrets: string[]) {
  const storage = createCookieSessionStorage({
    cookie: {
      name: 'session',
      httpOnly: true,
      path: '/',
      sameSite: 'lax',
      secrets,
      // VULNERABILITY: secure flag is not set
    },
  });

  const session = await storage
    .getSession(request.headers.get('Cookie'))
    .catch(() => storage.getSession());

  return new this(storage, session);
}
```

### Response Evidence
When accessing a Hydrogen app deployed with the skeleton template:

```
HTTP/1.1 200 OK
Set-Cookie: session=eyJ...; Path=/; HttpOnly; SameSite=Lax
```

The `Secure` flag is missing from the `Set-Cookie` header.

### Impact on Customer Account API
The session cookie stores sensitive data including:
- Customer access tokens
- Refresh tokens
- ID tokens
- Nonce values
- Redirect paths

If the cookie is intercepted, all of this data is compromised.

## Impact (user data / finansial / reputasi — konkret)
- **Session hijacking**: An attacker who intercepts the session cookie over HTTP can impersonate the victim.
- **Customer account takeover**: The session cookie contains customer access tokens, allowing the attacker to access the victim's customer account.
- **Data theft**: The attacker can access the victim's orders, payment methods, and personal information.
- **Financial fraud**: The attacker can make purchases or modify orders using the stolen session.

## Remediation
1. **Set the `secure` flag**: Add `secure: true` to the cookie configuration:
```typescript
const storage = createCookieSessionStorage({
  cookie: {
    name: 'session',
    httpOnly: true,
    secure: true,  // ADD THIS
    path: '/',
    sameSite: 'lax',
    secrets,
  },
});
```

2. **Use environment-based configuration**: Set `secure: process.env.NODE_ENV === 'production'` to allow HTTP in development but enforce HTTPS in production.

3. **Add `maxAge` or `expires`**: Set an appropriate expiration time for the session cookie.

4. **Audit all cookie configurations**: Check all cookies set by the application (including cart, localization, and multipass cookies) for the `secure` flag.

## CVSS 3.1
**Vector**: `CVSS:3.1/AV:N/AC:H/PR:N/UI:N/S:U/C:H/I:N/A:N`
**Score**: 5.9 (Medium)

Rationale: Network exploitable, high complexity (requires network interception or HTTP access), no privileges required, no user interaction. Confidentiality impact is high (session token theft). The complexity is rated high because the attacker needs to be able to intercept HTTP traffic.

## Referensi
- **CWE-614**: Sensitive Cookie in HTTPS Session Without 'Secure' Attribute
- **CWE-1004**: Sensitive Cookie Without 'HttpOnly' Flag
- **File**: `templates/skeleton/app/lib/session.ts` — `AppSession.init()` method
- **OWASP**: https://owasp.org/www-community/controls/SecureCookie
