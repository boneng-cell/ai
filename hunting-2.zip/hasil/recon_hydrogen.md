# Hydrogen Reconnaissance Report

**Repo:** https://github.com/Shopify/hydrogen  
**Branch scanned:** `main` (fallback `master`) — 1622 files in tree, saved to `hasil/trees/hydrogen.txt`  
**Date:** 2026-08-09  

## 1. Stack Summary

| Layer | Technology |
|---|---|
| Framework | React Router 7.16.0 (Remix evolution), Vite 8 |
| SSR / edge | React DOM server streaming (`renderToReadableStream`), MiniOxygen + Workers (Oxygen) |
| Packages | Monorepo (pnpm/turbo workspaces): `packages/{cli,hydrogen,hydrogen-react,hydrogen-codegen,mini-oxygen,create-hydrogen,remix-oxygen}` + `templates/skeleton` + `cookbook` |
| Auth model | Customer Account API (OAuth 2.0/OIDC) **and** legacy Storefront API `customerAccessTokenCreate` (multipass recipe) |
| Session store | `react-router`'s `createCookieSessionStorage` (cookie: `session`, httpOnly, SameSite=Lax) — see `templates/skeleton/app/lib/session.ts` |
| Analytics | Legacy Trekkie/monorail (`analytics-constants`, `analytics-schema-trekkie`) + Customer Privacy Consent SDK (`ShopifyCustomerPrivacy.tsx`) |
| Secrets | `SESSION_SECRET`, `PUBLIC_*`, `PRIVATE_*`, `SHOP_ID`, plus cookboook-added `PRIVATE_SHOPIFY_STORE_MULTIPASS_SECRET` |

### Key versions
- hydrogen `2026.4.4`, react-router `7.16.0`, react `18.3.1`, node `^22 || ^24`, pnpm `>=10.16.1`.
- `createCustomerAccountHelper` uses API version `2026-04` (hard-coded `DEFAULT_CUSTOMER_API_VERSION`).
- Static OAuth public client id `30243aa5-17c1-465a-8493-944bcc4e88aa`.

## 2. Architecture / Entry Points

- **App entry points:** `templates/skeleton/app/entry.client.tsx`, `templates/skeleton/app/entry.server.tsx` (CSP via `createContentSecurityPolicy`, isbot gating).
- **Server entry (Node/Express):** `cookbook/recipes/express/ingredients/templates/skeleton/server.mjs` defines its own `AppSession` + `createHydrogenContext`.
- **Router config:** `templates/skeleton/react-router.config.ts` → `hydrogenPreset()` from `@shopify/hydrogen/react-router-preset`.
- **Context bootstrap:** `packages/hydrogen/src/createHydrogenContext.ts` builds `{storefront, customerAccount, cart, env, session, waitUntil}` and calls `createCustomerAccountClient` + `createStorefrontClient` + `createCartHandler`.

## 3. Auth Model

Two parallel auth models exist; the default **uses the Customer Account API**, the **multipass recipe swaps to Storefront API tokens**.

### A. Customer Account API (default skeleton)
1. `account_.login.tsx` → `context.customerAccount.login()` builds an OAuth authorize URL `https://shopify.com/{shopId}/authentication/{shopId}/oauth/authorize` with `code_challenge=S256`, `state`, `nonce`, `redirect_uri` (must be `https` / Hydrogen tunnel in dev — `checkTunnelDomain`).
2. `account_.authorize.tsx` → `context.customerAccount.authorize()` exchanges the `code` at `/oauth/token` (PKCE), validates `nonce`, then (for non-Plus shops) calls `exchangeAccessToken` (token-exchange grant) to get a customer-scoped token. Token + refresh token stored on `session` under key `customerAccount`.
3. Token lifecycle: `checkExpires` refreshes when `expiresAt - 1000 < now`; refresh errors throw `invalid_grant` only when OAuth error field is `invalid_grant`.
4. Logout: `account_.logout.tsx` → `context.customerAccount.logout()` hits `/logout` with `id_token_hint`/`post_logout_redirect_uri`, then `clearSession` + `session.destroy`.
5. Protected routes call `context.customerAccount.handleAuthStatus()` which `throw`s a `redirect()` to `/account/login?return_to=<current path>` (the app's own `return_to`, NOT the OAuth `state`).

### B. Legacy/Storefront API (multipass recipe)
- Login form POSTs `customerAccessTokenCreate` (Storefront mutation) → stores `{accessToken, expiresAt}` under session key `customerAccessToken` (custom, app-level).
- Logout removes `customerAccessToken`.
- A `validateCustomerAccessToken` helper compares `expiresAt` to `Date.now()` and clears stale tokens.

## 4. Cookie / Session Handling

- **Session cookie** (`templates/skeleton/app/lib/session.ts`): `httpOnly: true`, `sameSite: 'lax'`, `path: '/'`, **no `secure` flag set explicitly**, secrets = `[env.SESSION_SECRET]`. Express recipe uses identical flags. ⚠️ `secure` is not set — relies on platform (Oxygen forces HTTPS) but is a misconfiguration risk for self-hosted deployments.
- **Analytics cookies** via `useShopifyCookies` / `cookies-utils.tsx`: JS-written `_shopify_y`/`_shopify_s` with `samesite: 'Lax'`, `path: '/'`, long/short expiry, **no `Secure` attribute**. Cookie domain derived from `window.location.host` or an override; leading-dot added for checkout domain. Domain is computed by suffix matching against `checkoutDomain` — see `useShopifyCookies`.

## 5. Multipass Implementation (focus)

Files (recipe under `cookbook/recipes/multipass/`):
- `app/lib/multipass/multipassify.server.ts` — `Multipassify` class (AES-CBC + HMAC-SHA256, IV prepended, Base64url).
- `app/lib/multipass/multipass.ts` — browser helper POSTing to `/account/login/multipass`.
- `app/lib/multipass/types.ts` — `MultipassCustomer` (`email`, `return_to`, extra).
- `app/routes/account_.login.multipass.tsx` — the route handler.
- `app/components/MultipassCheckoutButton.tsx`.

### Flow
1. Browser POSTs `{return_to}` to `/account/login/multipass`.
2. Route reads `session.get('customerAccessToken')`; if absent → `handleLoggedOutResponse`. If checkout URL (`/cart/c/...?key=` regex) and logged out, returns `https://{checkoutDomain}/account/logout?return_url=...&step=contact_information` (logs user out of checkout).
3. Looks up customer via `CUSTOMER_INFO_QUERY`; requires `email`. **Critically, the `return_to` from the client request body is the value ultimately placed into the token** (the customer's `return_to` from the storefront mutation is ignored/overwritten by `body?.return_to`).
4. `generate()` builds `https://{shopifyDomain}/account/login/multipass/{token}` (checkout) **or** `{toOrigin}/account/login/multipass/{token}` (local) depending on whether `return_to` contains `cart/c` or `checkout`.
5. `Multipassify.generateToken` sets `customer.created_at = new Date().toISOString()`; `parseToken` validates `customer.created_at > now` (only future-dated tokens rejected — **no max-age / expiry ceiling**).

## 6. Return_to / Redirect Handling (focus)

- `get-redirect-url.ts` (`packages/hydrogen/src/utils/get-redirect-url.ts`): `getRedirectUrl` reads `return_to` or `redirect` from the query string, **only follows the URL if `isLocalPath` (same origin)** — good, blocks open redirect to external hosts. `ensureLocalRedirectUrl` enforces local redirect with fallback.
- `storefrontRedirect` (`packages/hydrogen/src/routing/redirect.ts`) deletes `redirect`/`return_to`/`_routes` query params from the outgoing redirect target, but then **re-appends all original search params** (including a new `return_to`) to the target in `createRedirectResponse` when `matchQueryParams` is false. ⚠️ This merges original params onto the redirect target.
- OAuth `state` is generated server-side and the session is the source of truth; `oauth_recovery` prefix path exists for the "browser dropped cookie mid-OAuth" case.

## 7. Cache / SSR Configuration

- `headers` set in `account.tsx`: `Cache-Control: no-cache, no-store, must-revalidate` on the account loader.
- `react-router.config.ts` uses `hydrogenPreset()` — prerendering off, server rendering enabled.
- Root `shouldRevalidate` returns false (no revalidation) except on mutations; relies on `cache` options e.g. `storefront.CacheLong()` for header/footer menu.
- Cart mutations set cart ID cookie; buyer identity flows use `BUYER_SESSION_KEY`.
- `entry.server.tsx`: CSP built with `createContentSecurityPolicy` using store/checkout domains.
- Static assets: `maxAge` 1y (build/client/assets) + 1d (build/client), plus a `/favicon.ico → /favicon.svg` redirect in Express recipe.

## 8. Key Files to Examine for Vulnerability Hunting

| Topic | File (raw.githubusercontent/main) | Notes |
|---|---|---|
| Session cookie config | `templates/skeleton/app/lib/session.ts` | Flags: httpOnly/SameSite set, **Secure absent** |
| Session cookie config (express) | `cookbook/recipes/express/ingredients/templates/skeleton/server.mjs` | Identical flags — no `secure` |
| Multipass token gen/verify | `cookbook/recipes/multipass/ingredients/templates/skeleton/app/lib/multipass/multipassify.server.ts` | AES-CBC+HMAC; `created_at` check only — **no max age** |
| Multipass client helper | `cookbook/recipes/multipass/ingredients/templates/skeleton/app/lib/multipass/multipass.ts` | POSTs `return_to` to own API |
| Multipass types | `cookbook/recipes/multipass/ingredients/templates/skeleton/app/lib/multipass/types.ts` | `MultipassCustomer.return_to` is user data |
| Multipass route handler | `cookbook/recipes/multipass/ingredients/templates/skeleton/app/routes/account_.login.multipass.tsx` | `body.return_to` trusted into token URL |
| Multipass checkout button | `cookbook/recipes/multipass/ingredients/templates/skeleton/app/components/MultipassCheckoutButton.tsx` | |
| Login route (CAPI) | `templates/skeleton/app/routes/account_.login.tsx` | Query params → OAuth `authorize` |
| Logout route (CAPI) | `templates/skeleton/app/logout.tsx` | |
| Authorize callback | `templates/skeleton/app/routes/account_.authorize.tsx` | |
| Auth status / redirect | `templates/skeleton/app/routes/account.$.tsx` | `handleAuthStatus` |
| Redirect validation | `packages/hydrogen/src/utils/get-redirect-url.ts` | `isLocalPath` guard |
| Storefront redirect | `packages/hydrogen/src/routing/redirect.ts` | param merge behavior |
| Customer account client | `packages/hydrogen/src/customer/customer.ts` | OAuth PKCE + token exchange |
| Auth helpers (token) | `packages/hydrogen/src/customer/auth.helpers.ts` | refresh/nonce/state |
| Context bootstrap | `packages/hydrogen/src/createHydrogenContext.ts` | |
| Analytics cookies | `packages/hydrogen-react/src/useShopifyCookies.tsx` & `cookies-utils.tsx` | JS cookie flags |
| Customer privacy/consent | `packages/hydrogen/src/customer-privacy/ShopifyCustomerPrivacy.tsx` | |
| Types/env | `packages/hydrogen/src/types.d.ts` (`HydrogenEnv`) | |
| Multipass env patch | `cookbook/recipes/multipass/patches/env.d.ts.2e612c.patch` | adds PRIVATE secret |
| Multipass root patch | `cookbook/recipes/multipass/patches/root.tsx.8f1e92.patch` | `validateCustomerAccessToken` |
| Multipass login patch | `cookbook/recipes/multipass/patches/account_.login.tsx.a8f71d.patch` | Storefront token model |
| Multipass logout patch | `cookbook/recipes/multipass/patches/account_.logout.tsx.2930de.patch` | |
| Multipass cart patch | `cookbook/recipes/multipass/patches/cart.tsx.825f67.patch` | buyer identity token |
| CSP builder | (in `@shopify/hydrogen`) `packages/hydrogen/src/csp/*` | CSP on SSR response |
| Tests/fixtures | `e2e/fixtures/multipass-utils.ts`, `e2e/specs/recipes/multipass.spec.ts` | |

## 9. Initial Observations / Potential Issues

1. **Missing `secure` cookie flag** on the `session` cookie (`session.ts`) and on JS analytics cookies (`_shopify_y`/`_shopify_s`). Works on Oxygen (HTTPS-mandated) but is a real defect for self-hosted/Express deployments over HTTP or behind misconfigured TLS.
2. **Multipass `return_to` is attacker-controlled and placed directly into the generated token** (`account_.login.multipass.tsx`). The `generate()` branching only distinguishes checkout vs local — it does **not** validate that `return_to` is on an allow-list or same-origin. `toOrigin` is taken from `request.url`, so a crafted `Origin` could redirect to an arbitrary host for the local (non-checkout) case. Open-redirect / phishing surface inside the Plus-only flow.
3. **No token expiry ceiling** in `Multipassify.parseToken` — it only rejects `created_at > now`. There is **no upper bound** on token age; an intercepted/captured token (e.g., viaReferer leakage) remains valid indefinitely.
4. **`console.log('Generating multipass token for customer:', customer?.email)`** and `console.log('⚠️ Bypassing multipass checkout due to', …)` leak PII (email) and error details to logs.
5. **CORS in multipass route** (`getCorsHeaders`) reflects the request `Origin` into `Access-Control-Allow-Origin` (echo) without an explicit allow-list comment toggle — default is origin-only, which is safe, but the comment invites adding `'https://example.com'`; any added entry is echo-matched via `origin.includes(...)`.
6. **Cross-domain redirect param merge** in `storefrontRedirect.createRedirectResponse` — when `matchQueryParams` is false, original search params (including a user-controlled `return_to`) are appended to the redirect target; combined with `getRedirectUrl`'s local-path check this is mostly bounded, but the merged target could carry surprising params to the destination.
7. **OAuth state-recovery** path uses query param `oauth_recovery=true` and restarts login with `return_to` from the session — worth confirming `redirectPath` can't be set to an out-of-scope value by the client (it is set server-side in `login()`, but `return_to` on the public `/account/login` is read from the URL and stored to `redirectPath`).
8. **Express recipe** duplicates the session implementation and reuses `createHydrogenContext` from the main package; note `waitUntil: null` and a hand-rolled `AppSession` — parity/cookie-flag drift risk.
9. **Static OAuth client id** `30243aa5...` is public by design (public client), but combined with PKCE and `code_verifier` stored in session it is acceptable; confirm `nonce`/`state` are always compared (they are).
10. **`customerAccessToken` (multipass recipe) stored in session with `expiresAt` validated only by the app helper** — no server-side revocation; logout merely unsets the key.
