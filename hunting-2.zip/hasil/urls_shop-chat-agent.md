# URLs / Domains / Endpoints - shop-chat-agent

## Environment Configuration
| Key | Value |
|---|---|
| `REDIRECT_URL` | `https://localhost:3458/auth/callback` |
| `CLAUDE_API_KEY` | _(user-supplied)_ |
| `SHOPIFY_API_KEY` | _(user-supplied)_ |

## Static Configuration URLs
| File | URL |
|---|---|
| `shopify.app.toml` | `application_url = "https://shop-chat-agent.com"` |
| `shopify.app.toml` | `redirect_urls = [ "https://shop-chat-agent.com/api/auth" ]` |
| `shopify.app.toml` | `customer_authentication.redirect_uris = [ "https://shop-chat-agent.com/callback" ]` |
| `.env.example` | `REDIRECT_URL=https://localhost:3458/auth/callback` |

## Client-Side (chat.js) API Endpoints
| URL | Method | Purpose |
|---|---|---|
| `https://localhost:3458/chat` | POST | SSE streaming chat endpoint |
| `https://localhost:3458/chat?history=true&conversation_id=XYZ` | GET | Fetch conversation history |
| `https://localhost:3458/auth/token-status?conversation_id=XYZ` | GET | Poll for customer token availability |

## Server-Side Route Endpoints
| Route File | Path | Methods | Notes |
|---|---|---|---|
| `app/routes/chat.jsx` | `/chat` | GET, POST, OPTIONS | Main chat SSE endpoint; no auth required |
| `app/routes/auth.callback.jsx` | `/auth/callback` | GET | OAuth PKCE callback; exchanges code for token |
| `app/routes/auth.token-status.jsx` | `/auth/token-status` | GET, OPTIONS | Checks if customer token exists for conversation |
| `app/routes/api.webhooks.jsx` | `/webhooks/app/uninstalled` | POST | Webhook handler for APP_UNINSTALLED |
| `app/routes/_index/route.jsx` | `/` | GET | Redirects to `/app?shop=<shop>` |
| `app/routes/app.jsx` | `/app` | GET | Admin auth-protected app shell |
| `app/routes/app._index.jsx` | `/app/` | GET | Admin home page |
| `app/routes/auth.$.jsx` | `/auth/*` | GET | Shopify OAuth redirect catch-all |

## External Discovery / Well-Known Endpoints (Dynamically Fetched)
From `app/routes/chat.jsx` `getCustomerAccountUrls()`:
| URL Pattern | Source |
|---|---|
| `https://{hostname}/.well-known/customer-account-api` | Derived from `Origin` header |
| `https://{hostname}/.well-known/openid-configuration` | Derived from `Origin` header |

## MCP (Model Context Protocol) Endpoints
From `app/mcp-client.js`:
| URL Pattern | Description |
|---|---|
| `{hostUrl}/api/mcp` | Storefront MCP JSON-RPC endpoint (no auth) |
| `{accountHostUrl}/customer/api/mcp` | Customer MCP JSON-RPC endpoint (Bearer token) |

Where `accountHostUrl` = `hostUrl` with `.myshopify.com` -> `.account.myshopify.com`

## OAuth / Auth Flow Endpoints
From `app/auth.server.js` and `app/routes/auth.callback.jsx`:
| URL | Source |
|---|---|
| Auth URL (authorization endpoint) | Fetched from `.well-known/openid-configuration` → `authorization_endpoint` |
| Token URL (token endpoint) | Fetched from `.well-known/openid-configuration` → `token_endpoint` |
| `client_id` = `process.env.SHOPIFY_API_KEY` | Env var |
| Scope: `customer-account-mcp-api:full` | Hardcoded in auth.server.js |
| PKCE `code_challenge_method`: `S256` | Hardcoded |
| `redirect_uri`: `process.env.REDIRECT_URL` | Env var |

## External Libraries / CDNs
| URL | Used By |
|---|---|
| `https://cdn.shopify.com/` | Fonts (Inter), assets |
| `https://cdn.shopify.com/static/fonts/inter/v4/styles.css` | root.jsx |
| `https://cdn.shopify.com/s/files/1/0533/2089/files/placeholder-images-image_large.png` | chat.js (placeholder image) |
| `@anthropic-ai/sdk` API: `https://api.anthropic.com` | claude.server.js |
| `@shopify/dev-mcp` (npx) | .mcp.json, .cursor/mcp.json |

## State Parameter Format
- `state = "${conversationId}-${shopId}"` (auth.server.js)
- `conversationId = body.conversation_id || Date.now().toString()` (chat.jsx)

## Session / Conversation ID Format
- `conversationId` = timestamp string (e.g., `"1634567890123"`)
- Stored in `sessionStorage` on client as `shopAiConversationId`

## Key Observations
1. **No authentication** on the `/chat` endpoint — any client can POST/GET.
2. **Wildcard-origin CORS** — `Origin` header is reflected directly in `Access-Control-Allow-Origin` and `Access-Control-Allow-Credentials: true`.
3. **SSRF risk** — `Origin` header is used to derive `hostname` for `.well-known` fetches and MCP endpoint construction.
4. **`redirect_uri`** in OAuth flow comes from env var, not validated against actual Origin.
