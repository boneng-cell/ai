# Reconnaissance Report: Shopify/subscriptions-reference-app

**Date:** 2026-08-09  
**Repository:** https://github.com/Shopify/subscriptions-reference-app  
**Default Branch:** `main`  
**Language:** TypeScript (100%)  
**Framework:** Remix v2.16.8 + Shopify App Remix v3.8.3  
**Stargazers:** 162 | **Forks:** 46 | **Open Issues:** 9  

---

## 1. Stack Summary

| Layer               | Technology                                                              |
|---------------------|-------------------------------------------------------------------------|
| Runtime             | Node.js (ESM `"type": "module"`)                                        |
| Web Framework       | Remix v2.16.8 (Vite-based build)                                        |
| Shopify Auth        | `@shopify/shopify-app-remix` v3.8.3                                     |
| Shopify API         | `@shopify/shopify-api` v11.13.0, API version `unstable`, REST `2023-07` |
| Admin API Client    | `@shopify/admin-api-client` v1.1.0                                      |
| UI                  | `@shopify/polaris` v13.9.5, `@shopify/app-bridge-react` v4.1.10        |
| UI Extensions       | `@shopify/ui-extensions` v2025.7.0                                      |
| ORM / DB            | Prisma v6.10.1 + `@prisma/client`, SQLite (`file:./data.db`)             |
| Session Storage     | Memory (test) / Prisma (prod)                                           |
| Job Queue           | Custom `JobRunner` — supports Inline, Test, Google Cloud Tasks          |
| Task Queue (Cloud)  | `@google-cloud/tasks` v6.1.0                                          |
| Cloud Storage       | `@google-cloud/storage` v7.16.0                                         |
| GraphQL Codegen     | `@shopify/api-codegen-preset` v1.1.8                                    |
| i18n                | `i18next` + `@shopify/i18next-shopify`                                  |
| Form/Validation     | `zod` v3.25.67, `@rvf/remix` v6.3.0, `@rvf/react` v7.1.5               |
| Testing             | `vitest` v3.2.4, `@testing-library/react` v16.3.0                      |
| HTTP Mocking        | `msw` v2.10.2 (test fixtures)                                           |
| Logging             | `pino` v9.7.0 + `pino-pretty` v13.0.0                                   |
| Address Parsing     | `@shopify/address` v4.3.0                                               |
| Date/Time           | `luxon` v3.6.1                                                            |

**Key Dev Tooling:** TypeScript 5.8.3, ESLint 9.30.0, Prettier 3.6.2, Vite 6.3.5

---

## 2. File Tree Overview (1,338 files)

See: `hasil/trees/subscriptions-reference-app.txt`

Notable top-level directories and files:
- `app/` — Main application source
- `app/routes/` — Remix file-based routes
- `app/jobs/` — Background job definitions
- `app/lib/jobs/` — Job framework (Job, JobRunner, schedulers)
- `app/models/` — Data access layer (Prisma + Shopify GraphQL)
- `app/services/` — Business logic services
- `app/graphql/` — GraphQL query/mutation definitions
- `app/types/` — TypeScript types (jobs, webhooks, contracts, plans)
- `app/utils/` — Utilities (helpers, bulk operations, metaobjects)
- `extensions/` — UI Extensions (admin-subs-action, buyer-subscriptions, thank-you-page)
- `config/` — Runtime configuration
- `prisma/schema.prisma` — Database schema
- `test/` — Test utilities, factories, constants
- `shopify.app.toml` — Shopify app configuration
- `.graphqlrc.ts` — GraphQL Codegen configuration

---

## 3. Entry Points

| File                          | Role                                      |
|-------------------------------|-------------------------------------------|
| `app/entry.server.tsx`        | Server entry point, SSR with i18n, CSP    |
| `app/entry.client.tsx`        | Client entry point (hydration)            |
| `app/routes.ts`               | Route config (uses flatRoutes)            |
| `app/shopify.server.ts`       | Shopify app initialization (oauth/webhooks)|
| `app/db.server.ts`            | Prisma client export                      |
| `config/index.ts`             | Runtime config (logger, jobs scheduler)   |
| `app/jobs/index.ts`           | Job registry initialization               |

---

## 4. Endpoint List

### 🔴 Internal / Infrastructure

| Method | Endpoint             | Auth      | File                          | Description                          |
|--------|----------------------|-----------|-------------------------------|--------------------------------------|
| POST   | `/internal/jobs/run` | **NONE**  | `app/routes/internal.jobs.run.tsx` | Dispatches a job by name from JSON body |
| GET    | `/services/ping`     | None      | `app/routes/services.ping.tsx`   | DB connectivity healthcheck        |

### Webhooks (HMAC-verified via `authenticate.webhook`)

| Method | Endpoint                                      | Webhook Topic(s)                  | File                                        |
|--------|------------------------------------------------|-----------------------------------|---------------------------------------------|
| POST   | `/webhooks/app/uninstalled`                    | `app/uninstalled`                 | `app/routes/webhooks.app.uninstalled.tsx`   |
| POST   | `/webhooks/subscription_contracts/create`      | `subscription_contracts/create`   | `app/routes/webhooks.subscription_contracts.create.tsx` |
| POST   | `/webhooks/subscription_contracts/activate`    | `subscription_contracts/activate` | `app/routes/webhooks.subscription_contracts.activate.tsx` |
| POST   | `/webhooks/subscription_contracts/cancel`      | `subscription_contracts/cancel`   | `app/routes/webhooks.subscription_contracts.cancel.tsx` |
| POST   | `/webhooks/subscription_contracts/pause`       | `subscription_contracts/pause`    | `app/routes/webhooks.subscription_contracts.pause.tsx` |
| POST   | `/webhooks/subscription_billing_cycles/skip`   | `subscription_billing_cycles/skip`| `app/routes/webhooks.subscription_billing_cycles.skip.tsx` |
| POST   | `/webhooks/subscription_billing_attempts/success` | `subscription_billing_attempts/success` | `app/routes/webhooks.subscription_billing_attempts.success.tsx` |
| POST   | `/webhooks/subscription_billing_attempts/failure` | `subscription_billing_attempts/failure` | `app/routes/webhooks.subscription_billing_attempts.failure.tsx` |
| POST   | `/webhooks/selling_plan_groups/create_or_update` | `selling_plan_groups/create`, `selling_plan_groups/update` | `app/routes/webhooks.selling_plan_groups.create_or_update.tsx` |
| POST   | `/webhooks/customer_redact`                    | `customers/data_request`, `customers/redact` | `app/routes/webhooks.customer_redact.ts`  |
| POST   | `/webhooks/shop_redact`                        | `shop/redact`                     | `app/routes/webhooks.shop_redact.ts`        |
| POST   | `/webhooks/cli`                                | Any (CLI manual trigger)          | `app/routes/webhooks.cli.tsx`             |

### Customer Account API

| Method | Endpoint               | Auth                              | File                          |
|--------|------------------------|-----------------------------------|-------------------------------|
| GET    | `/customerAccount/emails` | `authenticate.public.customerAccount` | `app/routes/customerAccount.emails.ts` |
| POST   | `/customerAccount/emails` | `authenticate.public.customerAccount` | `app/routes/customerAccount.emails.ts` |

### App Routes (Admin, OAuth-authenticated)

| Method | Route Pattern                          | File                              | Action                            |
|--------|----------------------------------------|-----------------------------------|-----------------------------------|
| GET/POST | `/app/contracts/$id`                  | `app/routes/app.contracts.$id._index/route.tsx` | View/edit contract details  |
| POST   | `/app/contracts/$id/address-update`   | `app/routes/app.contracts.$id.address-update/route.ts` | Update delivery address    |
| POST   | `/app/contracts/$id/bill-contract`     | `app/routes/app.contracts.$id.bill-contract/route.ts` | Charge billing cycle by index |
| POST   | `/app/contracts/$id/billing-cycle-skip`| `app/routes/app.contracts.$id.billing-cycle-skip/route.ts` | Skip/resume billing cycle |
| POST   | `/app/contracts/$id/cancel`            | `app/routes/app.contracts.$id.cancel/route.ts` | Cancel subscription          |
| POST   | `/app/contracts/$id/edit`              | `app/routes/app.contracts.$id.edit/route.tsx` | Edit subscription (draft)  |
| POST   | `/app/contracts/$id/pause`             | `app/routes/app.contracts.$id.pause/route.ts` | Pause subscription          |
| POST   | `/app/contracts/$id/payment-update`    | `app/routes/app.contracts.$id.payment-update/route.ts` | Send payment update email |
| POST   | `/app/contracts/$id/poll-bill-attempt` | `app/routes/app.contracts.$id.poll-bill-attempt/route.ts` | Poll billing attempt   |
| POST   | `/app/contracts/$id/resume`            | `app/routes/app.contracts.$id.resume/route.ts` | Resume subscription          |
| POST   | `/app/contracts/bulk-operation`        | `app/routes/app.contracts.bulk-operation.ts` | Bulk pause/activate         |
| GET    | `/app/bulk-operation`                  | `app/routes/app.bulk-operation.ts` | Poll bulk operation status       |
| GET/POST | `/app/plans`                          | `app/routes/app.plans._index/route.tsx` | Selling plan groups list   |
| GET/POST | `/app/plans/$id`                      | `app/routes/app.plans.$id/route.tsx` | Edit selling plan group     |
| POST   | `/app/plans/$id/delete`                | `app/routes/app.plans.$id.delete/route.tsx` | Delete selling plan group |
| GET/POST | `/app/settings`                        | `app/routes/app.settings._index/route.tsx` | App settings              |

### Static Pages
- `/missing-scopes` — `app/routes/missing-scopes._index/route.tsx`
- `/maintenance` — `app/routes/maintenance._index/route.tsx`
- `/auth/login` — `app/routes/auth.login/route.tsx`

---

## 5. Auth Model

### OAuth / Admin Authentication
- `shopifyApp()` from `@shopify/shopify-app-remix/server` (configured in `app/shopify.server.ts`)
- API key: `process.env.SHOPIFY_API_KEY`
- API secret: `process.env.SHOPIFY_API_SECRET`
- Auth path prefix: `/auth`
- Session storage: `MemorySessionStorage` (test) / `PrismaSessionStorage` (prod)
- Embedded app: `true`; Distribution: `AppDistribution.AppStore`
- Future flag: `unstable_newEmbeddedAuthStrategy: true`

### Webhook HMAC Verification
- All webhook routes call `authenticate.webhook(request)` from `@shopify/shopify-app-remix`
- Standard Shopify HMAC verification: checks `X-Shopify-Hmac-Sha256` header
- API version: `unstable`

### Customer Account Authentication
- `customerAccount.emails.ts` uses `authenticate.public.customerAccount(request)`
- Verifies session token (JWT) from customer account
- **Silent failure**: On auth failure, the route returns early without error

### Access Scopes (shopify.app.toml)
```
customer_read_customers, customer_read_orders, customer_read_own_subscription_contracts,
customer_write_customers, customer_write_own_subscription_contracts,
read_all_orders, read_locales, read_locations, read_themes,
write_customer_payment_methods, write_customers, write_metaobject_definitions,
write_metaobjects, write_orders, write_own_subscription_contracts,
write_products, write_translations, read_analytics
```

---

## 6. Data Flow

### Webhook → Job Enqueue → Job Execution
1. **Webhook received** → `authenticate.webhook(request)` verifies HMAC → extracts `{topic, shop, payload}` → constructs Job instance → `jobs.enqueue(job)`
2. **Job enqueued** via scheduler:
   - **INLINE** (prod/default): `InlineScheduler.enqueue` → serializes → `Reflect.construct` → `instance.run()`
   - **CLOUD_TASKS**: `CloudTaskScheduler.enqueue` → creates GCP Cloud Task with OIDC token to `callbackUrl` (/internal/jobs/run)
   - **TEST**: `TestScheduler.enqueue` → stores in array, returns Request object
3. **Job.run()** → calls `perform()` → uses `unauthenticated.admin(shop)` → Shopify Admin API GraphQL mutations
4. Error handling: terminal errors (401/402/403/404/423, SessionNotFound, MaxMetaobjects) don't retry; others throw and retry

### Contract Edit Flow (Draft Pattern)
1. `SubscriptionContractUpdate` mutation → creates draft from contract
2. Draft operations via `SubscriptionContractDraft` class: `addLine`, `updateAddress`, `updateLine`, `removeLine`, `update`, `removeDiscount`, `getDiscounts`, `commit`
3. `SubscriptionContractDraftCommitMutation` → commits draft

### Billing Flow
1. `RecurringBillingChargeJob` → calculates `targetDate` → `ScheduleShopsToChargeBillingCyclesJob` → finds billable schedules → `ChargeBillingCyclesJob` → `subscriptionBillingCycleBulkCharge` mutation
2. `RebillSubscriptionJob` → `subscriptionBillingCycleCharge` with `originTime` for individual contract billing

### Dunning Flow
- `subscription_billing_attempts/failure` webhook → `DunningStartJob`
- `subscription_billing_attempts/success` webhook → `DunningStopJob`
- Uses Prisma `DunningTracker` table for state tracking

### Database (Prisma + SQLite)
- `Session` — Shopify OAuth sessions (access tokens, shop domains)
- `BillingSchedule` — Per-shop billing schedule config (hour, timezone, active)
- `DunningTracker` — Tracks dunning attempts per billing cycle failure

---

## 7. Key Files for Vulnerability Hunting

### 🔴 CRITICAL: Unauthenticated Job Execution Endpoint

**File:** `app/routes/internal.jobs.run.tsx` — The `/internal/jobs/run` endpoint has **NO authentication**.

```typescript
export async function action({request, context}: ActionFunctionArgs) {
  await addShopToContext(request, context);  // only extracts shop for logging
  await jobs.execute(request);  // executes arbitrary registered job
  return json({status: 'success'}, {status: 200});
}
```

**JobRunner.execute()** (`app/lib/jobs/JobRunner.ts`):
```typescript
const payload = await request.json();
const {jobName, parameters} = payload;
const JobClass = this.registry.get(jobName);
const instance = Reflect.construct(JobClass, [parameters]);
await instance.run();
```

**Attack vector:** An attacker can POST to `/internal/jobs/run` with:
```json
{"jobName": "RebillSubscriptionJob", "parameters": {"shop": "victim.myshopify.com", "payload": {"subscriptionContractId": "...", "originTime": "..."}}}
```
This executes any registered job with attacker-controlled parameters, targeting any Shopify shop.

### 🔴 CRITICAL: Unauthenticated Admin API Access

All job `perform()` methods use `unauthenticated.admin(shop)` where `shop` comes from the job payload. Combined with the unauthenticated `/internal/jobs/run` endpoint, this allows an attacker to trigger Shopify Admin API calls (billing charges, contract cancellations, etc.) against any shop.

**Files to check:**
- `app/jobs/billing/RebillSubscriptionJob.ts:20` — `originTime` passed directly to mutation
- `app/jobs/billing/ChargeBillingCyclesJob.ts` — date range from payload
- `app/jobs/billing/RecurringBillingChargeJob.ts` — uses `DateTime.utc()` (safe)
- `app/jobs/dunning/DunningStopJob.ts` — uses `originTime` from billing attempt
- `app/jobs/dunning/DunningStartJob.ts` — failure reason from payload

### 🔴 HIGH: `originTime` is Untrusted in RebillSubscriptionJob

**File:** `app/jobs/billing/RebillSubscriptionJob.ts`

The `originTime` parameter selects which billing cycle to charge:
```graphql
subscriptionBillingCycleCharge(subscriptionContractId: $subscriptionContractId, billingCycleSelector: { date: $originTime })
```
No validation on the `originTime` value — attacker could charge the wrong billing cycle.

### HIGH: Client-Supplied Address JSON Parse (UpdateAddress)

**File:** `app/routes/app.contracts.$id.address-update/route.ts`

```typescript
const address = body.get('address') as string;
const addressObject = JSON.parse(address);  // no schema validation
const result = await draft.updateAddress(addressObject, deliveryMethodName);
```
The `address` and `deliveryMethodName` from form data are parsed and passed directly to the draft update without zod/schema validation.

### HIGH: `customerAccount.emails.ts` — operationName Controls Job Type

**File:** `app/routes/customerAccount.emails.ts`

The `operationName` from the request body controls which email template is sent. The route catches non-PAUSE/RESUME operations and returns an error, but the customer ID and shop domain come from the session token (which appears secure). However, the "silent failure" on auth means unauthenticated requests get a 200-like response.

### MEDIUM: No Authorization Check on Billing Cycle Charge

**File:** `app/routes/app.contracts.$id.bill-contract/route.ts`

```typescript
const inventoryPolicy = body.get('inventoryPolicy');
const cycleIndex = body.get('cycleIndex');
// no authorization check on which cycles can be charged
```

The `cycleIndex` and `inventoryPolicy` are taken from user input and passed to the Shopify API. The route uses `authenticate.admin(request)` which provides the admin session, so this is at least OAuth-authenticated, but the merchant could charge arbitrary billing cycle indices.

---

## 8. GraphQL Mutation Inventory

| Mutation                                    | File                              | Used In                              |
|---------------------------------------------|-----------------------------------|--------------------------------------|
| `SubscriptionBillingCycleChargeMutation`   | `app/graphql/SubscriptionBillingCycleChargeMutation.ts` | `RebillSubscriptionJob` |
| `ChargeBillingCyclesMutation`              | `app/graphql/ChargeBillingCyclesMutation.ts` | `ChargeBillingCyclesJob` |
| `SubscriptionContractUpdate`               | `app/graphql/SubscriptionContractUpdateMutation.ts` | `buildDraftFromContract` |
| `SubscriptionContractDraftUpdateMutation`  | `app/graphql/SubscriptionContractDraftUpdateMutation.ts` | `SubscriptionContractDraft.update()` |
| `SubscriptionContractDraftAddLineMutation` | `app/graphql/SubscriptionContractDraftAddLineMutation.ts` | `SubscriptionContractDraft.addLine()` |
| `SubscriptionDraftLineUpdateMutation`      | `app/graphql/SubscriptionDraftUpdateLineMutation.ts` | `SubscriptionContractDraft.updateLine()` |
| `SubscriptionContractDraftCommitMutation`  | `app/graphql/SubscriptionContractDraftCommitMutation.ts` | `SubscriptionContractDraft.commit()` |
| `SubscriptionContractDraftRemoveLineMutation` | `app/graphql/SubscriptionContractDraftRemoveLineMutation.ts` | `SubscriptionContractDraft.removeLine()` |
| `SubscriptionContractDraftRemoveDiscountMutation` | `app/graphql/SubscriptionContractDraftRemoveDiscountMutation.ts` | `SubscriptionContractDraft.removeDiscount()` |
| `SubscriptionContractPause`                | `app/graphql/SubscriptionContractPauseMutation.ts` | `SubscriptionContractPauseService` |
| `SubscriptionContractCancel`               | `app/graphql/SubscriptionContractCancelMutation.ts` | `SubscriptionContractCancelService` |
| `SubscriptionContractResume`               | `app/graphql/SubscriptionContractResumeMutation.ts` | `SubscriptionContractResumeService` |
| `SubscriptionContractFail`                 | `app/graphql/SubscriptionContractFailMutation.ts` | Dunning services |
| `SubscriptionBillingCycleScheduleEdit`     | `app/graphql/SubscriptionBillingCycleScheduleEditMutation.ts` | `skipOrResumeBillingCycle` |
| `CustomerPaymentMethodSendUpdateEmail`     | `app/graphql/CustomerPaymentMethodSendUpdateEmailMutation.ts` | `SendPaymentMethodUpdateEmailService` |
| `SubscriptionBillingCycleChargeIndexMutation` | `app/graphql/SubscriptionBillingCycleChargeIndexMutation.ts` | `bill-contract` route |
| `BulkOperationRunQueryMutation`            | `app/utils/bulkOperations/graphql/BulkOperationRunQueryMutation.ts` | Bulk query runner |

### Query Inventory (Key)
| Query | File | Used In |
|-------|------|---------|
| `SubscriptionContractRebillingQuery` | `app/graphql/SubscriptionContractRebillingQuery.ts` | `getContractDetailsForRebilling` (checks `lastPaymentStatus`) |
| `SubscriptionContractDetailsQuery` | `app/graphql/SubscriptionContractDetailsQuery.ts` | `getContractDetails` |
| `SubscriptionContractCustomerQuery` | `app/graphql/SubscriptionContractCustomerQuery.ts` | `getContractCustomerId` |
| `SubscriptionBillingAttemptQuery` | `app/graphql/SubscriptionBillingAttemptQuery.ts` | `findSubscriptionBillingAttempt` |
| `SubscriptionBillingCycleByIndexQuery` | `app/graphql/SubscriptionBillingCycleByIndexQuery.ts` | `getPastBillingCycles` |
| `SubscriptionPastBillingCyclesQuery` | `app/graphql/SubscriptionPastBillingCyclesQuery.ts` | `getPastBillingCycles` |

---

## 9. Job Registry (Registered Jobs)

From `app/jobs/index.ts`:

| Job Class                         | Queue        | Shop API Calls                                           |
|-----------------------------------|--------------|----------------------------------------------------------|
| `DisableShopJob`                  | default      | —                                                        |
| `EnqueueAddFieldsToMetaobjectJob` | default      | —                                                        |
| `AddFieldsToMetaobjectJob`        | default      | —                                                        |
| `EnqueueTransitionFailedContractsToActiveJob` | default | —                                                |
| `TransitionFailedContractsToActiveJob` | default   | —                                                        |
| `ChargeBillingCyclesJob`          | billing      | `subscriptionBillingCycleBulkCharge` (date range from payload) |
| `RecurringBillingChargeJob`       | billing      | Schedules `ScheduleShopsToChargeBillingCyclesJob`        |
| `ScheduleShopsToChargeBillingCyclesJob` | billing | `findActiveBillingSchedulesInBatches` (Prisma)        |
| `RebillSubscriptionJob`           | rebasing     | `subscriptionBillingCycleCharge` (originTime from payload) |
| `DeleteBillingScheduleJob`        | default      | —                                                        |
| `DunningStartJob`                 | webhooks     | `buildDunningService`/`buildInventoryService` (Prisma + GraphQL) |
| `DunningStopJob`                  | webhooks     | `findSubscriptionBillingAttempt` + `subscriptionContractActivate` |
| `CustomerSendEmailJob`            | webhooks     | `CustomerSendEmailService` (unauthenticated.admin)       |
| `MerchantSendEmailJob`            | webhooks     | `MerchantSendEmailService`                               |
| `EnqueueInventoryFailureEmailJob` | webhooks     | —                                                        |
| `SendInventoryFailureEmailJob`    | webhooks     | —                                                        |
| `TagSubscriptionOrderJob`         | webhooks     | `AddOrderTagsService`                                    |
| `CreateSellingPlanTranslationsJob`| webhooks     | Translations service                                     |

**All jobs except `RecurringBillingChargeJob` are exploitable via `/internal/jobs/run`**: they use `unauthenticated.admin(shop)` with `shop` from the attacker-controlled payload.

---

## 10. Initial Vulnerability Observations

### Priority 1 — Critical

1. **No Auth on `/internal/jobs/run` (app/routes/internal.jobs.run.tsx:15)**
   - The endpoint accepts `POST` with `{jobName, parameters}` and executes any registered job
   - `parameters.shop` controls which Shopify shop's API the job calls via `unauthenticated.admin(shop)`
   - No HMAC, no API secret check, no OIDC verification
   - In production, scheduler is INLINE (jobs execute synchronously on enqueue), but the endpoint is still exposed
   - If CLOUD_TASKS scheduler is used in production, the GCP OIDC token is NOT verified by the route

2. **Job `originTime` / `subscriptionContractId` are Untrusted (app/jobs/billing/RebillSubscriptionJob.ts:19-33)**
   - `originTime` selects the billing cycle date — attacker could charge wrong cycle
   - `subscriptionContractId` targets which contract to bill — no check that the shop owns this contract
   - Full control via `/internal/jobs/run` with no auth

3. **DunningStopJob uses `originTime` from Billing Attempt (app/models/SubscriptionBillingAttempt/SubscriptionBillingAttempt.server.ts)**
   - `findSubscriptionBillingAttempt(shop, billingAttemptId)` → `originTime` used to find billing cycle → `DunningTracker`
   - Attacker could manipulate cycle index lookup via crafted billing attempt ID

### Priority 2 — High

4. **No zod validation on address JSON (app/routes/app.contracts.$id.address-update/route.ts:24)**
   - `JSON.parse(address)` with no schema validation
   - `deliveryMethodName` from raw form input

5. **`customerAccount.emails.ts` silent auth failure (app/routes/customerAccount.emails.ts:13)**
   - "returns early without any error if authentication fails"
   - Attacker can probe for customer IDs / shops

6. **bill-contract route: no authorization check on cycleIndex (app/routes/app.contracts.$id.bill-contract/route.ts:19-20)**
   - Merchant can charge any billing cycle index without additional validation

7. **Job `perform()` uses `unauthenticated.admin(shop)` for all Shopify API calls**
   - While `unauthenticated.admin` requires a stored session, the `shop` parameter is not validated against the authenticated session in job context
   - In webhook-triggered jobs, `shop` comes from the verified webhook, but in `/internal/jobs/run`, it comes from the request body

### Priority 3 — Medium

8. **CSP allows `unsafe-inline`** in `app/entry.server.tsx:47` — `script-src 'self' 'unsafe-inline' https://cdn.shopify.com`

9. **SQLite database in production config** (`prisma/schema.prisma:12`) — `file:./data.db` — not suitable for production multi-instance deployments

10. **GraphQL responses logged in error paths** — `logger.error(json, ...)` in several job files logs full API responses which may contain sensitive data

---

## 11. Test Architecture

- **Runner:** vitest v3.2.4 (configured in `vitest.config.ts`)
- **Test env:** jsdom via happy-dom v18.0.1
- **Mocking:** `msw` v2.10.2 for HTTP; custom `mockShopifyServer()` in `test/test-utils.tsx`
- **Key test files:**
  - `app/jobs/billing/tests/RebillSubscriptionJob.test.ts` — tests job perform with mocked GraphQL
  - `app/jobs/billing/tests/ChargeBillingCyclesJob.test.ts`
  - `app/lib/jobs/tests/JobRunner.test.ts` — tests execute/enqueue
  - `app/lib/jobs/tests/Job.test.ts` — tests terminal/retryable error classification
  - `app/lib/jobs/schedulers/tests/CloudTaskScheduler.test.ts`
  - `app/routes/tests/customerAccount.email.test.ts`
  - `app/routes/tests/webhooks.*.test.ts`

**Observation:** No test exists for `/internal/jobs/run` `action` handler — the endpoint is completely untested for security.

---

## 12. Next Steps for Deep Hunt

1. **fuzz `/internal/jobs/run`** — enumerate all registered job names by fuzzing the `jobName` field
2. **test OIDC token bypass** — check if GCP Cloud Tasks OIDC tokens are verified when CLOUD_TASKS scheduler is active
3. **rebillSubscriptionJob originTime fuzzing** — test with various `originTime` values to find billing cycle manipulation
4. **SubscriptionContractDraft attack surface** — the draft commit/build flow uses user-supplied contract IDs
5. **customerAccount.emails.ts** — test JWT bypass / token substitution attacks
6. **bulkOperation routes** — check for IDOR on bulk operation polling
7. **Check `AddFieldsToMetaobjectJob` and migration jobs** — these may have different auth patterns
