# Reconnaissance Report: Shopify/shop-chat-agent

**Date:** 2026-08-09  
**Repository:** Shopify/shop-chat-agent  
**Branch:** main  
**Template Base:** Shopify/shopify-app-template-react-router (forked from shopify-app-template-remix)  

---

## 1. Stack Summary

| Layer | Technology |
|---|---|
| **Framework** | React Router v7 (`react-router@^7.9.1`) |
| **Runtime** | Node.js (>=20.10) |
| **AI Provider** | Anthropic Claude (`@anthropic-ai/sdk@^0.40.0`) |
| **LLM Model** | `claude-sonnet-4-20250514` |
| **Shopify SDK** | `@shopify/shopify-app-react-router@^1.0.0` |
| **Session Storage** | `@shopify/shopify-app-session-storage-prisma@^7.0.0` |
| **Database** | SQLite (via Prisma v6 `@prisma/client@^6.2.1`) |
| **Protocol** | MCP (Model Context Protocol) — JSON-RPC 2.0 over HTTP |
| **Auth** | OAuth 2.0 + PKCE (S256) |
| **Theme Extension** | Shopify theme app extension (chat-bubble) |
| **Build** | Vite v6 + React Router dev server |

### Key Dependency Versions
| Package | Version | Notes |
|---|---|---|
| `@anthropic-ai/sdk` | ^0.40.0 (latest 0.116.0) | 0.40.x is ~1yr behind latest |
| `@prisma/client` | ^6.2.1 | Prisma 6 |
| `react-router` | ^7.9.1 | React Router 7 |
| `@shopify/shopify-app-react-router` | ^1.0.0 (latest 1.2.1) | Major version v1 |
| `isbot` | ^5.1.0 (latest 5.2.1) | Minor version behind |
| `dotenv` | ^16.3.1 (latest 17.4.2) | Major version behind |
| `eslint` | ^8.38.0 | ESLint 8 (ESLint 9 exists) |
| `react` | ^18.2.0 | React 18 (React 19 exists) |

---

## 2. Architecture / Data Flow

```
┌─────────────────────┐
│  Storefront (Theme)  │
│  chat-bubble ext.    │
│  (Liquid + JS)       │
└──────────┬───────────┘
           │ HTTP POST to /chat
           │ Origin: <shop>.myshopify.com
           │ X-Shopify-Shop-Id: <shop_id>
           ▼
┌─────────────────────┐
│  /chat (SSE Stream)  │  ← NO authentication
│  app/routes/chat.jsx │
│  - CORS: reflect Origin│
│  - body.message      │
│  - body.conversation_id│
│  - body.prompt_type  │
└──────────┬───────────┘
           │
           ├─── Fetch .well-known/customer-account-api
           │    from https://<Origin-hostname>/.well-known/...
           │    ← SSRF via Origin header!
           │
           │    Store mcpApiUrl, authorizationUrl, tokenUrl
           │
           ├─── Connect to MCP (JSON-RPC)
           │    ┌─────────────────────────────────┐
           │    │ Storefront MCP: <Origin>/api/mcp │
           │    │  (no auth — unauthenticated endpoint)│
           │    └─────────────────────────────────┘
           │    ┌─────────────────────────────────────────┐
           │    │ Customer MCP: <Origin>/customer/api/mcp │
           │    │  (Bearer token from CustomerToken table)│
           │    └─────────────────────────────────────────┘
           │
           │    Get tools/list → format for Claude
           │
           ├─── Send to Claude API (claude.sonnet-4-20250514)
           │    - System prompt from prompts.json
           │    - Conversation history from DB
           │    - Available MCP tools
           │    ← Streamed response → SSE → client
           │
           │    On tool_use → callTool() → MCP JSON-RPC tools/call
           │    Results fed back to Claude
           │
           ▼
┌─────────────────────┐
│  Database (SQLite)   │
│  Prisma: dev.sqlite  │
│  Tables:             │
│  - Session (OAuth)   │
│  - CustomerToken     │
│  - CodeVerifier      │
│  - Conversation      │
│  - Message           │
│  - CustomerAccountUrls│
└─────────────────────┘

┌─────────────────────┐
│  /auth/callback      │
│  OAuth PKCE callback │
│  - Exchanges code    │
│  - Stores token      │
│  - Returns HTML (close│
└─────────────────────┘

┌─────────────────────┐
│  /auth/token-status  │
│  - Polls for token   │
└─────────────────────┘
```

### Data Flow Summary

1. **Client** (theme extension) sends POST to `/chat` with SSE Accept header
2. **Server** generates `conversationId` (if not provided) = `Date.now().toString()`
3. **Server** retrieves `.well-known/customer-account-api` from the **Origin** domain (SSRF risk)
4. **Server** connects to storefront MCP (`{origin}/api/mcp`) — no auth
5. **Server** connects to customer MCP (`{origin}/customer/api/mcp`) — uses stored customer token or proceeds unauthenticated
6. **Server** streams conversation to Claude API, including MCP tool descriptions
7. **Claude** generates text and/or invokes tools → server calls MCP `tools/call` via JSON-RPC
8. All messages saved to SQLite database (Prisma)
9. **SSE responses** streamed back to client with typed events (`chunk`, `tool_use`, `end_turn`, etc.)

---

## 3. Endpoint List

### Public-Facing Server Routes

| Route | File | Methods | Auth | Description |
|---|---|---|---|---|
| `/chat` | `app/routes/chat.jsx` | GET, POST, OPTIONS | **NONE** | Main SSE streaming chat endpoint |
| `/auth/callback` | `app/routes/auth.callback.jsx` | GET | **NONE** | OAuth PKCE callback |
| `/auth/token-status` | `app/routes/auth.token-status.jsx` | GET, OPTIONS | **NONE** | Poll for customer token availability |
| `/webhooks/app/uninstalled` | `app/routes/api.webhooks.jsx` | POST | **Webhook HMAC** | Handle APP_UNINSTALLED webhook |
| `/` | `app/routes/_index/route.jsx` | GET | **NONE** | Redirect to /app?shop=<shop> |
| `/app` | `app/routes/app.jsx` | GET | **Shopify Admin** | Admin auth-protected shell |
| `/auth/*` | `app/routes/auth.$.jsx` | GET | **Shopify Admin** | Shopify OAuth redirect catch-all |

### External / Third-Party Endpoints

| URL | Called By | Purpose |
|---|---|---|
| `https://api.anthropic.com` | `app/services/claude.server.js` | Claude LLM API |
| `https://{hostname}/.well-known/customer-account-api` | `app/routes/chat.jsx` | Discover MCP API URL + auth endpoints |
| `https://{hostname}/.well-known/openid-configuration` | `app/routes/chat.jsx` | Discover authorization + token endpoints |
| `{hostUrl}/api/mcp` | `app/mcp-client.js` | Storefront MCP JSON-RPC (`/tools/list`, `/tools/call`) |
| `{accountHostUrl}/customer/api/mcp` | `app/mcp-client.js` | Customer MCP JSON-RPC (with Bearer token) |

---

## 4. Auth Model

The app uses a **dual authentication model**:

### 4.1 Shopify App OAuth (Admin)
- Uses `@shopify/shopify-app-react-router` framework
- Admin sessions stored via `PrismaSessionStorage` (table: `Session`)
- Standard Shopify OAuth flow on `/auth/*` routes
- **Scopes:** `unauthenticated_read_product_listings` (password-protected stores may add more)

### 4.2 Customer OAuth + PKCE (Customer)
- **Flow:** Authorization Code + PKCE (S256)
- **Scope:** `customer-account-mcp-api:full`
- **State parameter:** `${conversationId}-${shopId}`
- **Conversation ID:** `body.conversation_id || Date.now().toString()` — **predictable**
- **Code verifier:** Stored in `CodeVerifier` table, deleted after single use, expires in 10 min
- **Tokens:** Stored in `CustomerToken` table, associated with `conversationId`, expires tracked
- **Redirect URI:** `process.env.REDIRECT_URL` (env var, not validated against request Origin)

### 4.3 /chat Endpoint — NO AUTHENTICATION
- The `/chat` endpoint **does not require any authentication**
- No session validation, no API key check, no HMAC verification
- The only auth context is:
  - `X-Shopify-Shop-Id` header (optional, used for logging)
  - `Origin` header (used to construct MCP URLs and fetch `.well-known` endpoints)
  - `conversation_id` in request body (used to look up existing customer tokens)

---

## 5. Database Schema (Prisma)

| Model | Key Fields | Notes |
|---|---|---|
| `Session` | id, shop, state, accessToken, userId, email | Shopify admin sessions |
| `CustomerToken` | conversationId, accessToken (plaintext), expiresAt | **Tokens stored unencrypted** |
| `CodeVerifier` | state (unique), verifier, expiresAt | PKCE code verifier; deleted after retrieval |
| `Conversation` | id, createdAt, updatedAt | Conversation tracking |
| `Message` | id, conversationId, role, content | Chat messages; `content` stored as JSON string |
| `CustomerAccountUrls` | conversationId (unique), mcpApiUrl, authorizationUrl, tokenUrl | Cached `.well-known` discovery results |

### Key Database Observations
- **No encryption** on `CustomerToken.accessToken` — stored as plaintext
- `conversationId` is a simple string (timestamp-like) — predictable
- `CodeVerifier.state` has a unique constraint — prevents duplicate state but doesn't prevent prediction
- SQLite database (`file:dev.sqlite`) — single file, no network encryption

---

## 6. CORS Configuration

### `/chat` endpoint (`getCorsHeaders` in chat.jsx:170)
```js
const origin = request.headers.get("Origin") || "*";
return {
  "Access-Control-Allow-Origin": origin,          // REFLECTS ANY ORIGIN
  "Access-Control-Allow-Methods": "GET, POST, OPTIONS",
  "Access-Control-Allow-Headers": requestHeaders,   // REFLECTS REQUESTED HEADERS
  "Access-Control-Allow-Credentials": "true",        // CREDENTIALS ALLOWED
  "Access-Control-Max-Age": "86400"
};
```

### `/auth/token-status` (`corsHeaders` in auth.token-status.jsx:41)
```js
const origin = request.headers.get("Origin") || "*";
return {
  "Access-Control-Allow-Origin": origin,
  "Access-Control-Allow-Methods": "GET, OPTIONS",
  "Access-Control-Allow-Headers": "Content-Type, Accept",
  "Access-Control-Max-Age": "86400"
};
```

### SSE Headers (`getSseHeaders` in chat.jsx:184)
```js
const origin = request.headers.get("Origin") || "*";
return {
  "Content-Type": "text/event-stream",
  "Access-Control-Allow-Credentials": "true",
  "Access-Control-Allow-Origin": origin,
  "Access-Control-Allow-Methods": "GET,OPTIONS,POST",
  "Access-Control-Allow-Headers": "X-CSRF-Token, X-Requested-With, ..."
};
```

---

## 7. Key Files to Examine for Vulnerability Hunting

| Priority | File | Line(s) | Why |
|---|---|---|---|
| **CRITICAL** | `app/routes/chat.jsx` | 170-183, 195-213, 262-310 | CORS wildcard + SSRF via Origin header + no auth |
| **CRITICAL** | `app/routes/chat.jsx` | 223-248 | `getCustomerAccountUrls()` — fetches from attacker-controlled Origin |
| **CRITICAL** | `app/mcp-client.js` | 25-30 | Constructs MCP endpoints from Origin header |
| **HIGH** | `app/routes/chat.jsx` | 57 | `conversationId = body.conversation_id \|\| Date.now()` — predictable |
| **HIGH** | `app/routes/chat.jsx` | 99-103 | Conversation ID used for DB storage; no validation |
| **MEDIUM** | `app/db.server.js` | 109-130 | `storeCustomerToken` — plaintext token storage |
| **MEDIUM** | `app/services/claude.server.js` | 30-75 | Error details leaked to client |
| **MEDIUM** | `app/services/streaming.server.js` | 44-65 | `error.message` sent to client |
| **MEDIUM** | `app/services/tool.server.js` | 116-133 | Product URLs from MCP results — potential XSS via markdown |
| **LOW** | `app/auth.server.js` | 27-30 | State = `${conversationId}-${shopId}` — predictable |
| **LOW** | `app/services/claude.server.js` | 79-83 | Prompt type falls back silently |
| **LOW** | `app/routes/api.webhooks.jsx` | 17-19 | Only handles APP_UNINSTALLED; others rejected |

---

## 8. Initial Security Observations

### 8.1 — CRITICAL: CORS Wildcard Origin with Credentials
**File:** `app/routes/chat.jsx:170-183, 195-213, 184-192`

The `/chat` endpoint reflects the `Origin` header directly into `Access-Control-Allow-Origin` while also setting `Access-Control-Allow-Credentials: true`. This allows **any website** to make cross-origin requests to the chat endpoint, including sending messages to Claude (consuming the API key) and reading conversation history.

### 8.2 — CRITICAL: SSRF via Origin Header
**File:** `app/routes/chat.jsx:223-248`

The `getCustomerAccountUrls()` function extracts the hostname from `request.headers.get("Origin")` and fetches:
```
https://{hostname}/.well-known/customer-account-api
https://{hostname}/.well-known/openid-configuration
```
An attacker can set `Origin: evil.com` to make the server make outbound HTTP requests to arbitrary domains. The `mcpApiUrl` and `customerMcpEndpoint` are also constructed from this Origin. While the responses are stored and used for subsequent MCP calls, an attacker who controls the external server could return crafted URLs.

### 8.3 — CRITICAL: No Authentication on /chat Endpoint
**File:** `app/routes/chat.jsx:31-75`

The `/chat` endpoint has **zero authentication**. Anyone can:
- POST messages and receive Claude responses (API key abuse)
- Fetch conversation history via `?history=true&conversation_id=<predictable_id>`
- Access SSE streaming

### 8.4 — HIGH: Predictable Conversation IDs
**File:** `app/routes/chat.jsx:57`

```js
const conversationId = body.conversation_id || Date.now().toString();
```
The conversation ID is a Unix timestamp in milliseconds. This is highly predictable, allowing:
- **Conversation history enumeration** via `/chat?history=true&conversation_id=<guessed_timestamp>`
- **Token hijacking** — if a customer authenticates for a conversation, the token is stored by `conversationId`; an attacker who guesses the timestamp can look up the same token
- **PKCE state prediction** — the auth state parameter embeds the conversation ID

### 8.5 — MEDIUM: Customer Tokens Stored in Plaintext
**File:** `prisma/schema.prisma` (model `CustomerToken`)

The `accessToken` field is stored as plaintext in the SQLite database. If the database file is compromised (e.g., through a separate vulnerability, backup exposure, or directory traversal), all customer OAuth tokens are immediately usable.

### 8.6 — MEDIUM: Error Message Information Disclosure
**Files:**
- `app/routes/chat.jsx:109` — `{ error: error.message }` returned on 500
- `app/services/streaming.server.js:48-59` — `error.message` sent in stream error
- `app/mcp-client.js:157` — `{ error: { type: "internal_error", data: error.message } }`
- `app/routes/auth.callback.jsx:130` — `{ error: "Failed to obtain access token" }`

Internal error messages (which may include stack traces, API keys, internal URLs) are returned directly to clients.

### 8.7 — MEDIUM: MCP Tool Response Injection
**File:** `app/routes/chat.jsx:150-163`

Tool execution results are added directly to the conversation history and sent to Claude without sanitization. If a malicious MCP server returns crafted content, it could:
- Inject system-level instructions into the conversation
- Cause Claude to produce unintended output
- The `processProductSearchResult` in `tool.server.js:116-133` passes `product.url` directly to the client for rendering

### 8.8 — MEDIUM: Markdown / XSS in Client-Side Rendering
**File:** `extensions/chat-bubble/assets/chat.js:188-237`

The `convertMarkdownToHtml` function processes raw text from the LLM and tool results, inserting it via `innerHTML` (through `element.innerHTML = processedText`). Auth URLs and product URLs are handled specially but the general markdown conversion path for `<p>` content, links, and list items does not sanitize HTML. An LLM-generated response containing HTML tags or JavaScript could be executed in the context of the storefront.

### 8.9 — LOW: PKCE State Parameter Predictability
**File:** `app/auth.server.js:36`

```js
const state = `${conversationId}-${shopId}`;
```
The state parameter embeds the conversation ID (predictable timestamp) and shop ID (from `X-Shopify-Shop-Id` header, which is client-controlled). This makes the state parameter predictable.

### 8.10 — LOW: No Rate Limiting
None of the public endpoints (`/chat`, `/auth/token-status`, `/auth/callback`) have rate limiting. This allows:
- Brute-force guessing of conversation IDs
- API key abuse (spamming Claude via `/chat`)
- DoS via SSE stream exhaustion

### 8.11 — LOW: MCP Tools Exposed Without Filtering
**File:** `app/mcp-client.js:103-108`

All tools from both storefront and customer MCP are collected and passed directly to Claude without filtering by role, sensitivity, or intent. The LLM can invoke any exposed tool at any time.

### 8.12 — MEDIUM: Hardcoded Stream URL in Client
**File:** `extensions/chat-bubble/assets/chat.js:396`

```js
const streamUrl = 'https://localhost:3458/chat';
```
The client-side JavaScript has a hardcoded URL that points to localhost. In production, this should be dynamically set to the app's tunnel URL. While this is likely a development default, it indicates the URL is not dynamically configured.

### 8.13 — MEDIUM: Insecure Cookie / Token Handling
**File:** `app/routes/auth.callback.jsx:66-84`

The OAuth callback returns an HTML page that calls `window.close()`. There is no secure cookie set for the customer token. The token is stored server-side by `conversationId` only. An attacker who knows a `conversationId` can retrieve the token status and potentially the token itself through the MCP client flow.

---

## 9. Additional Notes

### Shopify API Version
- Configured as `ApiVersion.October25` in `app/shopify.server.js:11`
- Webhook API version in `shopify.app.toml`: `2025-04`

### MCP JSON-RPC Implementation
The MCP client uses raw JSON-RPC 2.0 (not SSE-based MCP):
- `tools/list` — gets available tools
- `tools/call` — invokes a tool
- Uses `id: 1` for all requests (no unique request IDs — could cause issues with concurrent tool calls in the same MCP session, but since calls are sequential this may not be exploitable)

### Theme Extension
- Type: Shopify theme extension (`type = "theme"`)
- Injects into storefront via Liquid block (`chat-interface.liquid`)
- Client-side JS opens a popup for OAuth, polls `/auth/token-status` every 10s (max 30 attempts = 5 min)
- Uses `sessionStorage` for conversation ID persistence (per-tab, not persistent across sessions)

### No Test Files Found
There are no test files in this repository (no `test/`, `tests/`, `*.test.js`, `*.spec.js` directories or files found in the tree).
