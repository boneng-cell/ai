# Hydrogen — Extracted URLs / Domains / Endpoints

## Top-level documentation
- https://hydrogen.shopify.dev
- https://shopify.dev/custom-storefronts/hydrogen
- https://shopify.dev/docs/api/customer
- https://shopify.dev/docs/custom-storefronts/building-with-the-customer-account-api/hydrogen
- https://shopify.dev/api/multipass
- https://shopify.dev/api/storefront
- https://shopify.dev/api/usage/versioning
- https://shopify.dev/docs/api/customer (Customer Account API)
- https://github.com/Shopify/hydrogen
- https://github.com/Shopify/hydrogen/discussions
- https://github.com/Shopify/hydrogen-v1
- https://github.com/Shopify/hydrogen-v1/tutorials/getting-started
- https://reactrouter.com/
- https://reactrouter.com/start/framework/routing
- https://monorepo.tools/
- https://npmcharts.com/compare/@shopify/hydrogen
- https://calver.org/

## Shopify domains / hosts
- shopify.com
- myshopify.com  (store + checkout domains)
- shop.app  (used by analytics)
- cdn.shopify.com  (analytics/analytics assets)
- myshopify.dev  (Oxygen / merchant request origin)
- .tryhydrogen.dev  (Hydrogen dev tunnel suffix)

## APIs referenced
### Customer Account API (OAuth 2.0 / OIDC)
- Base auth: `https://shopify.com/{shopId}/authentication/{shopId}/oauth/authorize`
- Token exchange: `https://shopify.com/{shopId}/authentication/{shopId}/oauth/token`
- GraphQL (per-customer): `https://shopify.com/{shopId}/account/customer/api/{apiVersion}/graphql`
- Logout: `https://shopify.com/{shopId}/authentication/{shopId}/logout`
- Scopes: `openid email https://api.customers.com/auth/customer.graphql`
- Client id: `30243aa5-17c1-465a-8493-944bcc4e88aa` (static public client)

### Storefront API
- `https://{storeDomain}/api/{apiVersion}/graphql.json`
- Consent-tracking query: `{ consentManagement { cookies(visitorConsent:{}) { cookieDomain } } }`

### Multipass (Plus only)
- `https://{shopifyDomain}/account/login/multipass/{token}`  (Liquid multipass auth to checkout)
- Local route: `/account/login/multipass/{token}`  (local multipass verification)
- POST `/account/login/multipass`  (token + url generation endpoint)

### Legacy Storefront analytics (Trekkie / Monorail)
- Monorail events (`schemaWrapper`, `trekkie_storefront_page_view/1.4`)

## Cookie / tracking names
- Session cookie: `session` (httpOnly, SameSite=Lax, path=/)
- Deprecated analytics: `_shopify_y`, `_shopify_s`, `_tracking_consent`
- Newer tracking: `_shopify_y` (uniqueToken), `_shopify_s` (visitToken)
- Buyer identity session key: `buyer`
- CA session key: `customerAccount`

## Environment variables
### Skeleton `.env`
- `SESSION_SECRET="foobar"`

### e2e envs
- `SESSION_SECRET`, `PUBLIC_CHECKOUT_DOMAIN`, `PUBLIC_STORE_DOMAIN`, `PUBLIC_STOREFRONT_API_TOKEN`, `PUBLIC_STOREFRONT_ID`, `PUBLIC_CUSTOMER_ACCOUNT_API_CLIENT_ID`, `PUBLIC_CUSTOMER_ACCOUNT_API_URL`, `SHOP_ID`

### Multipass env patch (env.d.ts)
- `PRIVATE_SHOPIFY_STORE_MULTIPASS_SECRET`  (added to global Env)

### Express recipe env.ts
- `SOME_API_KEY` (example)

## Public-facing routes
- `/` (index)
- `/account`  → redirects to `/account/login` if logged out
- `/account/login`
- `/account/login/multipass` (POST)  — multipass token+url generator
- `/account/login/multipass/{token}` (GET)  — token handler
- `/account/logout`
- `/account/register`
- `/account/recover`
- `/account/reset/:id/:resetToken`
- `/account/activate/:id/:activationToken`
- `/account/authorize`  — OAuth callback (calls `customerAccount.authorize()`)
- `/account/orders`
- `/account/orders/:id`
- `/account/profile`
- `/account/addresses`
- `/account/subscriptions` (subscriptions recipe)
- `/cart`
- `/products/:handle`
- `/collections/:handle`
- `/search`
- `/($locale).*`  (markets recipe locale-prefixed variants)

## Internal/redirect query params
- `?return_to=`  (login + multipass redirect target)
- `?redirect=`
- `?oauth_recovery=true`  (OAuth state-recovery flag)
- `?acr_values=`, `?login_hint=`, `?login_hint_mode=`, `?locale=`
- `?region_country=`, `?code_challenge=`, `?code_challenge_method=S256`, `?state=`, `?nonce=`
- `?id_token_hint=`, `?post_logout_redirect_uri=`, `?step=contact_information`
- Storefront redirect query param: `?redirect`, `?return_to`, `?_routes`
