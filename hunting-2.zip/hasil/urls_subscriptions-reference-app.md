# URLs / Domains / Endpoints - Shopify Subscriptions Reference App

## Application Configuration (shopify.app.toml)

### Application URL
- `https://example.com` (placeholder — `application_url`)

### Auth Redirect URLs
- `https://example.com/auth/callback`
- `https://example.com/auth/shopify/callback`
- `https://example.com/api/auth/callback`

## Webhook Endpoints (from shopify.app.toml)

| Topic                          | URI                                      |
|--------------------------------|------------------------------------------|
| `app/uninstalled`              | `/webhooks/app/uninstalled`              |
| `subscription_contracts/create` | `/webhooks/subscription_contracts/create` |
| `subscription_contracts/activate` | `/webhooks/subscription_contracts/activate` |
| `subscription_contracts/cancel`   | `/webhooks/subscription_contracts/cancel` |
| `subscription_contracts/pause`    | `/webhooks/subscription_contracts/pause` |
| `subscription_billing_cycles/skip`| `/webhooks/subscription_billing_cycles/skip` |
| `subscription_billing_attempts/success` | `/webhooks/subscription_billing_attempts/success` |
| `subscription_billing_attempts/failure` | `/webhooks/subscription_billing_attempts/failure` |
| `selling_plan_groups/create`,`selling_plan_groups/update` | `/webhooks/selling_plan_groups/create_or_update` |
| compliance: `customers/data_request`,`customers/redact` | `/webhooks/customer_redact` |
| compliance: `shop/redact`          | `/webhooks/shop_redact`              |

## Internal / Debug Endpoints

| Route                        | Purpose                                      |
|------------------------------|----------------------------------------------|
| `/internal/jobs/run`         | Job runner entry point (POST action)         |
| `/services/ping`             | Healthcheck (DB connectivity)                |
| `/maintenance`               | Maintenance mode page                        |
| `/missing-scopes`            | Missing scopes warning page                  |

## App Routes (User-Facing, behind `/app`)

| Route Pattern                          | Action Endpoint (route.ts)          |
|----------------------------------------|-------------------------------------|
| `/app`                                  | layout                              |
| `/app/_index`                           | dashboard                           |
| `/app/contracts/$id`                    | contract details                    |
| `/app/contracts/$id/address-update`    | update delivery address             |
| `/app/contracts/$id/bill-contract`      | charge specific billing cycle index |
| `/app/contracts/$id/billing-cycle-skip` | skip/resume billing cycle           |
| `/app/contracts/$id/cancel`             | cancel subscription contract        |
| `/app/contracts/$id/edit`               | edit subscription contract          |
| `/app/contracts/$id/pause`              | pause subscription contract         |
| `/app/contracts/$id/payment-update`     | send payment method update email    |
| `/app/contracts/$id/poll-bill-attempt`  | poll billing attempt status         |
| `/app/contracts/$id/resume`             | resume subscription contract        |
| `/app/contracts/bulk-operation`         | bulk pause/activate + tag           |
| `/app/plans`                            | selling plan groups list            |
| `/app/plans/$id`                        | selling plan group detail/edit      |
| `/app/plans/$id/delete`                 | delete selling plan group           |
| `/app/settings`                         | app settings                          |
| `/app/bulk-operation` (loader)          | poll bulk operation status          |

## Customer Account API Routes

| Route                          | Method | Purpose                                      |
|--------------------------------|--------|----------------------------------------------|
| `/customerAccount/emails`      | POST   | Trigger customer email (PAUSE/RESUME)        |
| `/customerAccount/emails`      | GET    | CORS preflight response                      |

## Auth Routes

| Route      | Purpose                         |
|------------|---------------------------------|
| `/auth`    | Shopify OAuth login             |
| `/auth/login` | Login page                    |
| `/auth/callback` | OAuth callback            |

## CLI Webhook Route

| Route         | Purpose                                    |
|---------------|--------------------------------------------|
| `/webhooks/cli` | Manually trigger webhooks from CLI       |

## External Domains & Services

### Shopify API Hosts
- `app.myshopify.com` — Admin & Customer API introspection (`https://app.myshopify.com/services/graphql/introspection/admin`, `https://app.myshopify.com/services/graphql/introspection/customer`)
- `*.myshopify.io` — Per-shop admin domains (e.g. `shop1.myshopify.io`, `test-shop.myshopify.com`)

### CDN / Static Assets (CSP allowlist in entry.server.tsx)
- `https://cdn.shopify.com/` — Fonts (Inter), Polaris assets, app-bridge
- `https://atlas.shopifysvc.com` — App Bridge analytics / connectivity
- `https://extensions.shopifycdn.com` — UI Extensions runtime

### Google Cloud (Cloud Tasks Scheduler)
- Callback URL: `/internal/jobs/run` (OIDC token sent by Cloud Tasks when `CLOUD_TASKS` scheduler is configured)

### Test Constants
- `https://my-test-app.myshopify.io` (APP_URL in tests)
- `totally-real-host.myshopify.io` (SHOPIFY_HOST in tests)
- `https://shopify-subscriptions-app.com` (mock request origin in tests)
- `https://shopify.dev/docs/apps/build/purchase-options/subscriptions` (docs)
- `https://apps.shopify.com/shopify-subscriptions` (App Store)
- `https://remix.run/docs/en/main` (Remix docs)

## API Versions
- Admin API: `unstable` (via `@shopify/shopify-api`, `ApiVersion.Unstable`)
- Webhook API version: `unstable` (from `shopify.app.toml`)
- REST API: `2023-07` (from `@shopify/shopify-api/rest/admin/2023-07` in shopify.server.ts)
- GraphQL Codegen: `unstable`
