# RECON TEKNIS MENTAH — Shopify API Repositories
**Tanggal:** 10 Agustus 2026  
**Metode:** GitHub API (`git/trees/main?recursive=1`) + raw.githubusercontent.com  
**Catatan:** Tidak ada git clone dilakukan.

---

## REPO 1: shopify_python_api (v12.7.1)

### a) File Tree
- Disimpan di: `hasil/trees/shopify_python_api.txt`
- **209 file** total
- Struktur: `shopify/` (source), `test/` (tests), `scripts/`, `docs/`, `shopify/resources/` (200+ resource classes)

### b) Peta Arsitektur

#### Entry Points
| Entry | File |
|-------|------|
| Library import | `shopify/__init__.py:1` — exports `Session`, `ValidationException`, `Limits`, `GraphQL`, resources, `ApiAccess` |
| CLI console | `scripts/shopify_api.py` — interactive console + YAML config management |
| CLI entry | `bin/shopify_api.py` — wrapper to `scripts/shopify_api.py` |

#### Core Layer
| Layer | Files | Description |
|-------|-------|-------------|
| Session Management | `shopify/session.py` | OAuth flow, HMAC validation, timestamp validation, URL preparation |
| JWT / Session Token | `shopify/session_token.py` | JWT decode from `Authorization: Bearer` header — validates `iss`, `dest`, `sub`, `jti`, `sid`, `aud` |
| API Access Scopes | `shopify/api_access.py` | `ApiAccess` class — scope parsing, `covers()` comparison |
| API Version | `shopify/api_version.py` | Versioned API paths: `2021-10` → `2024-10`, `unstable` |
| Resource Base | `shopify/base.py` | `ShopifyResource` (ActiveResource) — thread-local connection, `X-Shopify-Access-Token` header |
| Resource Collection | `shopify/resources/*.py` | 200+ REST resource classes (Product, Order, Customer, etc.) |
| GraphQL | `shopify/resources/graphql.py` | GraphQL endpoint execution |
| Utility | `shopify/utils/shop_url.py` | `sanitize_shop_domain()` — strips protocol, validates myshopify.com |
| YAML | `shopify/yamlobjects.py` | YAML config loading |
| Limits | `shopify/limits.py` | API call rate limiting |

#### Service Layer
- No separate service layer — `ShopifyResource` directly extends `pyactiveresource`'s `ActiveResource`
- HTTP transport: `ShopifyConnection` (subclass of `pyactiveresource.connection.Connection`)

#### DB Layer
- **No database**. State is ephemeral — session tokens kept in-memory or via `Session.temp()` context manager.

#### Env Handling
- Credentials managed entirely by consumer app
- CLI stores configs in `~/.shopify/shops/{connection}.yml` (YAML format) containing: `protocol`, `domain`, `api_key`, `password`, `api_version`
- No `.env` file loading or framework env vars in core library

#### Test Files (27 test files)
| Test File | Coverage |
|-----------|----------|
| `test/session_test.py` | OAuth flow, HMAC, timestamp, state param, URL generation |
| `test/session_token_test.py` | JWT validation: expiry, alg confusion, signature, audience, issuer |
| `test/api_access_test.py` | Scope parsing & coverage |
| `test/api_version_test.py` | API version coercion |
| `test/base_test.py` | ShopifyResource session activation |
| `test/graphql_test.py` | GraphQL execution |
| `test/test_helper.py` | Shared test fixtures, HTTP faking |

### c) URL / Endpoint Ekstraksi
- Simpan di: `hasil/urls_shopify_python_api.md`

### d) Dependency & CVE Analysis

**Dependencies (setup.py):**
| Package | Constraint | Status |
|---------|-----------|--------|
| `pyactiveresource` | `>=2.2.2` | No known CVEs (latest 2.2.2) |
| `PyJWT` | `>=2.0.0` | ⚠️ **RISK**: CVE-2022-29217 affects <2.4.0 — constraint allows vulnerable versions |
| `PyYAML` | `>=6.0.1` (py3.12+) / `>=5.x` (older) | CVE-2020-1747 (resolved in 5.4), CVE-2020-14343 (resolved in 5.4) — `>=6.0.1` is safe |
| `six` | (unpinned) | CVE-2022-29110? — `six` has no known CVEs but is deprecated (Python 2 compat) |
| `mock` | `>=1.0.1` (test only) | No known CVEs |

**Key Dependency Risks:**
1. **PyJWT `>=2.0.0`** — Does NOT enforce `>=2.4.0` which fixes CVE-2022-29217 (algorithm confusion in EC key types). If consumer installs PyJWT 2.0-2.3.x, JWT decoding in `session_token.py` is vulnerable.
2. **PyYAML** — For py3.10/3.11, constraint is bare `PyYAML` (no version floor). An attacker who controls the YAML config file could exploit CVE-2020-14343 (arbitrary code execution via `yaml.load`) if `safe_load` is not used. However, the code uses `yaml.safe_load()` in test_helper (line ~510 in scripts/shopify_api.py: `yaml.safe_load`).
3. **`six`** — Legacy dependency. `session.py` imports `from six.moves import urllib`. This suggests the codebase still has Python 2 compat code. `six` itself has no CVEs but is a code smell.

### e) Ringkasan Output

**Stack:** Python | pyactiveresource (ActiveResource) | PyJWT | PyYAML | REST + GraphQL API

**Endpoints:**
- `https://{shop}.myshopify.com/admin/oauth/authorize` — OAuth authorization
- `https://{shop}.myshopify.com/admin/oauth/access_token` — Token exchange
- `https://{shop}.myshopify.com/admin/api/{version}/...` — REST API
- `https://shopify.com/authentication/{shopId}/oauth/authorize` — Customer Account API (in sample)
- `https://shopify.com/authentication/{shopId}/oauth/token` — Customer token exchange

**Auth Model:**
- **OAuth 2.0** (authorization code) — `create_permission_url()` generates URL with `client_id`, `redirect_uri`, `scope`, `state`
- **HMAC validation** — `validate_hmac()` compares HMAC-SHA256 of params (excluding `hmac`), using `hmac.compare_digest()` to prevent timing attacks
- **Timestamp replay protection** — `validate_params()` checks `timestamp` param: if `timestamp < time.time() - 86400` → reject (1-day window)
- **JWT session tokens** — `decode_from_header()` decodes Bearer JWT using `PyJWT`, validates `aud` (audience=api_key), `iss` (must be valid myshopify.com hostname), `dest` (must match `iss` root), `nbf`/`exp` (10s leeway)
- **State param** — `create_permission_url(state=...)` — consumer is expected to compare returned state with sent state (not enforced by library)
- **Access scope management** — `ApiAccess` class with `covers()` for scope hierarchy (write implies read)

**Data Flow:**
```
OAuth callback (code+timestamp+hmac) → validate_params() → validate_hmac() → validate timestamp
    ↓ (if valid)
→ request_token() → POST /admin/oauth/access_token → {access_token, scope}
    ↓
→ Session(url, version, token) → ShopifyResource.activate_session(session)
    ↓
→ ShopifyResource.find/create/update/delete → HTTP request via ShopifyConnection
    → Header: X-Shopify-Access-Token: {token}
    ← Response → ActiveResource model
```

---

## REPO 2: checkout-sheet-kit-react-native (v4.0.0)

### a) File Tree
- Simpan di: `hasil/trees/checkout-sheet-kit-react-native.txt`
- **103 file** total
- Struktur: `modules/@shopify/checkout-sheet-kit/` (TypeScript source + native iOS/Android), `sample/` (example app, auth, screens), `__mocks__/`, `docs/`

### b) Peta Arsitektur

#### Entry Points
| Entry | File |
|-------|------|
| JS API | `modules/@shopify/checkout-sheet-kit/src/index.ts` — `ShopifyCheckoutSheet` class (present, preload, dismiss, setConfig, addEventListener) |
| Context Provider | `modules/@shopify/checkout-sheet-kit/src/context.tsx` — `ShopifyCheckoutSheetProvider`, `useShopifyCheckoutSheet()` hook |
| Type definitions | `modules/@shopify/checkout-sheet-kit/src/index.d.ts` |

#### Native Bridge Layer
| Platform | File | Description |
|----------|------|-------------|
| iOS (Swift) | `modules/@shopify/checkout-sheet-kit/ios/ShopifyCheckoutSheetKit.swift` | `@objc(RCTShopifyCheckoutSheetKit)` — TurboModule bridge, `CheckoutDelegate`, present/preload via native SDK |
| iOS (Obj-C) | `modules/@shopify/checkout-sheet-kit/ios/ShopifyCheckoutSheetKit.mm` | Code generation TurboModule registration |
| Android (Java) | `modules/@shopify/checkout-sheet-kit/android/.../ShopifyCheckoutSheetKitModule.java` | `NativeShopifyCheckoutSheetKitSpec` impl — `present()`, `preload()`, `setConfig()`, `getConfig()` |

#### Service Layer
- No separate service — delegates to native SDK (`ShopifyCheckoutSheetKit` Swift / Java package)
- WebView: Uses native `WKWebView` (iOS) / Android WebView (via native SDK)

#### Env Handling
- `react-native-config` loads `.env` files
- Sample env vars: `STOREFRONT_DOMAIN`, `STOREFRONT_ACCESS_TOKEN`, `STOREFRONT_VERSION`, `STOREFRONT_MERCHANT_IDENTIFIER`, `EMAIL`, `PHONE`, `CUSTOMER_ACCOUNT_API_CLIENT_ID`, `CUSTOMER_ACCOUNT_API_SHOP_ID`

#### Sample App Structure
| File | Purpose |
|------|---------|
| `sample/src/App.tsx` | Root — deep link handler (`useInitialURL`), universal link routing, CheckoutSheetKit config |
| `sample/src/auth/customerAccountManager.ts` | **OAuth 2.1 + PKCE** flow — `buildAuthorizationURL()`, `handleAuthCallback()`, `exchangeCodeForTokens()`, `refreshAccessToken()`, `logout()` |
| `sample/src/auth/pkce.ts` | PKCE code verifier/challenge via `react-native-quick-crypto` |
| `sample/src/auth/tokenStorage.ts` | Encrypted token storage via `react-native-encrypted-storage` |
| `sample/src/auth/types.ts` | Type definitions for auth state |
| `sample/src/context/Auth.tsx` | Auth context wrapper |
| `sample/src/hooks/useShopify.ts` | (not fetched — likely Shopify data fetch hook) |
| `sample/src/hooks/useCheckoutEventHandlers.ts` | Checkout event callbacks |

#### Test Files
| Test File | Coverage |
|-----------|----------|
| `tests/linking.test.ts` | Verifies turbo module registration throws if native module not linked |
| `tests/index.test.ts` | Core API surface test |
| `tests/context.test.tsx` | ShopifyCheckoutSheetProvider context |
| `tests/AcceleratedCheckoutButtons.test.tsx` | Native component view manager |
| `sample/src/auth/__tests__/CustomerAccountManager.test.ts` | OAuth PKCE + token exchange |
| `sample/src/auth/__tests__/PKCE.test.ts` | PKCE generation |

### c) URL / Endpoint Ekstraksi
- Simpan di: `hasil/urls_checkout-sheet-kit-react-native.md`

### d) Dependency & CVE Analysis

**Root package devDeps:**
| Package | Version | Notes |
|---------|---------|-------|
| `typescript` | `^5.9.2` | Latest TS — OK |
| `react-native-builder-bob` | `^0.23.2` | Build tool — no known CVEs |

**Sample app key deps (not fully enumerable — pnpm-workspace.yaml):**
| Package | Risk |
|---------|------|
| `react-native-encrypted-storage` | Android: uses Android Keystore; iOS: Keychain. Known issues: older versions had encryption bypass on rooted Android |
| `react-native-quick-crypto` | C-based crypto (OpenSSL). CVE depends on OpenSSL version bundled |
| `react-native-config` | Known CVE-2021-42739 (arbitrary code execution via malicious config) — but version unknown from files |
| `@apollo/client` | Apollo GraphQL client — version unknown |

### e) Ringkasan Output

**Stack:** TypeScript | React Native | TurboModule (New Arch) | Native: iOS Swift (WKWebView) + Android Java (WebView)

**Endpoints:**
- `https://shopify.com/authentication/{shopId}/oauth/authorize` — Customer Account OAuth
- `https://shopify.com/authentication/{shopId}/oauth/token` — Token exchange
- `https://shopify.com/authentication/{shopId}/logout` — Logout
- `https://{STOREFRONT_DOMAIN}/api/{STOREFRONT_VERSION}/graphql.json` — Storefront GraphQL API
- `shop.{shopId}.app://callback` — **Custom URL scheme** (deep link)
- Checkout URL (runtime) → WebView

**Auth Model:**
- **OAuth 2.1 with PKCE** — `PKCE.generateCodeVerifier()` (32 random bytes) + `PKCE.generateCodeChallenge(verifier)` (SHA-256)
- **State param** — `PKCE.generateState()` (27 random bytes) — checked in `exchangeCodeForTokens()` via `state !== this.storedState` comparison
- **Custom URL scheme redirect** — `shop.{shopId}.app://callback` — deep link handled via `Linking` and `useInitialURL()` hook in App.tsx
- **Token storage** — `react-native-encrypted-storage` (Android Keystore + iOS Keychain)
- **Token refresh** — 5-minute refresh threshold (`REFRESH_THRESHOLD_MS = 5 * 60 * 1000`)
- **JWT ID token** — `extractEmailFromIdToken()` parses base64 JWT payload to extract email (no signature validation — relies on HTTPS transport)

**Deeplink / Universal Link Handling:**
- **iOS:** `Info.plist` declares URL scheme `rn`; App Delegates does **NOT** implement `continue userActivity` or `openURL:options` — deep links handled entirely via React Native `Linking` in JS layer (`useInitialURL()` hook)
- **Android:** `<intent-filter>` for `android.intent.action.VIEW` with `https://{STOREFRONT_DOMAIN}` — App Linking
- **Universal Links (iOS):** Consumer must configure `applinks:domain.com` entitlements + serve `.well-known/apple-app-site-association` from custom domain (NOT `*.myshopify.com`)
- **In-WebView link interception:** `open_externally=true/1` query param → `webView(_:decidePolicyFor:decisionHandler:)` cancels navigation + emits `checkoutDidClickLink` event
- **Deep link detection:** `CheckoutURL.isDeepLink()` — any non-HTTP(S) scheme triggers `checkoutDidClickLink`
- **External URL fallback:** `CheckoutDelegate.checkoutDidClickLink` default impl → `UIApplication.shared.canOpenURL()` + `.open()`

**Data Flow:**
```
Universal Link / Deep Link (shop.{shopId}.app://callback or https://...)
    → Linking.getInitialURL() / useInitialURL() in App.tsx
    → StorefrontURL.isCheckout() → shopify.present(url)  [WebView]
    → StorefrontURL.isCart() → navigation.navigate('Cart')
    → else → Linking.openURL(url)  [browser]

OAuth Flow:
    1. customerAccountManager.buildAuthorizationURL() → shopify.com/authentication/{shopId}/oauth/authorize?...code_challenge&state
    2. Browser opens → user authenticates → redirect to shop.{shopId}.app://callback?code&state
    3. handleAuthCallback(code, state) → validates state → POST /oauth/token (code_verifier)
    4. Tokens stored in EncryptedStorage → session restored on app start
```

---

## REPO 3: checkout-sheet-kit-swift (v3.8.1)

### a) File Tree
- Simpan di: `hasil/trees/checkout-sheet-kit-swift.txt`
- **163 file** total (excluding samples and generated files)
- Struktur: `Sources/ShopifyCheckoutSheetKit/` (core), `Sources/ShopifyAcceleratedCheckouts/` (accelerated wallets), `Tests/`, `Samples/`, `documentation/`, `Package.swift`, `ShopifyCheckoutSheetKit.podspec`

### b) Peta Arsitektur

#### Entry Points
| Entry | File |
|-------|------|
| Public API | `Sources/ShopifyCheckoutSheetKit/ShopifyCheckoutSheetKit.swift` — `present(checkout:from:)`, `preload(checkout:)`, `invalidate()`, `configure(_:)` |
| Configuration | `Sources/ShopifyCheckoutSheetKit/Configuration.swift` |
| Checkout View | `Sources/ShopifyCheckoutSheetKit/CheckoutViewController.swift` — `UINavigationController` wrapping `CheckoutWebViewController` |
| Checkout Web | `Sources/ShopifyCheckoutSheetKit/CheckoutWebView.swift` — `WKWebView` subclass with navigation delegate |
| Checkout URL | `Sources/ShopifyCheckoutSheetKit/CheckoutURL.swift` — URL classification (`isDeepLink()`, `isMultipassURL()`, `isConfirmationPage()`) |
| Checkout Delegate | `Sources/ShopifyCheckoutSheetKit/CheckoutDelegate.swift` — lifecycle events incl. `checkoutDidClickLink(url:)` |
| Checkout Bridge | `Sources/ShopifyCheckoutSheetKit/CheckoutBridge.swift` — WKScriptMessageHandler + JS injection |
| Completed Event | `Sources/ShopifyCheckoutSheetKit/CheckoutCompletedEvent.swift` + `CheckoutCompletedEventDecoder.swift` |
| Message Handler | `Sources/ShopifyCheckoutSheetKit/MessageHandler.swift` — WKScriptMessageHandler wrapper |
| Logger | `Sources/ShopifyCheckoutSheetKit/Logger.swift` — `OSLogger` (subsystem: `com.shopify.checkoutsheetkit`) |
| User Agent | `Sources/ShopifyCheckoutSheetKit/UserAgent.swift` — `ShopifyCheckoutSDK/{version} (schema;colorscheme;platform)` |
| MetaData | `Sources/ShopifyCheckoutSheetKit/Internal/MetaData.swift` — version `3.8.1`, schema `8.1` |
| Web Pixels | `Sources/ShopifyCheckoutSheetKit/PixelEvents.swift`, `Sources/ShopifyCheckoutSheetKit/WebPixelsEventDecoder.swift` |
| CheckoutError | `Sources/ShopifyCheckoutSheetKit/CheckoutError.swift` — `CheckoutErrorCode` enum + `CheckoutError` enum |
| ProgressBar | `Sources/ShopifyCheckoutSheetKit/ProgressBarView.swift` |
| Confetti | `Sources/ShopifyCheckoutSheetKit/ConfettiCannon.swift` |
| DecodeDictionary | `Sources/ShopifyCheckoutSheetKit/DecodeDictionary.swift` |

#### Accelerated Checkouts Layer
| File | Purpose |
|------|---------|
| `Sources/ShopifyAcceleratedCheckouts/ShopifyAcceleratedCheckouts.swift` | Main entry — `apiVersion = "2026-04"`, logger config |
| `Sources/ShopifyAcceleratedCheckouts/ShopifyAcceleratedCheckouts+Configuration.swift` | `Configuration` class — storefront domain, access token, customer |
| `Sources/ShopifyAcceleratedCheckouts/ShopifyAcceleratedCheckouts+Errors.swift` | Error types for accelerated checkouts |
| `Sources/ShopifyAcceleratedCheckouts/Internal/GraphQLClient/GraphQLClient.swift` | Custom GraphQL client (async/await) |
| `Sources/ShopifyAcceleratedCheckouts/Internal/StorefrontAPI/StorefrontAPI.swift` | `https://{storefrontDomain}/api/{apiVersion}/graphql.json` |
| `Sources/ShopifyAcceleratedCheckouts/Internal/Models/CheckoutIdentifier.swift` | Cart/variant checkout ID parsing |
| `Sources/ShopifyAcceleratedCheckouts/Wallets/Wallet.swift` / `.swift` | Wallet button base |
| `Sources/ShopifyAcceleratedCheckouts/Wallets/WalletController.swift` | Presents checkout via native SDK |
| `Sources/ShopifyAcceleratedCheckouts/Wallets/ShopPay/ShopPayViewController.swift` | Shop Pay — appends `?payment=shop_pay` to checkout URL |
| `Sources/ShopifyAcceleratedCheckouts/Wallets/ShopPay/ShopPayButton.swift` | Shop Pay button view |
| `Sources/ShopifyAcceleratedCheckouts/Wallets/ApplePay/ApplePayViewController.swift` | Apple Pay flow (PKPaymentAuthorizationController) |
| `Sources/ShopifyAcceleratedCheckouts/Wallets/ApplePay/ApplePayConfiguration.swift` | `merchantIdentifier`, `contactFields`, `supportedShippingCountries` |
| `Sources/ShopifyAcceleratedCheckouts/Wallets/ApplePay/ApplePayButton.swift` | Apple Pay button view |
| `Sources/ShopifyAcceleratedCheckouts/Wallets/ApplePay/ApplePayButtonRepresentable.swift` | SwiftUI wrapper |
| `Sources/ShopifyAcceleratedCheckouts/Wallets/ApplePay/ApplePayAuthorizationDelegate/` | Apple Pay auth delegate (state machine) |
| `Sources/ShopifyAcceleratedCheckouts/Wallets/ApplePay/ErrorHandler/` | Error handling for Apple Pay |
| `Sources/ShopifyAcceleratedCheckouts/Wallets/ApplePay/Data/` | PKDecoder, PKEncoder, CardBrandMapper, PassKitFactory, PaymentData |

#### GraphQL Client (custom, not Apollo)
| File | Description |
|------|-------------|
| `GraphQLClient.swift` | Async HTTP client — `QueryRequest`, `MutationRequest`, `AnyCodable` for variable encoding |
| `GraphQLDocument/` | Built-in GraphQL queries/mutations (CartCreate, CartLinesAdd, etc.) |
| `GraphQLRequest/` | Request encoding with minification |
| `GraphQLTypes.swift` | Type aliases for scalars |
| `GraphQLResponse.swift` | Response decoding wrapper |
| `GraphQLScalars.swift` | Scalar type definitions |

#### Internal Extensions
| File | Purpose |
|------|---------|
| `Extensions/Collection.swift` | Collection utilities (cartesian product for delivery options) |
| `Extensions/Color.swift` | UIColor/SwiftUI Color extensions |
| `Extensions/Locale.swift` | Locale helpers |
| `Extensions/LocalizableString+Bundle.swift` | Localization |
| `Extensions/Task.swift` | Async task helpers |
| `Extensions/URL.swift` | `URL.appendQueryParam()` helper |

#### Test Infrastructure
| File | Description |
|------|-------------|
| `Tests/ShopifyCheckoutSheetKitTests/` | Unit tests for CheckoutURL, CheckoutWebView, Configuration, Logger, UserAgent, CheckoutBridge, CheckoutCompletedEvent |
| `Tests/ShopifyAcceleratedCheckoutsTests/` | Tests for GraphQL client, Apple Pay, Shop Pay, error handlers |
| `Tests/ShopifyCheckoutSheetKitTests/Mocks/` | Mock objects: `MockCheckoutDelegate`, `MockCheckoutWebViewDelegate`, `MockLogger`, `MockNavigationAction`, `MockWebView` |

#### Samples
| Sample | Files |
|--------|-------|
| MobileBuyIntegration | Full iOS app with GraphQL cart operations, universal links, customer account auth |
| ShopifyAcceleratedCheckoutsApp | SwiftUI app demonstrating Shop Pay + Apple Pay accelerated checkout |

### c) URL / Endpoint Ekstraksi
- Simpan di: `hasil/urls_checkout-sheet-kit-swift.md`

### d) Dependency & CVE Analysis

**Swift Package Dependencies (Package.swift):**
| Package | URL | Version | CVE Status |
|---------|-----|---------|------------|
| `SwiftLintPlugin` | github.com/lukepistrol/SwiftLintPlugin | `>=0.2.2` | Wrapper plugin, no runtime CVE risk |
| `ViewInspector` | github.com/nalexn/ViewInspector | `>=0.10.0` | Test-only dependency, no runtime risk |

**No external runtime dependencies** — the SDK uses only Apple frameworks:
- `WebKit` (WKWebView, WKScriptMessageHandler, WKNavigationDelegate)
- `PassKit` (Apple Pay — PKPaymentAuthorizationController, PKShippingMethod)
- `UIKit` / `SwiftUI` / `Foundation`
- `os.log` (OSLogger)

**iOS Deployment Target Risk:**
- Core SDK: iOS 13.0 minimum
- AcceleratedCheckouts: iOS 16.0+ (`@available(iOS 16.0, *)`)
- `isAcceleratedCheckoutAvailable()` returns `false` on iOS < 16.0 (graceful fallback)

**No external library CVE risk** — pure Swift/Apple framework stack.

### e) Ringkasan Output

**Stack:** Swift | Swift Package Manager | CocoaPods | WKWebView (iOS 13+) | PassKit (Apple Pay) | Custom GraphQL Client (iOS 16+) | SwiftUI/UIKit

**Endpoints:**
- `https://{storefrontDomain}/api/{apiVersion}/graphql.json` — Storefront GraphQL API
  - `apiVersion = "2026-04"` (from `ShopifyAcceleratedCheckouts.swift:14`)
  - Header: `X-Shopify-Storefront-Access-Token`
- Checkout URL (runtime) → WKWebView
- `applinks:domain.com` — iOS Universal Links (entitlements)
- `.well-known/apple-app-site-association` — Apple AASA file (served from custom domain only)
- Apple Pay merchant domain — provided by consumer app via `merchantIdentifier`

**Auth Model:**
- No direct auth in SDK — relies on consumer app for tokens
- Storefront Access Token passed to native SDK via `ShopifyCheckoutSheetKit.configuration` (not exposed in CheckoutSheetKit core — only in `ShopifyAcceleratedCheckouts.Configuration`)
- Apple Pay: `PKPaymentAuthorizationController` with `merchantIdentifier` (Apple validates via entitlements)
- Shop Pay: Checkout URL with `?payment=shop_pay` appended — no token exchange

**Deeplink / Universal Link Handling:**
- `CheckoutURL.isDeepLink()`: non-HTTP(S) scheme → intercepted as deep link → `checkoutDidClickLink`
- `CheckoutURL.isMultipassURL()`: contains "multipass" → special handling
- `CheckoutURL.isConfirmationPage()`: regex `thank[_-]you` on path components → order ID extraction
- `isExternalLink()`: detects `open_externally=true/1` query param → cancels WKWebView navigation → emits `checkoutDidClickLink(url)`
- `removeExternalParam()`: strips `open_externally` from URL before passing to delegate
- **External URL opening:** `CheckoutDelegate.checkoutDidClickLink(url:)` default impl → `UIApplication.shared.canOpenURL(url)` → `UIApplication.shared.open(url)`
- `CheckoutViewController.swift:162` → `CheckoutDelegateWrapper.checkoutDidClickLink` → same fallback if no custom handler
- **Recovery mode:** On 5xx errors, `presentFallbackViewController(url:)` creates a new WKWebView with non-persistent cookie store (avoids cross-instance pollution) and `isBridgeAttached = false` (disables JS bridge)
- **Cache invalidation:** 5-minute timeout for preloaded webviews; `invalidate(disconnect: true)` on any HTTP error ≥ 400

**WebView Navigation Delegate (`CheckoutWebViewController` + `CheckoutWebView`):**
- `decidePolicyFor navigationAction` → allows if HTTP/HTTPS + not external/deep link; cancels + emits event for external/deep
- `decidePolicyFor navigationResponse` → checks HTTP status code:
  - 401 → `checkoutUnavailable` (non-recoverable)
  - 404 → `checkoutUnavailable` (non-recoverable)
  - 410 → `checkoutExpired` (non-recoverable)
  - 500-599 → `checkoutUnavailable` (recoverable in non-recovery mode)
  - Other ≥ 400 → `checkoutUnavailable` (non-recoverable)
- Recovery retry limit: `checkoutViewDidFailWithErrorCount < 2`
- `webView(_:didFail:)` ignores `NSURLErrorCancelled` (redirect cancellation)

**Data Flow:**
```
Consumer calls: CheckoutSheetKit.present(checkout: URL, from: UIViewController, delegate:)
    ↓
CheckoutViewController → CheckoutWebViewController → CheckoutWebView (WKWebView)
    ↓
WKNavigationDelegate.decidePolicyFor → checks: external link? (open_externally param) | deep link? (non-http scheme)
    → Yes → emit checkoutDidClickLink(url) → default: UIApplication.shared.open(url)
    → No → allow navigation
    ↓
WKNavigationDelegate.decidePolicyFor navigationResponse → checks HTTP status:
    → 4xx/5xx → emit checkoutDidFail → if recoverable + < 2 retries → presentFallbackViewController (recovery mode, no bridge)
    → 2xx → allow
    ↓
JS → window.MobileCheckoutSdk.dispatchMessage() → CheckoutBridge.decode → WebEvent
    → checkoutComplete → ConfettiCannon.fire() + delegate.checkoutDidComplete
    → error → delegate.checkoutDidFail
    → webPixels → delegate.checkoutDidEmitWebPixelEvent
```

---

## CROSS-REPO OBSERVATIONS & BUG HUNTING NOTES

### OAuth Flow Differences
| Aspect | Python API | RN | Swift (sample) |
|--------|-----------|-----|------| ---------|
| OAuth flavor | OAuth 2.0 (no PKCE) | OAuth 2.1 + PKCE | OAuth 2.1 + PKCE (in sample) |
| State param | `create_permission_url(state=...)` — state provided by consumer, comparison NOT in library | `PKCE.generateState()` (27 bytes) + stored + validated in `handleAuthCallback` | Same as RN |
| HMAC validation | `validate_hmac()` in `validate_params()` — **mandatory before token exchange** | None (PKCE replaces HMAC) | Same as RN |
| Timestamp replay | `timestamp < time.time() - 86400` → reject (1-day window) | None (PKCE + short-lived codes) |
| Token storage | Consumer responsibility (YAML config) | `react-native-encrypted-storage` | iOS Keychain (sample) |
| JWT session tokens | `session_token.py` — `decode_from_header()` with full validation | Not present in library | Not present in SDK |
| Redirect URI | HTTPS URL (consumer-hosted) | `shop.{shopId}.app://callback` (custom scheme) | Same as RN |

### Potential Security Issues (Bug Hunting Notes)

#### 1. **shopify_python_api: Timestamp validation race condition** (`session.py:110-113`)
```
if int(params.get("timestamp", 0)) < time.time() - one_day: return False
```
- Uses `int()` cast on `timestamp` param — if timestamp is missing, defaults to 0, which is always < `time.time() - 86400` → always rejected. ✓ Good.
- BUT: If `timestamp` is a **float string** (e.g. `"1234.56"`), `int("1234.56")` raises `ValueError` → uncaught exception → 500 error (DoS via crash). **Potential issue.**

#### 2. **shopify_python_api: State param not validated by library** (`session.py:38`)
```python
if state:
    query_params["state"] = state
```
- `state` is **optional** and library does **NOT** validate it on callback. Consumer must compare. The README says "Your should compare the state you provided" but this is not enforced — many consumers skip it. **CSRF risk.**

#### 3. **shopify_python_api: PyJWT constraint too loose** (`setup.py:36`)
- `PyJWT >= 2.0.0` allows vulnerable versions affected by CVE-2022-29217 (algorithm confusion). Should be `>= 2.10.1`.

#### 4. **checkout-sheet-kit-react-native: ID token email extraction without signature validation** (`customerAccountManager.ts:142-158`)
```typescript
const parts = idToken.split('.');
const payload = JSON.parse(atob(parts[1]!));
return payload.email ?? null;
```
- Parses JWT payload **without signature verification**. Email is trusted without validation. If ID token is tampered (and attacker can intercept/modify traffic), fake email could be accepted. Relies entirely on HTTPS transport + OAuth redirect security. **Information trust issue.**

#### 5. **checkout-sheet-kit-swift: `checkoutDidClickLink` default opens ANY URL via `UIApplication.shared.open()`** (`CheckoutDelegate.swift:83-85`)
```swift
private func handleUrl(_ url: URL) {
    if UIApplication.shared.canOpenURL(url) {
        UIApplication.shared.open(url)
    }
}
```
- Only checks `canOpenURL` (scheme registered in Info.plist) — does NOT validate the URL is from a trusted domain.
- `open_externally` param is consumer-controlled within the checkout WebView.
- **Risk**: If a malicious page inside the checkout can inject a navigation with `open_externally=true`, it can open any registered URL scheme (e.g., `itms-apps://`, `sms:`, `tel:`, or other apps' schemes) from within the checkout context. **Potential URL scheme hijacking / phishing.**

#### 6. **checkout-sheet-kit-swift: Recovery mode disables bridge but keeps same checkout URL** (`CheckoutWebView.swift:194-206`)
- On 5xx error, creates a new `CheckoutWebView` with `recovery: true` — uses `WKWebsiteDataStore.nonPersistent()` but loads the SAME `checkoutURL`.
- If the 5xx is caused by a server-side issue that affects specific checkout sessions, repeated recovery attempts could trigger multiple checkouts.

#### 7. **checkout-sheet-kit-react-native: `App.tsx` universal link handler opens arbitrary URLs** (`App.tsx`)
```typescript
// Open everything else in a mobile browser
const canOpenUrl = await Linking.canOpenURL(url);
if (canOpenUrl) {
    await Linking.openURL(url);
}
```
- No URL validation/whitelisting. Any universal link received is opened in the browser. If an attacker can craft a universal link to the app (via compromised storefront), they can redirect to any URL.

#### 8. **shopify_python_api: HMAC doesn't exclude `timestamp`** (`session.py:155-165`)
- `__encoded_params_for_signature()` excludes only `hmac` — timestamp is included in HMAC sign.
- This means the timestamp is integrity-protected. ✓ Good.
- But the validation checks timestamp AFTER HMAC validation, so an attacker can replay the same params (including timestamp) within the 1-day window. **Replay window = 24 hours.** This is the documented behavior (1-day replay protection).
