# Architecture Mapping — shopify_app

**Repo:** https://github.com/Shopify/shopify_app  
**Branch:** main  
**Gem Version:** 23.0.3  
**Type:** Ruby on Rails Engine (gem)

---

## 1. Entry Points

| Entry Point | Path | Deskripsi |
|-------------|------|----------|
| Gem entry | `lib/shopify_app.rb` | Main require file, loads all modules |
| Engine | `lib/shopify_app/engine.rb` | Rails engine mounting |
| Version | `lib/shopify_app/version.rb` | `VERSION = "23.0.3"` |
| Routes | `config/routes.rb` | Engine route definitions |
| Gemspec | `shopify_app.gemspec` | Gem specification, dependencies |

---

## 2. Package Structure

### 2.1 Core Library (`lib/shopify_app/`)

| Module | Path | Purpose |
|--------|------|---------|
| Configuration | `lib/shopify_app/configuration.rb` | App config (api_key, secret, scope, embedded, billing) |
| Engine | `lib/shopify_app/engine.rb` | Rails engine, route mounting |
| Utils | `lib/shopify_app/utils.rb` | `sanitize_shop_domain`, `shop_login_url`, `unified_admin_path` |
| Errors | `lib/shopify_app/errors.rb` | ConfigurationError, ShopifyDomainNotFound, ShopifyHostNotFound |
| Logger | `lib/shopify_app/logger.rb` | Structured logging wrapper |

### 2.2 Controller Concerns (`lib/shopify_app/controller_concerns/`)

| Concern | Path | Auth Function |
|---------|------|---------------|
| `csrf_protection.rb` | CSRF: `protect_from_forgery with: :exception, unless: :valid_session_token?` | CSRF bypass via valid session token |
| `login_protection.rb` | Core auth: `activate_shopify_session`, `current_shopify_session`, `redirect_to_login`, `login_url_with_optional_shop` | Main session auth |
| `ensure_has_session.rb` | Ensures session exists before action | Authenticated sessions |
| `ensure_installed.rb` | Checks app installed on shop | Installation check only |
| `ensure_billing.rb` | `check_billing` before_action | Billing verification |
| `embedded_app.rb` | `redirect_to_embed_app_in_admin`, `safe_embedded_app_url` | Iframe embedding |
| `app_proxy_verification.rb` | `verify_proxy_request`, `calculated_signature` | App proxy HMAC verification |
| `payload_verification.rb` | `shopify_hmac`, `hmac_valid?` | HMAC verification (webhooks/proxy) |
| `webhook_verification.rb` | `verify_request` | Webhook HMAC verification |
| `token_exchange.rb` | `activate_shopify_session` via token exchange | Token exchange auth |
| `with_shopify_id_token.rb` | `shopify_id_token`, `jwt_payload` | JWT session token parsing |
| `frame_ancestors.rb` | CSP `frame-ancestors` directive | Clickjacking protection |
| `localization.rb` | `set_locale` around_action | i18n locale setting |
| `redirect_for_embedded.rb` | `redirect_for_embedded`, `fullpage_redirect_to` | Embedded app redirects |
| `sanitized_params.rb` | `sanitized_shop_name`, `sanitized_params` | Shop param sanitization |

### 2.3 Session Management (`lib/shopify_app/session/`)

| Module | Path | Purpose |
|--------|------|---------|
| `session_repository.rb` | Main session repository, dispatch logic |
| `session_storage.rb` | `with_shopify_session` model mixin |
| `shop_session_storage.rb` | Shop session storage methods |
| `shop_session_storage_with_scopes.rb` | Deprecated scope-aware shop storage |
| `user_session_storage.rb` | User session storage methods |
| `user_session_storage_with_scopes.rb` | Deprecated scope-aware user storage |
| `in_memory_session_store.rb` | Base in-memory store |
| `in_memory_shop_session_store.rb` | In-memory shop sessions (testing) |
| `in_memory_user_session_store.rb` | In-memory user sessions (testing) |
| `null_user_session_store.rb` | Null user session (no online tokens) |

### 2.4 Auth (`lib/shopify_app/auth/`)

| Module | Path | Purpose |
|--------|------|---------|
| `token_exchange.rb` | `TokenExchange.perform(id_token)` — exchanges session token for access token |
| `post_authenticate_tasks.rb` | Webhook/script tag installation + after_authenticate_job |

### 2.5 Admin API (`lib/shopify_app/admin_api/`)

| Module | Path | Purpose |
|--------|------|---------|
| `with_token_refetch.rb` | `with_token_refetch` — auto-refresh expired tokens |

### 2.6 Managers (`lib/shopify_app/managers/`)

| Module | Path | Purpose |
|--------|------|---------|
| `webhooks_manager.rb` | Webhook registration and management |
| `script_tags_manager.rb` | Script tag installation and sync |

### 2.7 Access Scopes (`lib/shopify_app/access_scopes/`)

| Strategy | Path | Purpose |
|----------|------|---------|
| `noop_strategy.rb` | No scope verification |
| `shop_strategy.rb` | Shop-level scope changes |
| `user_strategy.rb` | User-level scope changes |

### 2.8 Generators (`lib/generators/shopify_app/`)

| Generator | Creates |
|-----------|---------|
| `install` | Initializer, session store, views, JS |
| `shop_model` | Shop model + DB migration |
| `user_model` | User model + DB migration |
| `home_controller` | Home controller + views |
| `products_controller` | Products controller |
| `authenticated_controller` | Authenticated base controller |
| `app_proxy_controller` | App proxy controller + routes |
| `add_webhook` | Webhook controller + job |
| `add_declarative_webhook` | Declarative webhook |
| `add_after_authenticate_job` | After auth job |
| `add_app_uninstalled_job` | App uninstalled job |
| `add_privacy_jobs` | GDPR privacy jobs |
| `rotate_shopify_token_job` | Token rotation job |
| `views` | View partials |
| `routes` | Route definitions |

---

## 3. Controllers

| Controller | Path | Routes | Auth |
|-----------|------|--------|------|
| `callback_controller.rb` | OAuth callback handler | GET `/auth/shopify/callback` | LoginProtection, EnsureBilling |
| `sessions_controller.rb` | Login/logout/session mgmt | GET/POST `/login`, GET `/logout` | LoginProtection, RedirectForEmbedded |
| `webhooks_controller.rb` | Webhook receiver | POST `/webhooks/:type` | WebhookVerification |
| `authenticated_controller.rb` | Base for authenticated | (inherited) | LoginProtection |
| `extension_verification_controller.rb` | Extension auth | (extension routes) | ExtensionVerification |

---

## 4. Middleware / Auth Flow

### 4.1 OAuth Callback Flow
```
Browser → GET /login?shop={shop}&host={host}&return_to={path}
  → SessionsController#new
  → SessionsController#authenticate
    → redirect_to_begin_oauth (ShopifyAPI::Auth::Oauth.begin_auth)
    → Sets encrypted session cookie with nonce
    → Redirect to Shopify OAuth URL

Browser → Shopify OAuth → Callback /auth/shopify/callback?code={code}&state={state}&shop={shop}&host={host}&hmac={hmac}
  → CallbackController#callback
    → validated_auth_objects: validates HMAC, state, code
    → save_session: SessionRepository.store_session
    → update_rails_cookie: sets encrypted cookie
    → redirect_to_app: follows session[:return_to] or returns to embedded app
```

### 4.2 Token Exchange Flow (New Embedded Auth)
```
Browser → App Bridge sends JWT in Authorization header
  → TokenExchange controller concern
    → current_shopify_session_id from JWT (ShopifyAPI::Utils::SessionUtils)
    → SessionRepository.load_session(id)
    → If session missing/expired: TokenExchange.perform(id_token)
      → ShopifyAPI::Auth::TokenExchange.exchange_token
      → Returns access token + refresh token
      → SessionRepository.store_session
  → with_token_refetch: auto-refresh on 401
```

### 4.3 CSRF Protection Flow
```
All controllers:
  → include ShopifyApp::CsrfProtection
    → protect_from_forgery with: :exception, unless: :valid_session_token?
    → valid_session_token? checks: jwt_payload.present?
    → If JWT present in Authorization header → CSRF skip
    → Otherwise → Rails CSRF token required
```

### 4.4 App Proxy Verification Flow
```
Browser → GET /app_proxy?shop={shop}&path_prefix={prefix}&timestamp={ts}&signature={sig}&...
  → AppProxyVerification
    → skip_before_action :verify_authenticity_token
    → before_action :verify_proxy_request
      → query_string_valid?(query_string)
        → Delete :signature from params
        → calculated_signature = HMAC-SHA256(secret, sorted_params)
        → secure_compare(calculated, provided)
      → head(:forbidden) if invalid
```

### 4.5 return_to Handling
```
1. User requests protected page without auth
  → LoginProtection#redirect_to_login
    → session[:return_to] = return_to_url(path, query)
    → Redirect to /login

2. SessionsController#copy_return_to_param_to_session
    → session[:return_to] = RedirectSafely.make_safe(params[:return_to], "/")
    → Used in session controller for OAuth flow

3. CallbackController#redirect_to_app
    → return_to = session.delete(:return_to)
    → Redirect to return_to (if fully_formed_url?) or decoded_host + return_to
    → Falls back to configuration.root_url if phishing attack detected
```

### 4.6 Session Loading (LoginProtection)
```
current_shopify_session:
  1. Read cookie: ShopifyAPI::Auth::Oauth::SessionCookie::SESSION_COOKIE_NAME
     (encrypted Rails cookie)
  2. If JWT in Authorization header: session_id_from_shopify_id_token(id_token, cookies, is_online)
  3. SessionRepository.load_session(session_id)
     → Parse session_id: offline_{domain} → shop session by domain
     → Otherwise: online_{user_id} → user session by user_id
  4. Check expiry: if expired → clear session, redirect to login
  5. Check scopes: if scope mismatch → clear session, redirect to login
  6. ShopifyAPI::Context.activate_session(current_shopify_session)
```

---

## 5. Cookie Analysis

### 5.1 Session Cookies

| Cookie | Flags | Setter | Purpose |
|--------|-------|--------|---------|
| `__Host-$_shopify_app_session` | HttpOnly, Secure, SameSite=Lax, Path=/ | `cookies.encrypted[...]` in Rails | Encrypted Rails session |
| `session[:return_to]` | (in encrypted session) | LoginProtection | Post-login redirect URL |
| `session[:shopify_user_id]` | (in encrypted session) | CallbackController | Online session user ID |
| `session[:locale]` | (in encrypted session) | Localization | i18n locale |

**Session Cookie Security:**
- `secure: true` — Set on session cookie (callback_controller.rb:62, sessions_controller.rb:52)
- `http_only: true` — Set on session cookie (callback_controller.rb:63, sessions_controller.rb:52)
- `SameSite` — Default Rails SameSite (Lax), not explicitly set
- `expires` — Set from OAuth cookie object

### 5.2 Cookie Security Analysis

**Strengths:**
- Cookies are encrypted using Rails' encrypted cookie store
- `http_only: true` enforced on session cookies (prevents XSS theft)
- `secure: true` enforced on session cookies
- `RedirectSafely.make_safe` used for return_to sanitization
- CSRF protection with `:exception` strategy
- HMAC verification uses `secure_compare` (timing-safe)

**Potential Issues:**
1. **Cookie `SameSite` not explicitly set** — relies on Rails defaults (could be `Strict` or `Lax` depending on Rails version)
2. **No session fixiation protection in OAuth flow** — session is not regenerated on login
3. **`return_to` uses `RedirectSafely.make_safe`** — but this is an external gem; should be verified
4. **App proxy HMAC: sorted params joined without delimiter** — potential collision: `a=b&cd=e` vs `a=bc&d=e` could produce same signature
5. **CSRF bypass too broad**: `valid_session_token?` skips ALL CSRF protection if ANY valid JWT is present, even for state-changing requests

---

## 6. Auth Model

### 6.1 Authentication Strategies

| Strategy | Condition | Flow |
|----------|-----------|------|
| New embedded auth (token exchange) | `config.new_embedded_auth_strategy = true` + embedded | JWT → token exchange → access token |
| Legacy OAuth (auth code grant) | Default | 3-legged OAuth → session token |
| Session token auth | App Bridge | JWT in `Authorization: Bearer` header |

### 6.2 Authorization / Session Verification

| Concern | Method | Check |
|---------|--------|-------|
| `LoginProtection` | `activate_shopify_session` | Session exists, not expired, scopes match |
| `EnsureHasSession` | (includes LoginProtection) | Full auth + session loading |
| `EnsureInstalled` | `installed_shop_session` | App installed on shop only (no user auth) |
| `EnsureBilling` | `check_billing` | Active payment for shop |
| `CsrfProtection` | `protect_from_forgery` | CSRF token or valid session JWT |

### 6.3 Session Types

| Type | Description | Storage Key |
|------|-------------|-------------|
| Offline (shop) | Access token for the store, no user context | `offline_{shopify_domain}` |
| Online (user) | Access token for individual user | `{user_id}_{shopify_user_id}` |

---

## 7. .env Example / Configuration

### 7.1 Env Vars (shopify_app.rb.tt initializer)
```ruby
ENV['SHOPIFY_API_KEY']         # OAuth client ID (required)
ENV['SHOPIFY_API_SECRET']       # OAuth client secret (required)
ENV['HOST']                     # App host URL
ENV['SHOPIFY_APP_PRIVATE_SHOP'] # Private shop mode
ENV['SHOPIFY_TEST_CHARGES']     # Enable test charges
ENV['SPIN_FQDN']                # Spin environment FQDN
```

### 7.2 Configuration Options (configuration.rb)
```ruby
config.api_key                   = ENV['SHOPIFY_API_KEY']
config.secret                    = ENV['SHOPIFY_API_SECRET']
config.old_secret                = ENV['SHOPIFY_OLD_SECRET']  # For key rotation
config.scope                     = ["read_products", ...]
config.embedded_app              = true/false
config.new_embedded_auth_strategy = true/false
config.root_url                  = "/"
config.login_url                 = config.root_url + "/login"
config.login_callback_url        = "auth/shopify/callback"
config.myshopify_domain          = "myshopify.com" (default)
config.unified_admin_domain      = "shopify.com" (default)
config.api_version               = "2025-01" etc
config.webhooks                  = [{topic, address}]
config.script_tags               = [...]
config.billing                   = BillingConfiguration.new(...)
config.reauth_on_access_scope_changes = true
config.check_session_expiry_date = true
config.log_level                 = :info
```

### 7.3 ShopifyAPI Context Setup
```ruby
ShopifyAPI::Context.setup(
  api_key: config.api_key,
  api_secret_key: config.secret,
  old_api_secret_key: config.old_secret,
  api_version: config.api_version,
  host: ENV['HOST'],
  scope: config.scope,
  is_private: ...,
  is_embedded: config.embedded_app,
  log_level: :info,
  user_agent_prefix: "ShopifyApp/#{VERSION}",
  expiring_offline_access_tokens: true,  # Optional
)
```

---

## 8. Test Files

| Test Directory | File Count | Purpose |
|----------------|-----------|---------|
| `test/controllers/` | 4 | Controller tests (callback, sessions, extension_verification, webhooks) |
| `test/controllers/concerns/` | 4 | Concern tests (embedded_app, ensure_authenticated_links, ensure_billing, ensure_has_session, ensure_installed) |
| `test/shopify_app/` | 20+ | Unit tests for all modules |
| `test/generators/` | 14 | Generator tests |
| `test/routes/` | 4 | Route tests |
| `test/integration/` | 1 | Integration tests |
| `test/javascripts/` | 2 | JS tests (redirect, storage_access) |
| `test/shopify_app/session/` | 8 | Session storage tests |
| `test/shopify_app/controller_concerns/` | 6 | Controller concern tests |
| `test/shopiy_app/auth/` | 2 | Auth tests (post_authenticate, token_exchange) |
| `test/shopify_app/managers/` | 2 | Manager tests (script_tags, webhooks) |
| `test/shopify_app/access_scopes/` | 3 | Scope strategy tests |
| `test/shopify_app/test_helpers/` | 1 | Test helper tests |
