# URL / Domain / Endpoint Extraction — shopify_python_api

## Version
- Library version: **12.7.1** (from `shopify/version.py`)
- Python support: 3.7 - 3.12

## Dependencies (from `setup.py`)
| Package | Constraint | CVE Notes |
|---------|-----------|-----------|
| `pyactiveresource` | `>=2.2.2` | Core REST transport; depends on `six`, `PyYAML`, `python-dateutil` |
| `PyJWT` | `>=2.0.0` | Core JWT decoding; used in `session_token.py` |
| `PyYAML` | `>=6.0.1` (py3.12+) / `>=5.x` (older) | YAML parsing for `yamlobjects.py` |
| `six` | (unpinned) | Python 2/3 compat (legacy) |
| `mock` | `>=1.0.1` (test only) | — |

### PyJWT CVE Watch
- PyJWT < 2.4.0 — CVE-2022-29217 (algorithm confusion); constraint `>=2.0.0` is NOT patched against this if pip resolves to 2.0-2.3.x
- PyJWT < 2.10.1 — CVE-2022-29217 (EC algorithm confusion); constraint `>=2.0.0` allows vulnerable versions
- **RISK**: Constraint `>=2.0.0` does not enforce minimum patched version

### pyactiveresource CVE Watch
- pyactiveresource 2.2.2 — no known CVEs but depends on `six` (legacy Python 2 support remains in code paths)

## All Endpoints & Domains

### OAuth / Auth Endpoints
| URL | File:Line | Description |
|-----|-----------|-------------|
| `https://{shop}.myshopify.com/admin/oauth/authorize` | `session.py:41` | OAuth authorization URL (PKCE-less, state param) |
| `https://{shop}.myshopify.com/admin/oauth/access_token` | `session.py:52` | Token exchange endpoint (POST `client_id`, `client_secret`, `code`) |
| `https://shopify.dev/docs/admin-api/access-scopes` | `docs/api-access.md` | Documentation link for scopes |
| `https://shopify.dev/concepts/apps/building-embedded-apps-using-session-tokens` | `docs/session-tokens.md` | Session token docs |

### API Endpoints (template)
| URL Pattern | File:Line | Description |
|-------------|-----------|-------------|
| `https://{shop}.myshopify.com/admin/api/{version}/...` | `base.py:33-36` | Base REST API path |
| `https://{shop}.myshopify.com/admin/api/unstable/...` | `api_version.py:83` | Unstable API endpoint |

### Default API Versions (from `api_version.py`)
- `2021-10`, `2022-01`, `2022-04`, `2022-07`, `2022-10`, `2023-01`, `2023-04`, `2023-07`, `2023-10`, `2024-01`, `2024-04`, `2024-07`, `2024-10`, `unstable`

### Domains
| Domain | File:Line | Description |
|--------|-----------|-------------|
| `myshopify.com` | `session.py:13` | Default myshopify_domain |
| `myshopify.com` | `utils/shop_url.py:10` | Default in sanitize_shop_domain |
| `developers.shopify.com` | `README.md` | Developer docs |
| `shopify.dev` | `README.md`, docs | Shopify dev portal |
| `partners.shopify.com` | `README.md` | Shopify Partners |
| `community.shopify.dev` | `README.md` | Shopify community |
| `pypi.org/project/shopifyapp/` | `README.md` | New Python package (experimental) |
| `ecommerce.shopify.com` | `README.md` | Shopify forums |
| `github.com/Shopify/pyactiveresource` | `README.md` | Core dependency (pyactiveresource) |

### CLI Tool URLs
| URL | File | Description |
|-----|------|-------------|
| `https://{domain}/admin/apps/private` | `scripts/shopify_api.py:88` | Manual link to generate private app credentials |
| `~/.shopify/shops/{connection}.yml` | `scripts/shopify_api.py` | Local config file path (credential storage) |

### Internal Domains / Substrings Used in Code
| String | File:Line | Context |
|--------|-----------|---------|
| `myshopify.com` | `session.py:13` | `myshopify_domain` class attr; shop URL is normalized to `{name}.myshopify.com` |
| `https://` | `session.py:12` | Default `protocol` |
| `admin/oauth/authorize` | `session.py:42` | OAuth path |
| `admin/oauth/access_token` | `session.py:53` | Token exchange path |
| `admin/api` | `api_version.py:52` | API prefix path |
| `User-Agent` header value: `ShopifyPythonAPI/{VERSION} Python/{python_version}` | `base.py:85` | HTTP User-Agent sent to all Shopify API requests |
| `X-Shopify-Access-Token` | `base.py:153` | Auth header for API requests |
| `X-Shopify-Storefront-Access-Token` | `README.md` (sample app reference) | Storefront API token header (not in core library) |

## Auth-Related File Map

| File | Purpose |
|------|---------|
| `shopify/session.py` | **Primary OAuth engine**: `create_permission_url()`, `request_token()`, `validate_params()`, `validate_hmac()`, `calculate_hmac()` |
| `shopify/session_token.py` | **JWT Session Token** decoder: `decode_from_header()` — validates Bearer JWT, issuer hostname, issuer/dest match, leeway=10s |
| `shopify/api_access.py` | Scope parsing & coverage: `ApiAccess` class with `covers()` |
| `shopify/utils/shop_url.py` | `sanitize_shop_domain()` — sanitizes/validates shop domain |
| `shopify/base.py` | `ShopifyResource.activate_session()` / `clear_session()` — sets `X-Shopify-Access-Token` header |
| `test/session_test.py` | OAuth flow tests: HMAC validation, timestamp replay, state param |
| `test/session_token_test.py` | JWT validation tests: expired token, invalid alg, invalid signature, audience mismatch, issuer validation |
| `docs/api-access.md` | Doc on scope matching with `ApiAccess` |
| `docs/session-tokens.md` | Doc on JWT session token usage with decorator example |
| `shopify/yamlobjects.py` | YAML-based credential storage (config files) |
