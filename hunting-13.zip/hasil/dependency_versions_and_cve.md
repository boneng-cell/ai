# Dependency Versions & CVE Check

## shop-chat-agent

Source: `package.json` (declared) + `package-lock.json` (resolved)

| Package | Declared | Resolved | CVE / Advisory |
|---------|----------|----------|-----------------|
| `@anthropic-ai/sdk` | ^0.40.0 | 0.40.1 | CVE-2026-41686 (medium): Insecure Default File Permissions in Local Filesystem Memory Tool |
| `@prisma/client` | ^6.2.1 | 6.19.1 | None found |
| `prisma` | ^6.2.1 | 6.19.1 | None found |
| `@shopify/shopify-app-react-router` | ^1.0.0 | 1.1.0 | None found |
| `@shopify/shopify-app-session-storage-prisma` | ^7.0.0 | 7.0.3 | None found |
| `@shopify/app-bridge-react` | ^4.1.6 | 4.1.10 | None found |
| `@react-router/dev` | ^7.9.1 | 7.11.0 | CVE-2026-42211 (high): Arbitrary constructor invocation via TYPE_ERROR deserialization leading to Unauth RCE |
| `@react-router/fs-routes` | ^7.9.1 | 7.11.0 | Same as above |
| `@react-router/node` | ^7.9.1 | 7.11.0 | Same as above |
| `@react-router/serve` | ^7.9.1 | 7.11.0 | Same as above |
| `react-router` | ^7.9.1 | 7.11.0 | CVE-2026-42211 (high): RCE via deserialization |
| `react` | ^18.2.0 | 18.3.1 | None found |
| `react-dom` | ^18.2.0 | 18.3.1 | None found |
| `isbot` | ^5.1.0 | 5.1.27 | None found |
| `dotenv` | ^16.3.1 | 16.6.1 | None found |
| `vite` | ^6.2.2 | (dev) | None found |
| `@shopify/cli` | (dev) | 3.81.2 (via package-lock) | None found |

**Node engine**: >=20.10

---

## subscriptions-reference-app

Source: `package.json` (exact versions pinned)

| Package | Declared | CVE / Advisory |
|---------|----------|-----------------|
| `@remix-run/dev` | 2.16.8 | None found |
| `@remix-run/node` | 2.16.8 | None found |
| `@remix-run/react` | 2.16.8 | None found |
| `@remix-run/serve` | 2.16.8 | None found |
| `@shopify/shopify-api` | 11.13.0 | None found |
| `@shopify/shopify-app-remix` | 3.8.3 | None found |
| `@shopify/shopify-app-session-storage-prisma` | 6.0.7 | None found |
| `@shopify/polaris` | 13.9.5 | None found |
| `@shopify/ui-extensions` | 2025.7.0 | None found |
| `@shopify/ui-extensions-react` | 2025.7.0 | None found |
| `@google-cloud/tasks` | 6.1.0 | None found |
| `@google-cloud/storage` | 7.16.0 | None found |
| `zod` | 3.25.67 | CVE-2023-4316 (medium): Denial of service vulnerability — check if 3.25.67 is patched |
| `jsonwebtoken` | 9.0.2 | None found |
| `lodash` | 4.17.21 | None found |
| `prisma` | 6.10.1 | None found |
| `graphql` | (resolutions: 16.8.1) | None found |
| `luxon` | 3.6.1 | None found |
| `msw` | 2.10.2 | None found |

## Critical Findings Summary

### 1. shop-chat-agent — React Router RCE (CVE-2026-42211) [HIGH]
- **Package**: `react-router` v7.11.0 (also `@react-router/*`)
- **CVE**: CVE-2026-42211
- **Description**: Arbitrary constructor invocation via TYPE_ERROR deserialization in turbo-stream. This can lead to unauthenticated Remote Code Execution.
- **Impact**: The `/chat` endpoint and SSR rendering via `entry.server.jsx` are affected.
- **Remediation**: Upgrade to react-router >= 7.x latest patch (check for fix release).

### 2. shop-chat-agent — Claude SDK File Permissions (CVE-2026-41686) [MEDIUM]
- **Package**: `@anthropic-ai/sdk` v0.40.1
- **CVE**: CVE-2026-41686
- **Description**: Insecure default file permissions in Local Filesystem Memory Tool.
- **Impact**: If using Claude's file/memory tools, local filesystem could be exposed.
- **Remediation**: Upgrade to latest `@anthropic-ai/sdk`.

### 3. subscriptions-reference-app — `/internal/jobs/run` Unauthenticated RCE
- **File**: `app/routes/internal.jobs.run.tsx:24`
- **Description**: The `/internal/jobs/run` endpoint executes arbitrary jobs by name with no authentication or authorization. An attacker can POST any registered job name with crafted parameters.
- **Impact**: Full RCE — attacker can trigger billing charges, contract cancellations, dunning flows, email sending, bulk operations on any shop.
- **Remediation**: Add authentication middleware (e.g., `authenticate.admin`) or restrict to internal network/GCP Cloud Tasks only with proper OIDC validation.
