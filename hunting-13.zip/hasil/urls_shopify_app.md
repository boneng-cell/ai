# URL / Domain / Endpoint Extraction — shopify_app

**Repo:** https://github.com/Shopify/shopify_app  
**Tanggal:** 10 Agustus 2026  
**Branch:** main  
**Gem Version:** 23.0.3

---

## 1. Dokumentasi & Situs Web

| No | URL | Sumber |
|----|-----|--------|
| 1 | `https://rubygems.org` | Gemfile:1, shopify_app.gemspec |
| 2 | `https://github.com/Shopify/shopify_app` | README |
| 3 | `https://shopify.dev/concepts/apps/building-embedded-apps-using-session-tokens` | authentication.md |
| 4 | `https://shopify.dev/concepts/about-apis/authentication#api-access-modes` | authentication.md |
| 5 | `https://shopify.dev/tutorials/authenticate-with-oauth` | authentication.md |
| 6 | `https://shopify.dev/concepts/apps/building-embedded-apps-using-session-tokens` | README |
| 7 | `https://shopify.dev/docs/apps/auth/oauth/session-tokens/getting-started` | authentication.md |
| 8 | `https://shopify.dev/docs/apps/auth/installation#shopify-managed-installation` | authentication.md |
| 9 | `https://shopify.dev/docs/apps/auth/get-access-tokens/token-exchange` | authentication.md |
| 10 | `https://shopify.dev/docs/apps/auth/get-access-tokens/authorization-code-grant` | authentication.md |
| 11 | `https://shopify.dev/docs/apps/auth/access-token-types/offline` | sessions.md |
| 12 | `https://shopify.dev/docs/apps/auth/access-token-types/online` | sessions.md |
| 13 | `https://shopify.dev/docs/api/usage/access-scopes` | shopify_app.rb.tt |
| 14 | `https://shopify.dev/docs/api/usage/versioning#release-schedule` | README |
| 15 | `https://shopify.dev/apps/billing` | shopify_app.rb.tt |
| 16 | `https://shopify.dev/docs/apps/auth/session-tokens/using-a-session-token` | controller-concerns.md |
| 17 | `https://shopify.dev/docs/api/admin` | webhook_verification.rb (docs) |
| 18 | `https://shopify.dev/docs/apps/tools/cli/configuration` | authentication.md |
| 19 | `https://partners.shopify.com` | README (Partners dashboard) |
| 20 | `https://shopify.dev/concepts/shopify-introduction` | README |

---

## 2. Trusted Domains

| Domain | Source | Usage |
|--------|--------|-------|
| `shopify.com` | utils.rb:10 | Unified admin domain, trusted |
| `myshopify.io` | utils.rb:10 | Trusted for session domains |
| `myshopify.com` | utils.rb:10, configuration.rb:49 | Default myshopify domain |
| `spin.dev` | utils.rb:10 | Spin dev environment |
| `shop.dev` | utils.rb:10 | Shop.dev domain |

---

## 3. OAuth Endpoints

| Endpoint | Pattern | File |
|----------|---------|------|
| OAuth begin auth | `ShopifyAPI::Auth::Oauth.begin_auth` | sessions_controller.rb:46 |
| OAuth callback | `ShopifyAPI::Auth::Oauth.validate_auth_callback` | callback_controller.rb:34 |
| Token exchange | `ShopifyAPI::Auth::TokenExchange.exchange_token` | auth/token_exchange.rb:40 |
| Unified admin install path | `https://admin.${unified_admin_domain}/store/${shop}` | sessions_controller.rb:37, utils.rb:49 |
| Admin OAuth install | `https://${shop}/oauth/install?client_id=${api_key}` | sessions_controller.rb:37 |

### 3.1 OAuth Callback Parameters
| Param | Source |
|-------|--------|
| `code` | callback_controller.rb:31, validated_auth_objects |
| `shop` | callback_controller.rb:31 |
| `timestamp` | callback_controller.rb:31 |
| `state` | callback_controller.rb:31 |
| `host` | callback_controller.rb:31 |
| `hmac` | callback_controller.rb:31 |

### 3.2 OAuth Token Exchange Parameters
| Param | Source |
|-------|--------|
| `grant_type` | auth.helpers.ts:235 |
| `client_id` | auth.helpers.ts:231 |
| `audience` | auth.helpers.ts:232 |
| `subject_token` | auth.helpers.ts:233 |
| `subject_token_type` | auth.helpers.ts:234 |
| `scopes` | auth.helpers.ts:235 |

---

## 4. Webhook Endpoints

| Route | Method | Controller | Purpose |
|-------|--------|-----------|---------|
| `/webhooks/:type` | POST | `WebhooksController` | Receive webhooks |
| `/webhooks/app_uninstalled` | POST | WebhooksController | App uninstalled |
| `/webhooks/customers/data_request` | POST | WebhooksController | Data request |
| `/webhooks/customers/redact` | POST | WebhooksController | Customer data redaction |
| `/webhooks/shop/redact` | POST | WebhooksController | Shop data redaction |

### 4.1 Webhook Verification
| Header | Sumber |
|--------|--------|
| `HTTP_X_SHOPIFY_HMAC_SHA256` | payload_verification.rb:8 |
| `HTTP_X_SHOPIFY_SHOP_DOMAIN` | webhook_verification.rb:40 |

---

## 5. App Proxy Endpoints

| Route | Controller | Purpose |
|-------|-----------|---------|
| `/app_proxy` | AppProxyController | App proxy entry point |
| `/app_proxy/:path` | AppProxyController | App proxy nested routes |

### 5.1 App Proxy Verification Parameters
| Param | Source |
|-------|--------|
| `shop` | app_proxy_verification.rb |
| `path_prefix` | app_proxy_verification.rb |
| `timestamp` | app_proxy_verification.rb |
| `signature` | app_proxy_verification.rb:18 |

**Signature Algorithm:** HMAC-SHA256 using `config.secret`  
**Verification:** `OpenSSL::HMAC.hexdigest(OpenSSL::Digest.new("sha256"), secret, sorted_params)`

---

## 6. Session & Authentication Routes

| Route | Method | Controller | Purpose |
|-------|--------|-----------|---------|
| `/login` | GET | SessionsController#new | Login page |
| `/login` | POST | SessionsController#create | Authenticate |
| `/logout` | GET | SessionsController#destroy | Logout |
| `/patch_shopify_id_token` | GET | SessionsController#patch_shopify_id_token | JWT refresh |
| `/auth/shopify/callback` | GET | CallbackController#callback | OAuth callback |
| `/top_level_interaction` | GET | SessionsController#top_level_interaction | Top-level redirect |

---

## 7. Cookie Names & Session Storage

| Cookie Name | Controller Concern | Usage |
|-------------|-------------------|-------|
| `__Host-$_shopify_app_session` | ShopifyAPI::Auth::Oauth::SessionCookie | Encrypted Rails session cookie |
| Rails session | ActionDispatch | `session[:shopify_user_id]`, `session[:return_to]`, `session[:locale]`, `session[:shopify_user]` |

### 7.1 OAuth State Parameter
| Param | Store | Source |
|-------|-------|--------|
| `state` | OAuth URL | sessions_controller.rb (ShopifyAPI) |
| `nonce` | OAuth URL | customer.ts |
| `return_to` | `session[:return_to]` | sessions_controller.rb:60, login_protection.rb:153 |

---

## 8. Environment Variables

| Env Var | Usage | Source |
|---------|-------|--------|
| `SHOPIFY_API_KEY` | OAuth client ID | shopify_app.rb.tt, configuration.rb |
| `SHOPIFY_API_SECRET` | OAuth client secret | shopify_app.rb.tt, configuration.rb |
| `SHOPIFY_APP_PRIVATE_SHOP` | Private shop mode | shopify_app.rb.tt |
| `HOST` | App host for OAuth | shopify_app.rb.tt |
| `SHOPIFY_APP_DISABLE_WEBPACKER` | Webpacker toggle | configuration.rb |
| `SPIN_FQDN` | Spin environment FQDN | utils.rb:48 |
| `SHOPIFY_HYDROGEN_FLAG_PORT` | Dev port override | server.ts (e2e) |
| `SHOPIFY_TEST_CHARGES` | Test billing charges | shopify_app.rb.tt |

---

## 9. Asset/CDN URLs

| URL | Sumber |
|-----|--------|
| `https://cdn.shopify.com/shopifycloud/app-bridge.js` | redirect.html.erb:12, add_csp_directives |
| `/assets/shopify_app/redirect.js` | redirect.html.erb:13 |
| `/assets/shopify_app/redirect-{hash}.js` | redirect.html.erb:16 (SRI) |

---

## 10. Shopify Admin/Dev URLs

| URL Pattern | Source |
|-------------|--------|
| `https://admin.${shop}/admin` | embedded_app.rb:31 |
| `https://admin.${unified_admin_domain}` | frame_ancestors.rb:13 |
| `https://${shop}/oauth/install?client_id=${api_key}` | sessions_controller.rb:37 |
| `https://${shop}/oauth/authorize` | OAuth flow |
| `https://${shop}/admin` | admin redirect |
