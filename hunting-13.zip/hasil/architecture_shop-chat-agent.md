# Architecture Summary — shop-chat-agent

## Stack
| Layer | Technology |
|-------|-----------|
| Framework | React Router (v7) + `@react-router/serve` |
| AI Provider | Claude (Anthropic SDK v0.40.0) — `claude-sonnet-4-20250514` |
| Shopify SDK | `@shopify/shopify-app-react-router` (v1.0.0) |
| Session Storage | `@shopify/shopify-app-session-storage-prisma` + Prisma |
| Database | SQLite via Prisma (v6.2.1) |
| MCP Client | Custom JSON-RPC 2.0 client (`app/mcp-client.js`) |
| Frontend | React 18 + Polaris (via Shopify app-bridge-react) |
| Extension | Shopify Theme Extension (chat-bubble) |
| Build | Vite + TypeScript |
| Node | >=20.10 |

## Entry Points
- `package.json` scripts:
  - `dev`: `shopify app dev` (start dev server)
  - `start`: `react-router-serve ./build/server/index.js`
  - `docker-start`: `npm run setup && npm run start`
  - `setup`: `prisma generate && prisma migrate deploy`
- `app/entry.server.jsx` — SSR entry point (React streaming)
- `app/shopify.server.js` — Shopify OAuth config (authPathPrefix="/auth")
- `shopify.web.toml` — web config (roles: frontend+backend, webhooks_path="/webhooks/app/uninstalled")

## Route Map
| File | Route | Function |
|------|-------|----------|
| `app/routes/_index/route.jsx` | `/` | Landing redirect (→ `/app?shop=...`) |
| `app/routes/app.jsx` | `/app` | App layout (Polaris AppProvider, embedded) |
| `app/routes/app._index.jsx` | `/app/_index` | App home page |
| `app/routes/chat.jsx` | `/chat` | **SSE chat endpoint** (GET+POST) |
| `app/routes/auth.$.jsx` | `/auth/*` | Shopify OAuth (SDK-handled) |
| `app/routes/auth.callback.jsx` | `/auth/callback` | Customer OAuth2 PKCE callback |
| `app/routes/auth.token-status.jsx` | `/auth/token-status` | Token status polling (CORS-enabled) |
| `app/routes/api.webhooks.jsx` | `/api/webhooks` | Webhook handler (APP_UNINSTALLED) |

## Auth Model
1. **Shop Admin Auth**: Standard Shopify OAuth via `@shopify/shopify-app-react-router` SDK. Flow: `/auth` → Shopify → callback → session stored in Prisma `Session` table.
2. **Customer Auth (PKCE)**: Custom OAuth2 PKCE flow:
   - `generateAuthUrl(conversationId, shopId)` in `auth.server.js`:
     - Reads `authorization_endpoint` and `token_endpoint` from `.well-known/openid-configuration`
     - Reads `mcp_api` from `.well-known/customer-account-api`
     - State = `${conversationId}-${shopId}` (hyphen-delimited)
     - Scope: `customer-account-mcp-api:full`
     - PKCE: `code_challenge_method=S256`
   - Code verifier stored in `CodeVerifier` table (state → verifier, expiresAt=10min, single-use)
   - `auth.callback.jsx` loader: exchanges code → token via `token_endpoint`, stores in `CustomerToken` table (keyed by `conversationId`)
3. **Webhook Auth**: HMAC verification handled by Shopify SDK (`authenticate.webhook(request)`)

## Data Flow
```
Customer (Browser)
  ┓ POST/GET /chat?history=true&conversation_id=XYZ
  ┗──────────────────────────────┓
                                  ┃
  Chat UI (Theme Extension)       ▼
  ┗→ POST /chat                 /chat route
    (SSE stream)                   ┃
      │                           ├─ Parse: message, conversation_id, prompt_type
      │                           ├─ Get Origin header → shopDomain
      │                           ├─ getCustomerAccountUrls(shopDomain, convId)
      │                           ├─ If not cached → fetch .well-known/* from shopDomain
      │                           ├─ MCPClient(hostUrl, convId, shopId, mcpApiUrl)
      │                           ├─ Connect storefront MCP: POST hostUrl/api/mcp (tools/list)
      │                           ├─ Connect customer MCP: POST accountUrl/customer/api/mcp (with token)
      │                           ├─ saveMessage(convId, 'user', body)
      │                           ├─ getConversationHistory(convId) → map to Claude format
      │                           ├─ claude.streamConversation(messages, tools, handlers)
      │                           ├─ SSE events: chunk, message_complete, tool_use, end_turn
      │                           ├─ Tool calls → MCPClient.callTool → JSON-RPC tools/call
      │                           ├─ Auth required → generateAuthUrl → return auth URL to client
      │                           ├─ saveMessage(convId, 'assistant', response)
      │                           └─ SSE stream → client
      │
  Client receives SSE stream and renders chat
```

## Key Files
| File | Purpose |
|------|---------|
| `app/services/claude.server.js` | Claude API client (streaming) |
| `app/services/tool.server.js` | Tool result processing (product search formatting) |
| `app/services/config.server.js` | Central config (model, max_tokens, tool names) |
| `app/services/streaming.server.js` | SSE stream manager (createSseStream, createStreamManager) |
| `app/mcp-client.js` | MCP client (JSON-RPC 2.0: tools/list, tools/call) |
| `app/db.server.js` | Prisma client + DB operations (sessions, tokens, conversations, code verifiers) |
| `app/auth.server.js` | PKCE auth URL generation + crypto helpers |
| `app/prompts/prompts.json` | System prompts (standardAssistant, enthusiasticAssistant) |
| `prisma/schema.prisma` | DB schema (6 models) |
| `.mcp.json` | Cursor MCP server config (shopify-dev-mcp) |
| `shopify.app.toml` | App config (scopes, redirects, webhooks) |

## MCP Tools Exposed
The MCP client connects to two MCP servers and discovers tools dynamically via `tools/list`:

### Storefront MCP (`/<shopDomain>/api/mcp`)
- No authentication required
- Tools from README:
  - `search_shop_catalog` (product search)
  - `update_cart` (add/remove/update cart items)
  - `get_cart` (retrieve cart contents)
  - `search_shop_policies_and_faqs` (policy/FAQ lookup)
  - `get_most_recent_order_status` (recent order status)
  - `get_order_status` (specific order lookup)
  - Checkout initiation (from cart tools)

### Customer MCP (`/<accountHost>.account.myshopify.com/customer/api/mcp`)
- Authentication: Bearer token from `CustomerToken` table
- Uses `customer-account-mcp-api:full` scope
- Tools: same categories as storefront (catalog, cart, orders, policies)

### MCP Configuration File
- `.mcp.json` / `.cursor/mcp.json`:
  - Server: `shopify-dev-mcp` (via `npx @shopify/dev-mcp@latest`)
  - Env: `POLARIS_UNIFIED=true`, `LIQUID=true`

## Prisma Schema
| Model | Fields | Notes |
|-------|--------|-------|
| Session | id, shop, state, isOnline, scope, expires, accessToken, userId, firstName, lastName, email, accountOwner, locale, collaborator, emailVerified | Shopify session |
| CustomerToken | id, conversationId, accessToken, refreshToken, expiresAt, createdAt, updatedAt | Customer OAuth token |
| CodeVerifier | id, state (unique), verifier, createdAt, expiresAt | PKCE code verifier |
| Conversation | id, messages[], createdAt, updatedAt | Chat conversation |
| Message | id, conversationId, role, content, createdAt | Chat messages |
| CustomerAccountUrls | id, conversationId (unique), mcpApiUrl, authorizationUrl, tokenUrl, createdAt, updatedAt | Cached customer account endpoints |

## CORS Headers (Chat Endpoint)
- `Access-Control-Allow-Origin`: dynamically reflects request `Origin` header (or `*`)
- `Access-Control-Allow-Credentials`: `true`
- `Access-Control-Allow-Methods`: `GET, POST, OPTIONS`
- `Access-Control-Allow-Headers`: dynamically reflects `Access-Control-Request-Headers`
