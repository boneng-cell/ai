# Security Findings — subscriptions-reference-app

## 1. `/internal/jobs/run` Endpoint — CRITICAL: Unauthenticated Arbitrary Job Execution

### File: `app/routes/internal.jobs.run.tsx` (lines 1-43)

### The Vulnerability
```ts
export async function action({request, context}: ActionFunctionArgs) {
  await addShopToContext(request, context);

  try {
    await jobs.execute(request);
    return json({status: 'success'}, {status: 200});
  } catch (err) {
    const error = err instanceof Error ? err : new Error(String(err));
    throw json({status: 'failure', error: error.message}, {status: 500});
  }
}
```

**CRITICAL**: This endpoint has **no authentication or authorization whatsoever**. Any external attacker can:
1. POST a JSON payload with `jobName` and `parameters`
2. The `JobRunner.execute()` looks up the job class by name from the registry
3. Constructs a new instance with the provided parameters
4. Executes `job.run()` synchronously

### Impact: Arbitrary Job Execution
An attacker can execute ANY registered job with attacker-controlled parameters:

| Job | Risk |
|-----|------|
| `RebillSubscriptionJob` | Charge any subscription contract (fraudulent billing) |
| `ChargeBillingCyclesJob` | Charge all billing cycles in a date range (mass fraud) |
| `ScheduleShopsToChargeBillingCyclesJob` | Trigger billing scheduling for any shop |
| `SubscriptionContractCancelService` | Cancel subscriptions via job parameters |
| `CreateSellingPlanTranslationsJob` | Run with arbitrary shop + payload on behalf of any shop |
| `CustomerSendEmailJob` | Send emails as the app (email spoofing/phishing) |
| `MerchantSendEmailJob` | Send merchant emails (potential phishing) |
| `TransitionFailedContractsToActiveJob` | Reactivate failed contracts (financial loss) |
| `AddFieldsToMetaobjectJob` | Modify metaobject definitions |

### The `execute()` Method (JobRunner.ts, lines 42-64)
```ts
async execute(request: Request) {
  const payload = await request.json();
  const {jobName, parameters} = payload;
  this.logger.debug({jobName, parameters}, `Executing job from request`);

  const JobClass = this.registry.get(jobName);
  if (JobClass == null) {
    throw new Error(`Failed to find registered job ${jobName}`);
  }

  const instance = Reflect.construct(JobClass, [parameters]);
  await instance.run();
}
```

- No validation that `jobName` is a valid job
- No authentication on the endpoint
- No rate limiting
- No IP allowlisting
- `Reflect.construct(JobClass, [parameters])` — attacker-controlled constructor injection

### The `addShopToContext` Helper
```ts
async function addShopToContext(request: Request, context: AppLoadContext): Promise<void> {
  const payload: JobPayload = await request.clone().json();
  const { parameters: { shop } } = payload;
  shop && (context.shop = shop);
}
```
- Extracts `shop` from request body without verification
- Used for error logging context only, but still indicates no auth model

### Cloud Task Scheduler Context
In production (when `CLOUD_TASKS` scheduler is configured), the `CloudTaskScheduler` sends tasks to `callbackUrl` (which should be `/internal/jobs/run`). This endpoint is intended for Cloud Tasks to call back, but:
1. The endpoint is publicly accessible (no auth)
2. Cloud Tasks uses OIDC tokens, but this endpoint **does not verify** the OIDC token
3. The endpoint accepts any POST with valid JSON `{ jobName, parameters }`

## 2. RebillSubscriptionJob Analysis

### File: `app/jobs/billing/RebillSubscriptionJob.ts`

### Flow
1. Extract `subscriptionContractId` and `originTime` from payload
2. Call `unauthenticated.admin(shop)` — uses unauthenticated admin session
3. Query `SubscriptionContractRebillingQuery` — fetches `lastPaymentStatus`
4. If already `SUCCEEDED`, terminate (skip)
5. Execute `SubscriptionBillingCycleChargeMutation` with the contract ID and originTime
6. Handle user errors:
   - `CONTRACT_PAUSED` — terminate
   - `BILLING_CYCLE_SKIPPED` — terminate
   - `CONTRACT_TERMINATED` — terminate
   - `BILLING_CYCLE_CHARGE_BEFORE_EXPECTED_DATE` — terminate
   - Other errors — throw (will retry)

### Security Observations
- Uses `unauthenticated.admin(shop)` — creates an admin session without app installation verification
- No check that the shop is still an active subscriber to the app
- The `originTime` parameter is passed directly from the payload to the GraphQL mutation without validation
- Since `/internal/jobs/run` has no auth, an attacker can trigger billing on arbitrary contract IDs

### Test Fixture (RebillSubscriptionJobPayload.json)
```json
{
  "subscriptionContractId": "gid://shopify/SubscriptionContract/1",
  "originTime": "2023-01-20T15:00:00-05:00"
}
```

## 3. SubscriptionContractDraft Analysis

### Files: `app/models/SubscriptionContractDraft/SubscriptionContractDraft.ts` + `.server.ts`

### `buildDraftFromContract(shopDomain, contractId, graphqlClient)`
1. Calls `SubscriptionContractUpdateMutation` API (this creates a draft from the contract)
2. Validates `subscriptionContractUpdate.draft.id` exists and no user errors
3. Returns `new SubscriptionContractDraft(shopDomain, contractId, draftId, graphqlClient)`

### SubscriptionContractDraft Class Methods
1. **`addLine(lineToAdd)`** — Adds a subscription line via `subscriptionDraftLineAdd`
2. **`removeLine(lineId)`** — Removes a line via `subscriptionDraftLineRemove`
3. **`updateLine(lineId, {quantity, currentPrice, pricingPolicy})`** — Updates line
   - Throws if neither quantity nor price is provided
4. **`update(input)`** — Updates draft with `SubscriptionDraftUpdateInput` (delivery policy, billing policy, address)
5. **`updateAddress(address, deliveryMethodName)`** — Updates address:
   - Shipping: sets `deliveryMethod.shipping.address`
   - Local delivery: requires `phone`, sets `deliveryMethod.localDelivery.address` with `localDeliveryOption.phone`
6. **`getDiscounts()`** — Queries existing discounts on draft
7. **`commit()`** — Commits draft via `subscriptionDraftCommit`
   - Calls `removeInvalidDiscounts()` first (removes discounts with no entitled lines)
8. **`removeDiscount(discountId)`** (private) — Removes a discount
9. **`removeInvalidDiscounts()`** (private) — Auto-removes discounts with no entitled lines

### Security Observations
- The `contractId` is passed to `composeGid('SubscriptionContract', id)` without validation in route handlers
- `pricingPolicy.cycleDiscounts` with `computedPrice` is passed directly from user input (from the edit form)
- The `draft.commit()` method calls `removeInvalidDiscounts()` which removes discounts that have no entitled lines — this is correct behavior
- No rate limiting on draft creation — an attacker could spam the API

## 4. Webhook Handlers & HMAC Verification

### HMAC Verification
All webhook handlers use `authenticate.webhook(request)` from `@shopify/shopify-app-remix`:
```ts
const {topic, shop, payload} = await authenticate.webhook(request);
```

This function performs:
1. **HMAC-SHA256 verification** of the `X-Shopify-Hmac-Sha256` header
2. **Shop domain validation** from the `X-Shopify-Shop-Domain` header
3. **Webhook ID validation** (idempotency check)
4. Extracts `topic`, `shop`, and `payload` from the verified request

### All Webhook Handlers
| File | Topic | Action |
|------|-------|--------|
| `webhooks.app.uninstalled.tsx` | APP_UNINSTALLED | `DisableShopJob` (delete sessions, disable billing schedule) |
| `webhooks.cli.tsx` | APP_UNINSTALLED | `DisableShopJob` (catch-all for CLI dev webhooks) |
| `webhooks.customer_redact.ts` | CUSTOMERS_DATA_REQUEST, CUSTOMERS_REDACT | Return 200 (no data stored) |
| `webhooks.shop_redact.ts` | SHOP_REDACT | `DeleteBillingScheduleJob` |
| `webhooks.subscription_contracts.create.tsx` | SUBSCRIPTION_CONTRACTS_CREATE | `CustomerSendEmailJob` + `TagSubscriptionOrderJob` |
| `webhooks.subscription_contracts.activate.tsx` | SUBSCRIPTION_CONTRACTS_ACTIVATE | Log only |
| `webhooks.subscription_contracts.cancel.tsx` | SUBSCRIPTION_CONTRACTS_CANCEL | `CustomerSendEmailJob` + `MerchantSendEmailJob` |
| `webhooks.subscription_contracts.pause.tsx` | SUBSCRIPTION_CONTRACTS_PAUSE | Log only |
| `webhooks.subscription_billing_cycles.skip.tsx` | SUBSCRIPTION_BILLING_CYCLES_SKIP | `CustomerSendEmailJob` |
| `webhooks.subscription_billing_attempts.success.tsx` | SUBSCRIPTION_BILLING_ATTEMPTS_SUCCESS | `DunningStopJob` + `TagSubscriptionOrderJob` |
| `webhooks.subscription_billing_attempts.failure.tsx` | SUBSCRIPTION_BILLING_ATTEMPTS_FAILURE | `DunningStartJob` |
| `webhooks.selling_plan_groups.create_or_update.tsx` | SELLING_PLAN_GROUPS_CREATE/UPDATE | `CreateSellingPlanTranslationsJob` |

### Security Observations
- All webhooks are properly HMAC-verified via the Shopify SDK
- The `appGID` check in `CreateSellingPlanTranslationsJob`:
  ```ts
  if (appGid !== env.appGID) {
    this.logger.info('Not creating translation since event is not from subscriptions app');
    return;
  }
  ```
  This prevents other apps from triggering the translation job, but `env.appGID` (`APP_GID`) must be properly configured
- The `webhooks.cli.tsx` handler only processes `APP_UNINSTALLED` and ignores/silently logs all other topics — this could be a security concern if the CLI webhook is exposed in production

## 5. Customer Account Email Endpoint

### File: `app/routes/customerAccount.emails.ts`

### Auth Model
Uses `authenticate.public.customerAccount(request)` — this is a **session-token-based** authentication (not HMAC).

```ts
const {sessionToken, cors} = await authenticate.public.customerAccount(request);
const {sub: customerGid, dest: shopDomain} = sessionToken;
```

- `sessionToken.sub` = customer GID (e.g., `gid://shopify/Customer/1`)
- `sessionToken.dest` = shop domain
- If authentication fails, the function "returns early without any error" — the comment literally says "ie: request comes from a non-customer-account context"

### Security Observation
If `authenticate.public.customerAccount` doesn't throw on failure, and the function continues, an attacker could potentially inject payloads. But looking at the code, it does `return cors(...)` even on the error path, so the job enqueue is protected.

## 6. Job Scheduler — InlineScheduler (Production Default)

### File: `app/lib/jobs/schedulers/InlineScheduler.ts`
```ts
async enqueue(job: Job, options: SchedulerOptions = {}) {
  const body = JSON.stringify(job);
  const {parameters} = JSON.parse(body);
  const jobInstance = Reflect.construct(job.constructor, [parameters]) as Job;
  await jobInstance.run();
}
```

In production, the `InlineScheduler` runs jobs synchronously in the same process. This means:
- No task isolation
- No retry mechanism beyond `Job.run()` which throws
- The `/internal/jobs/run` endpoint executes jobs inline with the HTTP request

## 7. Environment Configuration

### Config: `config/index.ts`
- **Production**: `scheduler: 'INLINE'` — no Cloud Tasks
- **Development**: `scheduler: 'INLINE'` — no Cloud Tasks
- **Test**: `scheduler: 'TEST'` — captures jobs as Request objects

### Key Environment Variables
- `SHOPIFY_API_KEY` — App client ID
- `SHOPIFY_API_SECRET` — App API secret
- `SCOPES` — Comma-separated access scopes
- `SHOPIFY_APP_URL` — App URL
- `APP_GID` — App GID (for `CreateSellingPlanTranslationsJob` filtering)
- `MAINTENANCE_MODE` — When 'true', bypasses DB check in health endpoint

### Missing from config
- No Google Cloud Tasks configuration is defined in `config/index.ts` — the `CLOUD_TASKS` case is never triggered by config, so production always uses `INLINE` scheduler. This means the `/internal/jobs/run` endpoint is always active in production.
