# Executive Summary — Security Reconnaissance Report

**Tanggal:** 10 Agustus 2026  
**Repos yang di-analisis:** `Shopify/hydrogen` (main), `Shopify/shopify_app` (main)

---

## Repo 1: Hydrogen

### Ringkasan Singkat

| Field | Value |
|-------|-------|
| **Stack** | TypeScript / Node.js / React 18.3.1 + React Router 7.16.0 / Vite / Cloudflare Workers (Oxygen) |
| **Paradigma** | React SSR/CSR dengan React Router v7, monorepo (pnpm workspaces) |
| **Entry point** | `templates/skeleton/server.ts` → `createRequestHandler()` (React Router) |
| **Endpoint** | Storefront API: `/{domain}/api/{ver}/graphql.json`; Customer Account API: `https://shopify.com/{shopId}/account/customer/api/{ver}/graphql` |
| **Auth model** | OAuth 2.0 + PKCE (Customer Account API); cookie-based session for cart; no traditional user auth |
| **Data flow** | Worker `fetch(request, env, ctx)` → `createHydrogenRouterContext()` → `createRequestHandler()` → React Router render → `storefront.query/mutate()` → SFAPI |

### Cookie Inventory

| Cookie | HttpOnly | Secure | SameSite | Path | MaxAge | Owner |
|--------|----------|--------|----------|------|--------|-------|
| `session` | ✅ true | ❌ **NOT SET** | Lax | `/` | ❌ (session-only) | Hydrogen core |
| `cart` | ❌ false | ❌ false | Lax (worktop default) | `/` | ❌ | hydrogen-react |
| `_shopify_y` | ❌ false | ❌ false | Lax | `/` | ~1 year | Shop tracking |
| `_shopify_s` | ❌ false | ❌ false | Lax | `/` | 30 min | Shop tracking |
| `_shopify_analytics` | ✅ server-set | ✅ server-set | - | - | varies | Storefront API |
| `_shopify_marketing` | ✅ server-set | ✅ server-set | - | - | varies | Storefront API |
| `_shopify_essential` | ✅ server-set | ✅ server-set | - | - | varies | Storefront API |

### Key Security Findings (Hydrogen)

| ID | Risk | Component | Detail |
|----|------|-----------|--------|
| **H1** | **HIGH** | `SESSION_SECRET` | Default value `"foobar"` in `.env` template. If unchange di production, **session cookies dapat di-decode dan di-forgeri**. `createCookieSessionStorage` menggunakan `secrets` array, tapi default-nya lemah. |
| **H2** | **HIGH** | Multipass CORS | `account_.login.multipass.tsx` route's `getCorsHeaders()` melakukan **origin reflection**: `Access-Control-Allow-Origin` diset ke request origin jika cocok. Attacker dapat melakukan credential-leaking requests via preflight. |
| **H3** | **MEDIUM** | Cookie `secure` | Session cookie (`session.ts`) tidak menit `secure: true`. Cookie hanya dilindungi oleh `httpOnly` dan `sameSite: 'lax'`, tetapi bisa dibawa lewat HTTP (non-HTTPS) connection. |
| **H4** | **MEDIUM** | `return_to` handling | `getRedirectUrl()` hanya memvalidasi `isLocalPath()` (origin check). Parameter `return_to` di-parse dari query langsung tanpa sanitization tambahan. |
| **H5** | **MEDIUM** | Multipass token | Token multipass menggunakan AES-CBC + HMAC-SHA256 dengan crypto-js. `created_at` disertakan dalam plaintext (terlihat dari `parseToken` — hanya dicek, tidak dihapus). **Timing attack** pada token expiry check. |
| **H6** | **MEDIUM** | Cart cookie | Cart ID cookie (`cart`) **tidak memiliki HttpOnly, Secure, atau SameSite** yang eksplisit. Dapat dibaca oleh JavaScript (XSS risk) dan dikirim via HTTP. |
| **H7** | **MEDIUM** | `_shopify_y/_s` cookies | **Tidak HttpOnly dan tidak Secure**. Cookie tracking dapat diakses oleh JavaScript. Vulnerable terhadap XSS pencurian token tracking. |
| **H8** | **LOW** | `powered-by` header | `X-Powered-By: Shopify, Hydrogen` — informasi fingerprint. |
| **H9** | **LOW** | `collectTrackingInformation` | Default `true` — secara otomatis mengumpulkan cookies dan server-timing dari subrequests. Bisa mengekspos tracking data. |
| **H10** | **LOW** | Cookie option validation | `cartSetIdDefault` menerima `cookieOptions` langsung dari pengguna developer tanpa validasi. Jika developer mengoverride dengan `secure: false`, maka cart cookie rentan. |

### Auth Flow (Hydrogen)

```
Customer → /account/login (GET)
  → context.customerAccount.login()
    → OAuth 2.0 authorize ke https://shopify.com/{shopId}/oauth/authorize
    → PKCE: code_challenge, state, nonce disimpan di session
    → Redirect ke Shopify

Shopify → /account/authorize (GET)
  → context.customerAccount.authorize()
    → Validate state (CSRF) dan code_verifier (PKCE)
    → Exchange code untuk access_token + refresh_token + id_token
    → Token disimpan di session (encrypted cookie)

Subsequent request:
  → context.customerAccount.isLoggedIn()
    → checkExpires() — auto-refresh token jika expired
    → Token refresh via POST /oauth/token (refresh_token grant)

Logout:
  → context.customerAccount.logout()
    → Clear session, redirect ke /logout
```

### Data Flow (Hydrogen)

```
1. Worker fetch handler (server.ts)
   ├─→ createHydrogenRouterContext(request, env, ctx)
   │    ├─→ AppSession.init (cookie session storage, SESSION_SECRET)
   │    ├─→ caches.open('hydrogen')
   │    ├─→ createStorefrontClient (Storefront API client)
   │    └─→ createCustomerAccountClient (Customer Account API)
   │    └─→ createCartHandler (Cart with session persistence)
   │
2. createRequestHandler → React Router
   ├─→ Routes match → loader/action
   ├─→ context.storefront.query(graphql, {cache})
   │    └─→ fetchStorefrontApi → POST /api/{ver}/graphql.json
   │         → Cache (CacheDefault/CacheLong/CacheShort)
   │         → Collect subrequest headers (cookies, server-timing)
   │
3. Response
   ├─→ setCollectedSubrequestHeaders (forward SFAPI Set-Cookie)
   ├─→ appendServerTimingHeader (_y, _s, _cmp tracking values)
   └─→ session.commit() if isPending → Set-Cookie: session
```

---

## Repo 2: shopify_app

### Ringkasan Singkat

| Field | Value |
|-------|-------|
| **Stack** | Ruby (3.2+) on Rails (>= 7.1, < 9); Gemfile.lock locks to Rails 7.1.6 |
| **Paradigma** | Rails Engine — embedded Shopify apps |
| **Entry point** | `lib/shopify_app.rb` → `ShopifyApp::Engine` mounted in Rails app |
| **Endpoint** | `/login`, `/auth/shopify/callback`, `/webhooks/:type`, `/app_proxy` |
| **Auth model** | OAuth 2.0 (authorization code grant) + Token Exchange (JWT-based, for embedded apps); session token (JWT) via App Bridge |
| **Data flow** | Controller concern (LoginProtection/EnsureHasSession) → `current_shopify_session` → `ShopifyAPI::Context.activate_session` → Admin API client |

### Auth Flow (shopify_app)

```
Merchant → GET /login?shop={shop}&host={host}&return_to={path}
  → SessionsController#new
    → copy_return_to_param_to_session (session[:return_to] = sanitized)
    → start_oauth / start_install
      → ShopifyAPI::Auth::Oauth.begin_auth
      → Set encrypted cookie (nonce for CSRF)
      → Redirect ke Shopify OAuth URL

Shopify → GET /auth/shopify/callback?code={code}&state={state}&shop={shop}&host={host}&hmac={hmac}
  → CallbackController#callback
    → validated_auth_objects: ShopifyAPI::Auth::Oauth.validate_auth_callback
      → Verifikasi HMAC, state, code
    → save_session: SessionRepository.store_session
    → update_rails_cookie: Set encrypted cookie
    → redirect_to_app (follows session[:return_to])

API request (token exchange):
  → TokenExchange controller concern
    → current_shopify_session_id from JWT (Authorization: Bearer header)
    → SessionRepository.load_session
    → If expired/missing: TokenExchange.perform(id_token)
      → Exchange JWT untuk access_token + refresh_token
    → ShopifyAPI::Context.activate_session
```

### Middleware / Auth Controller Concerns

| Concern | Role | Critical Method |
|---------|------|-----------------|
| `LoginProtection` | Core auth, session loading, scope check | `activate_shopify_session`, `current_shopify_session` |
| `CsrfProtection` | CSRF + JWT session token bypass | `protect_from_forgery with: :exception, unless: :valid_session_token?` |
| `EnsureBilling` | Billing check before action | `check_billing`, `before_action :check_billing` |
| `EnsureHasSession` | Authenticated session required | `activate_shopify_session` (wrapper) |
| `EnsureInstalled` | Installation check only | `installed_shop_session` (⚠️ NOT authenticated) |
| `EmbeddedApp` | App Bridge embedding, iframe | `redirect_to_embed_app_in_admin`, `set_esdk_headers` |
| `AppProxyVerification` | HMAC proxy verification | `verify_proxy_request`, `calculated_signature` |
| `WebhookVerification` | HMAC webhook verification | `verify_request`, `hmac_valid?` |
| `TokenExchange` | JWT → access token | `activate_shopify_session` via `retrieve_session_from_token_exchange` |
| `FrameAncestors` | CSP frame-ancestors | `content_security_policy` |
| `WithShopifyIdToken` | JWT parsing | `shopify_id_token`, `jwt_payload` |
| `PayloadVerification` | HMAC verification base | `shopify_hmac`, `hmac_valid?` |

### Key Security Findings (shopify_app)

| ID | Risk | Component | Detail |
|----|------|-----------|--------|
| **S1** | **HIGH** | App Proxy HMAC | `calculated_signature` menggabungkan param dengan `join` tanpa delimiter: `"#{k}=#{v}"` joined. **Collision attack**: params `a=b,cd=e` dan `a=bc,d=e` menghasilkan signature yang sama. |
| **S2** | **HIGH** | CSRF bypass | `valid_session_token?` hanya memeriksa `jwt_payload.present?`. Jika JWT valid, CSRF protection **sepenuhnya di-skip**. Ini tidak aman untuk state-changing operations (POST/PUT/DELETE) — JWT bisa saja valid tapi request berasal dari CSRF. |
| **S3** | **HIGH** | `EnsureInstalled` | Dokumentasi stern mengatakan: "session dari `shop` param, tidak diverifikasi". Jika developer salah gunakan untuk API calls, **shop spoofing**. |
| **S4** | **MEDIUM** | `return_to` handling | `Copy_return_to_param_to_session` menggunakan `RedirectSafely.make_safe(params[:return_to], "/")`. Bergantung pada eksternal gem `redirect_safely`. Perlu verifikasi bahwa gem ini menghandle open redirect dengan benar. |
| **S5** | **MEDIUM** | Cookie `SameSite` | Cookie session tidak eksplisit set `SameSite`. Bergantung pada default Rails (bisa berubah antar versi). |
| **S6** | **MEDIUM** | Scope re-auth | `reauth_on_access_scope_changes` default `true`, tapi hanya trigger re-auth melalui redirect ke login. **Race condition** saat install/uninstall script tags/webhooks. |
| **S7** | **MEDIUM** | Session fixation | Tidak ada session regeneration pada callback. Cookie lama dibenahi tapi tidak dirotasi secara konsisten. |
| **S8** | **LOW** | Host parameter phishing | `decoded_host` parsing dan validasi melalui `sanitize_shop_domain`. **Potential bypass** jika URL parsing lemah (lihat `embedded_host_authority` di embedded_app.rb). |
| **S9** | **LOW** | `old_secret` rotasi | `old_secret` digunakan untuk HMAC verification. Jika `old_secret` sama dengan `secret`, atau `old_secret` tidak di-clear, **token lama tetap valid** setelah rotasi. |
| **S10** | **LOW** | Webhook HMAC | Hanya memverifikasi `HTTP_X_SHOPIFY_HMAC_SHA256`. **No nonce/timestamp** verification → vulnerable terhadap replay attack. |
| **S11** | **LOW** | `fullpage_redirect_to` | `redirect_to(redirect_to, allow_other_host: true)` di callback_controller — **tergantung validasi** `fully_formed_url?` dan `deduced_phishing_attack?`. |
| **S12** | **LOW** | Log level | `log_level: :info` default — mungkin mengekspor token atau data sensitif di log. |

### Session Management Details

```
Session Storage:
  - Rails encrypted cookie (key: __Host-$_shopify_app_session)
  - HttpOnly: true, Secure: true
  - SameSite: default Rails (Lax)

Offline sessions (shop):
  - Key: "offline_{shopify_domain}"
  - Stored in: SessionRepository.shop_storage (Shop model)

Online sessions (user):
  - Key: "online_{shopify_user_id}"
  - Stored in: SessionRepository.user_storage (User model)

Session expiry check:
  - If check_session_expiry_date=true AND session.expired?
    → Clear session, redirect to login
  - Online tokens cannot be refreshed → full OAuth re-auth required

Token refresh:
  - Offline tokens: automatic via with_shopify_session (ShopSessionStorage)
  - Online tokens: not supported — user must re-authenticate
```

---

## Comparative Analysis

| Aspect | Hydrogen | shopify_app |
|--------|----------|-------------|
| **Framework** | React Router + Cloudflare Worker | Ruby on Rails (Engine) |
| **Session cookie HttpOnly** | ✅ (session), ❌ (cart, _y, _s) | ✅ |
| **Session cookie Secure** | ❌ (not set in session.ts) | ✅ |
| **CSRF Protection** | PKCE state + nonce | `protect_from_forgery` + JWT bypass |
| **Open Redirect** | Mitigated (`isLocalPath` origin check) | Partially mitigated (`RedirectSafely.make_safe`) |
| **JWT Verification** | Nonce validation ✅ | JWT payload parse, no explicit nonce |
| **Token Storage** | Encrypted cookie (session) | Encrypted cookie + DB (Shop/User model) |
| **HMAC Verification** | ❌ (not applicable) | ✅ (webhook, app proxy) |
| **App Proxy Signature** | ❌ (not applicable) | ✅ HMAC-SHA256 (vulnerable to param collision) |
| **Cookie SameSite** | Explicit Lax on most, ❌ on session | Defaults to Rails (Lax) |
| **Cookie Secure** | ❌ not set on session/cart | ✅ set on session cookies |

---

## File Output Summary

Semua file hasil recon tersimpan di:
```
/home/runner/work/hunting-13/hunting-13/hasil/
├── trees/
│   ├── hydrogen.txt           (file tree, 1622 lines)
│   └── shopify_app.txt        (file tree, 397 lines)
├── urls_hydrogen.md           (URL/domain extraction)
├── urls_shopify_app.md        (URL/domain extraction)
├── architecture_hydrogen.md   (architecture mapping)
├── architecture_shopify_app.md (architecture mapping)
├── dependencies.md            (dependency versions + CVE)
├── SUMMARY.md                 (this file)
└── raw_samples/               (raw source files fetched)
```
