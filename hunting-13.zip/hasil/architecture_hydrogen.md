# Architecture Mapping — hydrogen

**Repo:** https://github.com/Shopify/hydrogen  
**Branch:** main  
**Monorepo (pnpm workspaces)**

---

## 1. Entry Points

| Entry Point | Path | Deskripsi |
|-------------|------|----------|
| Root package.json | `package.json` | Monorepo orchestrator (pnpm workspaces) |
| Skeleton server.ts | `templates/skeleton/server.ts` | Cloudflare Worker entry point (`fetch(request, env, ctx)`) |
| Skeleton entry.client.tsx | `templates/skeleton/app/entry.client.tsx` | Client-side hydration entry |
| Skeleton entry.server.tsx | `templates/skeleton/app/entry.server.tsx` | Server-side rendering entry (CSP, SSR) |
| React Router routes | `templates/skeleton/app/routes.ts` + `app/routes/*` | Route definitions (RR v7 file-based) |
| Hydrogen CLI | `packages/cli/src/index.ts` | Oclif-based CLI (`shopify hydrogen *`) |

---

## 2. Package Structure (Monorepo)

| Package | Path | Purpose |
|---------|------|---------|
| `@shopify/hydrogen` | `packages/hydrogen/` | Core Hydrogen library (React Router integration) |
| `@shopify/hydrogen-react` | `packages/hydrogen-react/` | Unopinionated React components (cart, product, analytics) |
| `@shopify/cli-hydrogen` | `packages/cli/` | CLI plugin for Shopify CLI |
| `@shopify/create-hydrogen` | `packages/create-hydrogen/` | Project scaffolding |
| `@shopify/hydrogen-codegen` | `packages/hydrogen-codegen/` | GraphQL type generation |
| `@shopify/mini-oxygen` | `packages/mini-oxygen/` | Local dev runtime (simulates Oxygen) |
| `@shopify/remix-oxygen` | `packages/remix-oxygen/` | Remix integration for Oxygen |
| `cookbook` | `cookbook/` | Recipe system (patches/ingredients) |
| `templates/skeleton` | `templates/skeleton/` | Default project template |

---

## 3. Route Files (Skeleton Template)

| Route File | Purpose | Auth Required |
|-----------|---------|--------------|
| `routes/_index.tsx` | Home page | No |
| `routes/products.$handle.tsx` | Product detail | No |
| `routes/collections.$handle.tsx` | Collection listing | No |
| `routes/cart.tsx` | Cart (POST for mutations) | No |
| `routes/cart.$lines.tsx` | Preloaded cart | No |
| `routes/account.tsx` | Account layout | Yes (customer) |
| `routes/account._index.tsx` | Account redirect | Yes (customer) |
| `routes/account_.login.tsx` | Login (Storefront API form) | No |
| `routes/account_.authorize.tsx` | OAuth callback handler | No (callback) |
| `routes/account_.login.multipass.tsx` | Multipass token endpoint | Session-based |
| `routes/account_.logout.tsx` | Logout | Yes |
| `routes/account_.recover.tsx` | Password recovery | No |
| `routes/account_.reset.$id.$resetToken.tsx` | Password reset | No |
| `routes/account.addresses.tsx` | Address management | Yes (customer) |
| `routes/account.orders._index.tsx` | Orders list | Yes (customer) |
| `routes/account.orders.$id.tsx` | Order detail | Yes (customer) |
| `routes/account.profile.tsx` | Profile update | Yes (customer) |
| `routes/[robots.txt].tsx` | robots.txt | No |
| `routes/[sitemap.xml].tsx` | Sitemap index | No |
| `routes/sitemap.$type.$page.xml.tsx` | Sitemap pages | No |
| `routes/search.tsx` | Search results | No |
| `routes/$.tsx` | Catch-all route | No |
| `routes/blogs.$blogHandle.$articleHandle.tsx` | Blog article | No |
| `routes/pages.$handle.tsx` | Page content | No |
| `routes/discount.$code.tsx` | Discount code redirect | No |

---

## 4. Middleware / Request Pipeline

### 4.1 Server Request Flow (server.ts)
```
Cloudflare Worker (fetch request)
  → createHydrogenRouterContext(request, env, ctx)
    → AppSession.init(request, [env.SESSION_SECRET])     [cookie session storage]
    → caches.open('hydrogen')                             [Cache API]
    → createHydrogenContext({env, request, cache, session, ...})
      → createStorefrontClient()                         [Storefront API client]
      → createCustomerAccountClient()                    [Customer Account API client]
      → createCartHandler()                              [Cart handler with session]
    → createRequestHandler({build, getLoadContext})      [React Router handler]
    → storefrontRedirect() if 404                        [Storefront redirect check]
```

### 4.2 Request Handling (createRequestHandler.ts)
```
createRequestHandler(build)
  → createReactRouterRequestHandler(build, mode)
  → For SFAPI URLs: storefront.forward(request)
  → For MCP URLs: storefront.forwardMcp(request)
  → Otherwise: handleRequest(request, context)
  → collectTrackingInformation: setCollectedSubrequestHeaders(response)
  → appendServerTimingHeader (server-timing with _y, _s, _cmp)
  → appendPoweredByHeader: "Shopify, Hydrogen"
```

### 4.3 Session Commit
```
server.ts:
  if (hydrogenContext.session.isPending)
    → session.commit() → Set-Cookie header
```

---

## 5. Cookie Analysis

### 5.1 Client Cookies (JavaScript)

| Cookie Name | Flags | TTL | Setter | Source |
|-------------|-------|-----|--------|--------|
| `session` | `httpOnly: true`, `sameSite: 'lax'`, `path: '/'` | Session | `createCookieSessionStorage` | templates/skeleton/app/lib/session.ts |
| `cart` | `path: '/'` (worktop defaults) | No explicit TTL | `cartSetIdDefault()` | createCartHandler.ts |
| `_shopify_y` | `samesite: 'Lax'`, `path: '/'` | ~1 year (31,536,000s) | `setCookie()` in useShopifyCookies.tsx | cookies-utils.tsx |
| `_shopify_s` | `samesite: 'Lax'`, `path: '/'` | 30 minutes (1,800s) | `setCookie()` in useShopifyCookies.tsx | cookies-utils.tsx |
| `_shopify_analytics` | HttpOnly (server-set) | Varies | Storefront API response | storefront.ts |
| `_shopify_marketing` | HttpOnly (server-set) | Varies | Storefront API response | storefront.ts |
| `_shopify_essential` | HttpOnly (server-set) | Varies | Storefront API response | storefront.ts |

### 5.2 Server-Only / HTTP-Only Cookies

| Cookie Name | Flags | Description | Source |
|-------------|-------|-------------|--------|
| `_shopify_analytics` | HttpOnly, Secure | Analytics tracking cookie | SFAPI response (Set-Cookie) |
| `_shopify_marketing` | HttpOnly, Secure | Marketing tracking cookie | SFAPI response (Set-Cookie) |
| `_shopify_essential` / `_shopify_essentials` | HttpOnly, Secure | Essential consent cookie | SFAPI response (Set-Cookie) |

### 5.3 Cookie Security Analysis

**Critical Security Issues Found:**
1. **SESSION_SECRET default is insecure**: `.env` template has `SESSION_COOKIE="foobar"` — this is used to encrypt session cookies. If not changed in production, session cookies can be forged.
2. **Cookie `secure` flag not explicitly set**: The `createCookieSessionStorage` in `session.ts` does NOT set `secure: true`. The cookie options only specify `httpOnly`, `path`, `sameSite`, and `secrets`. No `secure` flag, no `maxAge`.
3. **Cookie `maxAge` not set**: The session cookie has no `maxAge`, meaning it defaults to session-only (browser closes). This may be intentional but should be explicit.
4. **`_shopify_y` and `_shopify_s` are NOT HttpOnly**: These are client-side JavaScript cookies with no `httpOnly` flag (can be read by JS), making them susceptible to XSS theft. However, they are tracking tokens, not session tokens.
5. **`_shopify_y` and `_shopify_s` have `secure` undefined**: The worktop cookie library's `stringify` doesn't set `secure` by default, and the code doesn't explicitly set it. This means secure is `false`, cookies sent over HTTP.
6. **CORS headers on multipass endpoint**: The `getCorsHeaders` function in the multipass route allows origin reflection: `Access-Control-Allow-Origin: ${allowedOrigin}` where `allowedOrigin` includes the request origin. This could be an open CORS issue if not properly validated.

### 5.4 Multipass Cookie Analysis (multipassify.server.ts)
- No additional cookies set by multipass routes
- The `return_to` parameter is used for redirect after multipass auth
- The multipass token is generated client-side using `crypto-js`
- The token is Base64 URL-safe encoded (replaces `+` with `-`, `/` with `_`)

---

## 6. Auth Model / Data Flow

### 6.1 Customer Account OAuth Flow (OIDC/OAuth 2.0 + PKCE)
```
1. Browser → /account/login (GET)
   → customerAccount.login({countryCode, acrValues, loginHint, ...})
   → Generates: state, nonce, code_verifier, code_challenge (PKCE)
   → Stores in session: {codeVerifier, state, nonce, redirectPath}
   → Redirect to: https://shopify.com/{shopId}/oauth/authorize?client_id=...&state=...&nonce=...&code_challenge=...&code_challenge_method=S256&redirect_uri=...&response_type=code&scope=openid email&redirect_uri=...

2. Shopify → Callback to /account/authorize (GET)
   → customerAccount.authorize()
   → Validates state param (CSRF check against session)
   → Validates nonce (JWT nonce check)
   → Exchanges code for token: POST https://shopify.com/authentication/{shopId}/oauth/token
   → Stores in session: {accessToken, expiresAt, refreshToken, idToken}

3. Token refresh (automatic)
   → When expiresAt < now + 120s, call refreshToken()
   → POST https://shopify.com/authentication/{shopId}/oauth/token?grant_type=refresh_token

4. Logout
   → customerAccount.logout()
   → Clears session (CUSTOMER_ACCOUNT_SESSION_KEY, BUYER_SESSION_KEY)
   → Redirects to: https://shopify.com/authentication/{shopId}/logout
```

### 6.2 Session Data Structure
```typescript
// HydrogenSessionData (from types.d.ts)
{
  [CUSTOMER_ACCOUNT_SESSION_KEY]: {
    accessToken?: string;     // OAuth access token
    expiresAt?: string;       // Unix timestamp (ms) - 120s buffer
    refreshToken?: string;    // For token refresh
    codeVerifier?: string;    // PKCE verifier
    idToken?: string;         // JWT ID token
    nonce?: string;           // CSRF nonce
    state?: string;           // OAuth state
    redirectPath?: string;    // Where to go after login
  },
  [BUYER_SESSION_KEY]: Partial<BuyerInput>;  // B2B buyer context
}
```

### 6.3 return_to / Redirect Handling
- `getRedirectUrl()` in `packages/hydrogen/src/utils/get-redirect-url.ts`
- Reads `return_to` or `redirect` query param
- Validates with `isLocalPath()` — checks origin match to prevent open redirects
- `ensureLocalRedirectUrl()` wraps this with fallback to default URL
- The OAuth state recovery mechanism (`oauth_recovery=true`) allows one-time recovery of OAuth state if session is lost

### 6.4 Cache Headers
| Strategy | Cache Control | Usage |
|----------|--------------|-------|
| CacheNone | `no-store` | No caching, for dynamic data |
| CacheShort | `public, max-age=1, stale-while-revalidate=9` | Short-lived cache |
| CacheLong | `public, max-age=3600, stale-while-revalidate=82800` | Long-lived (1h) |
| CacheDefault | `public, max-age=1, stale-while-revalidate=86399` | Default (1s + 23h stale) |
| CacheCustom | User-defined | Custom cache strategies |

---

## 7. .env Example / Environment Handling

### 7.1 Local Dev
```
# templates/skeleton/.env
SESSION_SECRET="foobar"  ← INSECURE DEFAULT
```

### 7.2 E2E Test Envs
- `e2e/envs/.env.mockShop` — mock.shop test environment
- `e2e/envs/.env.hydrogenPreviewStorefront` — preview storefront
- `e2e/envs/.env.customerAccount` — Customer Account API test
- `e2e/envs/.env.defaultConsentAllowed_cookiesDisabled`
- `e2e/envs/.env.defaultConsentDisallowed_cookiesDisabled`
- `e2e/envs/.env.defaultConsentAllowed_cookiesEnabled`
- `e2e/envs/.env.defaultConsentDisallowed_cookiesEnabled`

### 7.3 Production Env (Oxygen Worker)
```typescript
interface HydrogenEnv {
  SESSION_SECRET: string;          // Required, throws if missing
  PUBLIC_STOREFRONT_API_TOKEN: string;
  PRIVATE_STOREFRONT_API_TOKEN: string;
  PUBLIC_STORE_DOMAIN: string;
  PUBLIC_STOREFRONT_ID: string;
  PUBLIC_CUSTOMER_ACCOUNT_API_CLIENT_ID: string;
  PUBLIC_CUSTOMER_ACCOUNT_API_URL: string;
  PUBLIC_CHECKOUT_DOMAIN: string;
  SHOP_ID: string;
}
```

---

## 8. Test Files

| Test Directory | File Count | Purpose |
|----------------|-----------|---------|
| `packages/hydrogen/src/**.test.ts` | 30+ | Unit tests |
| `packages/hydrogen-react/src/**.test.tsx` | 20+ | React component tests |
| `packages/cli/src/**/*.test.ts` | 30+ | CLI command tests |
| `packages/mini-oxygen/src/**/*.test.ts` | 15+ | Mini-oxygen runtime tests |
| `cookbook/src/**/*.test.ts` | 8+ | Recipe system tests |
| `e2e/specs/` | 30+ | Playwright e2e tests |
| `e2e/specs/recipes/` | 10+ | Recipe e2e tests |
| `e2e/specs/skeleton/` | 6 | Skeleton app tests |
| `e2e/specs/new-cookies/` | 5 | New cookie consent tracking |
| `e2e/specs/old-cookies/` | 4 | Legacy cookie tests |
| `e2e/specs/smoke/` | 4 | Smoke tests |
| `e2e/specs/recipes/multipass.spec.ts` | 1 | Multipass flow tests |
