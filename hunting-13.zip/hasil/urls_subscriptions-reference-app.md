# URL Extraction — subscriptions-reference-app

## Route Endpoints (App Routes)

### Webhook Endpoints (POST)
| Route | Topic(s) | Description | Job Enqueued |
|-------|----------|-------------|--------------|
| `/webhooks/app/uninstalled` | APP_UNINSTALLED | App uninstalled | `DisableShopJob` |
| `/webhooks/cli` | APP_UNINSTALLED + fallback | CLI dev webhook catch-all | `DisableShopJob` (for APP_UNINSTALLED) |
| `/webhooks/customer_redact` | CUSTOMERS_DATA_REQUEST, CUSTOMERS_REDACT | GDPR customer data redaction | None (returns 200) |
| `/webhooks/shop_redact` | SHOP_REDACT | GDPR shop data redaction | `DeleteBillingScheduleJob` |
| `/webhooks/subscription_contracts/create` | SUBSCRIPTION_CONTRACTS_CREATE | Contract created | `CustomerSendEmailJob` + `TagSubscriptionOrderJob` |
| `/webhooks/subscription_contracts/activate` | SUBSCRIPTION_CONTRACTS_ACTIVATE | Contract activated | None (logs only) |
| `/webhooks/subscription_contracts/cancel` | SUBSCRIPTION_CONTRACTS_CANCEL | Contract cancelled | `CustomerSendEmailJob` + `MerchantSendEmailJob` |
| `/webhooks/subscription_contracts/pause` | SUBSCRIPTION_CONTRACTS_PAUSE | Contract paused | None (logs only) |
| `/webhooks/subscription_billing_cycles/skip` | SUBSCRIPTION_BILLING_CYCLES_SKIP | Billing cycle skipped | `CustomerSendEmailJob` |
| `/webhooks/subscription_billing_attempts/success` | SUBSCRIPTION_BILLING_ATTEMPTS_SUCCESS | Billing attempt succeeded | `DunningStopJob` + `TagSubscriptionOrderJob` |
| `/webhooks/subscription_billing_attempts/failure` | SUBSCRIPTION_BILLING_ATTEMPTS_FAILURE | Billing attempt failed | `DunningStartJob` |
| `/webhooks/selling_plan_groups/create_or_update` | SELLING_PLAN_GROUPS_CREATE, SELLING_PLAN_GROUPS_UPDATE | Plan group created/updated | `CreateSellingPlanTranslationsJob` |

### Internal/Admin Endpoints
| Route | Method | Description | Auth |
|-------|--------|-------------|------|
| `/internal/jobs/run` | POST | Execute a job by name+parameters | **NONE** (no auth!) |

### Authenticated App Routes (via `authenticate.admin`)
| Route | Method | Description |
|-------|--------|-------------|
| `/app` | GET | App layout wrapper |
| `/app/_index` | GET | Contracts list page |
| `/app/contracts/$id` | GET | Contract detail page |
| `/app/contracts/$id/bill-contract` | POST | Bill contract |
| `/app/contracts/$id/cancel` | POST | Cancel contract |
| `/app/contracts/$id/pause` | POST | Pause contract |
| `/app/contracts/$id/resume` | POST | Resume contract |
| `/app/contracts/$id/payment-update` | POST | Send payment method update email |
| `/app/contracts/$id/address-update` | POST | Update delivery address (via SubscriptionContractDraft) |
| `/app/contracts/$id/poll-bill-attempt` | POST | Poll billing attempt status |
| `/app/contracts/bulk-operation` | POST | Bulk pause/activate/cancel contracts |
| `/app/plans` | GET | Selling plans list |
| `/app/plans/$id` | GET, POST | Plan create/edit |
| `/app/plans/$id/delete` | POST | Delete plan |
| `/app/settings` | GET, POST | Billing failure settings |

### Other Endpoints
| Route | Method | Description | Auth |
|-------|--------|-------------|------|
| `/auth/$` | * | Shopify OAuth flow | Shopify SDK |
| `/auth/login` | GET | Login page | Public |
| `/customerAccount/emails` | GET, POST | Customer account email endpoint (pause/resume) | Session token verified |
| `/services/ping` | GET | Health check (DB connection) | Public |
| `/maintenance` | GET | Maintenance page (503) | Public |
| `/missing-scopes` | GET | Missing scopes warning page | Dev only |

## External URLs & Domains

### App & Redirects
- `https://example.com` — Application URL (shopify.app.toml)
- `https://example.com/api/auth/callback` — Auth callback
- `https://example.com/auth/callback` — Auth callback
- `https://example.com/auth/shopify/callback` — Auth callback

### CDN & Assets
- `https://cdn.shopify.com` — Polaris CSS styles

### Shopify Services
- `https://atlas.shopifysvc.com` — CSP connect-src (error reporting)
- `https://extensions.shopifycdn.com` — CSP connect-src (extensions)

### Test References
- `https://shopify-subscriptions-app.com` — Test reference URL
- `https://app.com` — Test mock URL

### Documentation & Specs
- `https://shopify.dev/docs/apps/build/purchase-options/subscriptions` — Subscriptions docs
- `https://shopify.dev/docs/api/admin-graphql` — Admin GraphQL API
- `https://shopify.dev/docs/api/admin-graphql/2024-04/queries/sellingPlanGroups` — Selling Plans API
- `https://shopify.dev/docs/api/admin-graphql/2024-04/queries/subscriptionContracts` — Subscription Contracts API
- `https://shopify.dev/docs/apps/build/purchase-options/subscriptions/subscriptions-app/core-system-components` — Core building blocks
- `https://shopify.dev/docs/apps/build/purchase-options/subscriptions/subscriptions-app/start-building` — Getting started
- `https://shopify.dev/docs/apps/build/purchase-options/subscriptions/subscriptions-app#uniqueness-from-other-apps` — Uniqueness requirement
- `https://shopify.dev/docs/apps/tools/cli/configuration` — CLI config
- `https://shopify.dev/docs/apps/tools/cli/configuration#access_scopes` — Access scopes
- `https://shopify.dev/docs/apps/auth` — App authentication
- `https://shopify.dev/docs/apps/app-extensions/list` — App extensions
- `https://shopify.dev/docs/apps/getting-started` — Getting started
- `https://shopify.dev/docs/apps/deployment/web` — Deployment
- `https://apps.shopify.com/shopify-subscriptions` — Shopify Subscriptions app store
- `https://help.shopify.com/` — Help docs

### Other Documentation
- `https://remix.run/docs/en/main` — Remix framework docs
- `https://reactrouter.com/` — React Router docs

## GraphQL Endpoints
- Admin GraphQL API via `@shopify/shopify-app-remix` SDK (`admin.graphql`)
- REST API resources via `@shopify/shopify-api` (`restResources`)
- API version: `Unstable`

## Google Cloud Integration
- Google Cloud Tasks API (`@google-cloud/tasks`) — Production job scheduler
  - `CloudTaskScheduler` enqueues jobs to a Cloud Tasks queue
  - Callback URL receives POST with base64-encoded JSON job payload
  - OIDC token authentication with service account email

## Database
- PostgreSQL (prisma) — production
- SQLite (`file:dev.sqlite`) — development/testing
- Tables: Session, BillingSchedule, DunningTracker
