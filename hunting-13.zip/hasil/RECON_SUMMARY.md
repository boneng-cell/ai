# Technical Recon Summary — Shopify Repos

## Repo 1: shop-chat-agent

### a) File Tree
Saved to: `/home/runner/work/hunting-13/hunting-13/hasil/trees/shop-chat-agent.txt` (77 files)
Raw API response: `/home/runner/work/hunting-13/hunting-13/hasil/trees/shop-chat-agent.html`

**Key files:**
- `app/entry.server.jsx` — SSR entry
- `app/shopify.server.js` — Shopify OAuth config (`@shopify/shopify-app-react-router`)
- `app/routes/chat.jsx` — **SSE chat endpoint** (`/chat`)
- `app/routes/auth.callback.jsx` — Customer OAuth2 PKCE callback
- `app/routes/auth.token-status.jsx` — Token status polling (CORS-enabled)
- `app/routes/api.webhooks.jsx` — Webhook handler (APP_UNINSTALLED)
- `app/db.server.js` — Prisma client + DB operations (6 models)
- `app/mcp-client.js` — MCP JSON-RPC client
- `app/services/* — Claude, Tool, Config, Streaming services
- `prisma/schema.prisma` — SQLite via Prisma

### b) Architecture Map
- **Entry**: `app/entry.server.jsx` (SSR) → `app/routes.js` (flatRoutes)
- **Routes**: 5 app routes + 3 auth routes + 1 webhook route
- **Middleware**: Shopify SDK middleware (OAuth, webhook HMAC, admin auth)
- **Service Layer**: `app/services/` (claude, tool, config, streaming)
- **DB Layer**: `app/db.server.js` (Prisma + SQLite)
- **MCP Client**: `app/mcp-client.js` (JSON-RPC 2.0 to two MCP servers)
- **Env**: `.env.example` (CLAUDE_API_KEY, REDIRECT_URL, SHOPIFY_API_KEY)
- **Tests**: No test files found in the repo

### c) URLs Extracted
Saved to: `/home/runner/work/hunting-13/hunting-13/hasil/urls_shop-chat-agent.md`

**Critical endpoints:**
- `GET/POST /chat` — SSE streaming chat with Claude + MCP tools
- `GET /chat?history=true&conversation_id=XYZ` — Conversation history
- `GET /auth/callback` — Customer OAuth2 callback (PKCE)
- `GET /auth/token-status?conversation_id=XYZ` — Token status check (CORS-enabled)
- `POST /api/webhooks` — Webhook handler

**External URLs:**
- `https://shop-chat-agent.com` — App URL
- `https://shop-chat-agent.com/callback` — Customer auth redirect
- `https://*.myshopify.com/.well-known/customer-account-api` — MCP API discovery
- `https://*.myshopify.com/.well-known/openid-configuration` — OIDC config
- `https://api.anthropic.com` — Claude API

### d) Dependency Versions + CVE
- `@anthropic-ai/sdk`: 0.40.1 → CVE-2026-41686 (medium: insecure file permissions)
- `react-router`: 7.11.0 → CVE-2026-42211 (high: RCE via deserialization)
- `@shopify/shopify-app-react-router`: 1.1.0 → No known CVEs
- `@prisma/client`: 6.19.1 → No known CVEs
- `isbot`: 5.1.27 → No known CVEs

### e) Architecture Summary
- **Stack**: React Router 7 + Claude API + Prisma/SQLite
- **Endpoint**: `/chat` (SSE stream with Claude), `/auth/callback` (PKCE), `/auth/token-status` (CORS)
- **Auth Model**: Shop OAuth (SDK) + Customer PKCE OAuth2 + Webhook HMAC
- **Data Flow**: Client → `/chat` → parse Origin header → fetch `.well-known/*` (SSRF risk) → init MCP client → connect to storefront+customer MCP → stream Claude response via SSE

### Focused Findings — shop-chat-agent
**File**: `/home/runner/work/hunting-13/hunting-13/hasil/security_findings_shop-chat-agent.md`

Key vulnerabilities:
1. **SSRF via Origin header** (chat.jsx:88) — `request.headers.get("Origin")` used as shopDomain → fetches `.well-known/*` from arbitrary domains
2. **CORS reflection** (chat.jsx:155) — `Access-Control-Allow-Origin: origin` reflects any origin + `Allow-Credentials: true`
3. **Unvalidated conversationId** — `body.conversation_id || Date.now().toString()` — no ownership check
4. **PKCE state parsing vulnerability** — `state.split("-")` — conversationId with hyphens breaks parsing
5. **Empty API secret** — `apiSecretKey: process.env.SHOPIFY_API_SECRET || ""` — empty string fallback
6. **Empty Authorization header** — `Authorization: this.customerAccessToken || ""` — empty string auth header
7. **Missing SHOPIFY_API_SECRET** in `.env.example`

---

## Repo 2: subscriptions-reference-app

### a) File Tree
Saved to: `/home/runner/work/hunting-13/hunting-13/hasil/trees/subscriptions-reference-app.txt` (1338 files)
Raw API response: `/home/runner/work/hunting-13/hunting-13/hasil/trees/subscriptions-reference-app.html`

**Key files:**
- `app/entry.server.tsx` — SSR entry (i18n, CSP headers)
- `app/shopify.server.ts` — Shopify OAuth config (`@shopify/shopify-app-remix`, ApiVersion.Unstable)
- `app/routes/internal.jobs.run.tsx` — **UNAUTHENTICATED job execution endpoint**
- `app/routes/webhooks.*.tsx` — 12 webhook handlers (all HMAC-verified)
- `app/db.server.ts` — Prisma client (PostgreSQL/SQLite)
- `app/lib/jobs/` — Custom Job framework (Job, JobRunner, Scheduler, InlineScheduler, CloudTaskScheduler, TestScheduler)
- `app/models/` — SubscriptionContract, SubscriptionContractDraft, BillingSchedule, DunningTracker, Settings, ShopInfo, SubscriptionBillingAttempt, SellingPlan, Translations
- `app/services/` — 18 service files (Dunning, Inventory, Email, Billing services)
- `app/graphql/` — 60+ GraphQL operations
- `config/index.ts` + `config/types.ts` — App configuration

### b) Architecture Map
- **Entry**: `app/entry.server.tsx` (SSR + i18n + security headers)
- **Routes**: `app/routes.ts` (flatRoutes) → 30+ routes
- **Middleware**: Shopify SDK (`authenticate.admin`, `authenticate.webhook`)
- **Service Layer**: `app/services/` (18 services) + `app/models/` (7 models)
- **Job Framework**: `app/lib/jobs/` — Job base class, JobRunner, 3 schedulers
- **DB Layer**: `app/db.server.ts` (Prisma)
- **Env**: `config/index.ts` — environment-based config (InlineScheduler always in prod/dev, CloudTasks never used)
- **Tests**: Vitest — 30+ test files with fixtures

### c) URLs Extracted
Saved to: `/home/runner/work/hunting-13/hunting-13/hasil/urls_subscriptions-reference-app.md`

**Critical endpoints:**
- `POST /internal/jobs/run` — **No auth!** Executes registered jobs by name+parameters
- `GET /services/ping` — Health check
- `POST /webhooks/*` — 11 webhook handlers (all HMAC-verified via `authenticate.webhook`)
- `GET/POST /customerAccount/emails` — Customer account endpoint (session token auth)
- `POST /app/contracts/bulk-operation` — Bulk contract operations

**External URLs:**
- `https://example.com` — App URL (placeholder)
- `https://atlas.shopifysvc.com` — CSP connect-src (error reporting)
- `https://extensions.shopifycdn.com` — CSP connect-src
- `https://cdn.shopify.com` — Polaris styles
- Google Cloud Tasks API (for CloudTaskScheduler — not enabled in config)

### d) Dependency Versions + CVE
- `@shopify/shopify-app-remix`: 3.8.3 → No known CVEs
- `@shopify/shopify-api`: 11.13.0 → No known CVEs
- `@shopify/polaris`: 13.9.5 → No known CVEs
- `remix`: 2.16.8 → No known CVEs
- `zod`: 3.25.67 → CVE-2023-4316 (medium: DoS) — need to verify patched
- `prisma`: 6.10.1 → No known CVEs

### e) Architecture Summary
- **Stack**: Remix 2 + Shopify API SDK + Prisma + Polaris + Google Cloud Tasks
- **Endpoint**: `/internal/jobs/run` (critical), `/webhooks/*` (11 topics), `/app/*` (admin routes)
- **Auth Model**: Admin OAuth (SDK) + Webhook HMAC + Customer session token (customerAccount.emails)
- **Data Flow**: Webhook → enqueue job → (InlineScheduler in prod) → execute job → Shopify Admin GraphQL API

### Focused Findings — subscriptions-reference-app
**File**: `/home/runner/work/hunting-13/hunting-13/hasil/security_findings_subscriptions-reference-app.md`

Key vulnerabilities:
1. **CRITICAL: Unauthenticated job execution** (`internal.jobs.run.tsx:24`) — `/internal/jobs/run` accepts POST with `{jobName, parameters}` and executes ANY registered job. No auth, no HMAC, no rate limiting. Impact: fraudulent billing, contract cancellation, email phishing, bulk operations.
2. **CloudTaskScheduler OIDC not verified** — In production, the InlineScheduler is always used (config.ts: `isProduction → 'INLINE'`). Cloud Tasks OIDC tokens are never verified.
3. **`unauthenticated.admin()` usage** — Jobs use `unauthenticated.admin(shop)` without checking if the shop is still an active subscriber.
4. **`appGID` filtering in CreateSellingPlanTranslationsJob** — Only checks `appGid !== env.appGID` — if `APP_GID` is unset, all events are processed.
5. **`webhooks.cli.tsx` catch-all** — Only handles APP_UNINSTALLED, silently ignores other topics. Could be a production webhook path (shopify.web.toml: `webhooks_path = "/webhooks/cli"`).
6. **Dynamic import path injection** (`app.routes/app/route.tsx:50`) — `import(\`../../../node_modules/@shopify/polaris/locales/${lng}.json\`)` — if `lng` is user-controlled, path traversal is possible. The `lng` comes from `i18nextServer.getLocale(request)`.

## Output Files
All results saved to: `/home/runner/work/hunting-13/hunting-13/hasil/`
- `trees/shop-chat-agent.txt` + `.html` (raw)
- `trees/subscriptions-reference-app.txt` + `.html` (raw)
- `urls_shop-chat-agent.md`
- `urls_subscriptions-reference-app.md`
- `architecture_shop-chat-agent.md`
- `architecture_subscriptions-reference-app.md`
- `dependency_versions_and_cve.md`
- `security_findings_shop-chat-agent.md`
- `security_findings_subscriptions-reference-app.md`
- 60+ raw source files fetched from GitHub
