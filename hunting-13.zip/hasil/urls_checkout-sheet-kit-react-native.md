# URL / Domain / Endpoint Extraction — checkout-sheet-kit-react-native

## Version
- NPM package `@shopify/checkout-sheet-kit`: **4.0.0**
- Podspec version: `4.0.0`
- Native iOS dependency: `ShopifyCheckoutSheetKit ~> 3.8.0` (CocoaPods)
- RN minimum: 0.76 (New Architecture / TurboModules required)
- iOS minimum: 13.0 | Android minimum: SDK 23

## Dependencies (from `modules/@shopify/checkout-sheet-kit/package.json`)
| Package | Type | Version |
|---------|------|---------|
| `react` | peerDependency | `*` (any) |
| `react-native` | peerDependency | `*` (any) |
| `react-native-builder-bob` | devDependency | `^0.23.2` |
| `typescript` | devDependency | `^5.9.2` |

### Native Dependencies
**iOS (podspec):** `React-Core`, `ShopifyCheckoutSheetKit ~> 3.8.0`, `ShopifyCheckoutSheetKit/AcceleratedCheckouts ~> 3.8.0`

**Android:** Depends on native `com.shopify.checkoutsheetkit` module (compiled AAR via JSI/TurboModule)

### Root `sample/package.json` key deps (partial scan)
- `@apollo/client` — GraphQL client
- `@shopify/checkout-sheet-kit` — the library itself
- `react-native-encrypted-storage` — encrypted token storage
- `react-native-quick-crypto` — crypto (PKCE)
- `react-native-config` — env var loading
- `react-native-vector-icons`
- `@react-navigation/native`, `@react-navigation/bottom-tabs`, `@react-navigation/native-stack`

## All Endpoints & Domains

### OAuth / Auth Endpoints
| URL / Pattern | File:Line | Description |
|---------------|-----------|-------------|
| `https://shopify.com/authentication/{shopId}/oauth/authorize` | `sample/src/auth/customerAccountManager.ts:99` | Customer Account API authorization endpoint |
| `https://shopify.com/authentication/{shopId}/oauth/token` | `sample/src/auth/customerAccountManager.ts:103` | Token exchange endpoint |
| `https://shopify.com/authentication/{shopId}/logout` | `sample/src/auth/customerAccountManager.ts:106` | Logout endpoint |
| `shop.{shopId}.app://callback` | `sample/src/auth/customerAccountManager.ts:60` | **Custom URL scheme** redirect URI (deep link) |
| `shop.{shopId}.app` | `sample/src/auth/customerAccountManager.ts:63` | **Custom URL scheme** for app link handling |

### Storefront API Endpoints
| URL / Pattern | File:Line | Description |
|---------------|-----------|-------------|
| `https://{STOREFRONT_DOMAIN}/api/{STOREFRONT_VERSION}/graphql.json` | `sample/src/App.tsx:135` | Storefront GraphQL API endpoint |
| `X-Shopify-Storefront-Access-Token` header | `sample/src/App.tsx:138` | Storefront access token header |

### Checkout / Storefront URLs
| URL / Pattern | File:Line | Description |
|---------------|-----------|-------------|
| Checkout URL (string param) → `CheckoutViewController(checkout: url, ...)` | `modules/.../ios/ShopifyCheckoutSheetKit.swift:173` | Native `present(_ checkoutURL: String)` |
| Checkout URL (string param) → `ShopifyCheckoutSheetKit.preload(checkout: url)` | `modules/.../ios/ShopifyCheckoutSheetKit.swift:182` | Native `preload(_ checkoutURL: String)` |
| `{checkoutUrl}.payment=shop_pay` (query param appended) | `Sources/ShopifyAcceleratedCheckouts/Wallets/ShopPay/ShopPayViewController.swift:48` | Shop Pay payment query param |
| `https://{storefrontDomain}/api/{apiVersion}/graphql.json` | `Sources/ShopifyAcceleratedCheckouts/Internal/StorefrontAPI/StorefrontAPI.swift:31` | Storefront API for AcceleratedCheckouts (Swift native) |
| `X-Shopify-Storefront-Access-Token` header | `StorefrontAPI.swift:33` | Storefront access token for cart operations |

### Android Deep Links / Intent Filters
| URL | File | Description |
|-----|------|-------------|
| `https://{STOREFRONT_DOMAIN}` (intent-filter DATA) | `sample/android/app/src/main/AndroidManifest.template.xml` | App Linking (Android) — host replaced from env |

### iOS Custom URL Schemes (from Info.plist)
| Scheme | File | Description |
|--------|------|-------------|
| `rn` | `sample/ios/ReactNative/Info.plist` (`CFBundleURLSchemes`) | Custom URL scheme for the sample app |
| `rn` | `LSApplicationQueriesSchemes` | Query scheme for cross-app linking |

### WebView Configuration & Navigation
| URL | File:Line | Description |
|-----|-----------|-------------|
| `open_externally` query param | `Sources/ShopifyCheckoutSheetKit/CheckoutWebView.swift:340` | iOS WebView intercepts `open_externally=true/1` to open externally |
| `multipass` substring check | `Sources/ShopifyCheckoutSheetKit/CheckoutURL.swift:18` | Detects multipass URLs |
| `order_id` query param | `Sources/ShopifyCheckoutSheetKit/CheckoutWebView.swift:402` | Extracts order ID from confirmation URL |
| `thank[_-]you` regex | `Sources/ShopifyCheckoutSheetKit/CheckoutURL.swift:21` | Detects thank-you page |

### Domains Used Throughout Codebase
| Domain | File:Line | Description |
|--------|-----------|-------------|
| `myshopify.com` | `sample/.env.example` | Storefront domain suffix |
| `shopify.com` | `sample/src/auth/customerAccountManager.ts:99-106` | Customer Account API auth endpoints |
| `developers.shopify.com` | `sample/src/auth/customerAccountManager.ts` | Customer Account API docs reference |

### Documentation / Config URLs
| URL | File |
|-----|------|
| `https://github.com/Shopify/checkout-sheet-kit-react-native` | README.md |
| `https://www.shopify.com/partners/blog/mobile-checkout-sdks-for-ios-and-android` | README.md |
| `https://shopify.dev/docs/custom-storefronts/mobile-kit` | README.md |
| `https://shopify.dev/docs/api/storefront` | README.md |
| `https://shopify.dev/docs/api/storefront/2023-10/objects/Cart#field-cart-checkouturl` | README.md |
| `https://help.shopify.com/en/manual/products/details/cart-permalink` | README.md |
| `https://shopify.dev/docs/apps/build/graphql/migrate/new-product-model` | README.md |
| `https://developer.apple.com/documentation/passkit_apple_pay_and-wallet/pkpaymentrequest/1619305-merchantidentifier` | ApplePayConfiguration.swift |
| `https://shopify.dev/docs/storefronts/themes/getting-started/build-a-theme#get-the-shop-domain` | Configuration.swift |
| `https://shopify.dev/docs/storefronts/themes/getting-started/build-a-theme#get-the-storefront-access-token` | Configuration.swift |
| `https://shopify.dev/docs/api/storefront/latest/mutations/cartBuyerIdentityUpdate` | Configuration.swift |

## Auth-Related File Map (RN)

| File | Purpose |
|------|---------|
| `sample/src/auth/customerAccountManager.ts` | **OAuth 2.1 + PKCE**: `buildAuthorizationURL()`, `handleAuthCallback()`, `exchangeCodeForTokens()`, `refreshAccessToken()`, `logout()` |
| `sample/src/auth/pkce.ts` | PKCE code verifier/challenge generation using `react-native-quick-crypto` |
| `sample/src/auth/tokenStorage.ts` | Encrypted storage of tokens via `react-native-encrypted-storage` |
| `sample/src/auth/types.ts` | `BuyerIdentityMode`, `OAuthTokenResult` types |
| `sample/src/context/Auth.tsx` | React context wrapper around `customerAccountManager` |
| `sample/src/App.tsx` | **Deep link handling**: `useInitialURL()`, `Linking.getInitialURL()`, universal link routing (`isCheckout()`, `isCart()`, `isThankYouPage()`) |
| `sample/ios/ReactNative/Info.plist` | Custom URL scheme registration (`CFBundleURLSchemes`) |
| `sample/ios/ReactNative/AppDelegate.swift` | `UIApplicationDelegate` — note: **no** `continue userActivity` / `application:openURL:options:` override present (deep link handling via `Linking` in JS layer) |
| `sample/android/app/src/main/AndroidManifest.template.xml` | Android App Linking intent filter for `https://{STOREFRONT_DOMAIN}` |
| `documentation/universal_links_ios.md` | iOS Universal Links setup guide |
| `modules/@shopify/checkout-sheet-kit/src/context.tsx` | `ShopifyCheckoutSheetProvider` context |
| `modules/@shopify/checkout-sheet-kit/src/index.ts` | Core SDK entry — `present()`, `preload()`, `dismiss()`, `configureAcceleratedCheckouts()` |
| `modules/@shopify/checkout-sheet-kit/src/specs/NativeShopifyCheckoutSheetKit.ts` | TurboModule spec definition |
| `modules/@shopify/checkout-sheet-kit/ios/ShopifyCheckoutSheetKit.swift` | iOS native bridge (Obj-C + Swift) |
| `modules/@shopify/checkout-sheet-kit/ios/ShopifyCheckoutSheetKit.mm` | Obj-C TurboModule registration |
| `modules/@shopify/checkout-sheet-kit/android/src/main/AndroidManifest.xml` | Android native module manifest (empty — no intent filters in SDK) |
| `modules/@shopify/checkout-sheet-kit/android/src/main/java/com/shopify/reactnative/checkoutsheetkit/ShopifyCheckoutSheetKitModule.java` | Android native module (Java) |
| `modules/@shopify/checkout-sheet-kit/tests/linking.test.ts` | Tests native module linking |
| `__mocks__/react-native-config.ts` | Mock env config for tests |
| `__mocks__/react-native-encrypted-storage.ts` | Mock encrypted storage for tests |
| `__mocks__/react-native-quick-crypto.ts` | Mock crypto for tests |
| `__mocks__/react-native.ts` | Mock React Native for tests |
