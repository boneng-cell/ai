# Architecture Summary — subscriptions-reference-app

## Stack
| Layer | Technology |
|-------|-----------|
| Framework | Remix (v2.16.8) + `@remix-run/serve` |
| Shopify SDK | `@shopify/shopify-app-remix` (v3.8.3) |
| Shopify API | `@shopify/shopify-api` (v11.13.0) |
| Session Storage | `@shopify/shopify-app-session-storage-prisma` (v6.0.7) |
| Database | Prisma (v6.10.1) + PostgreSQL (production) / SQLite (dev) |
| GraphQL | `graphql` (v16.11.0) + `@shopify/admin-graphql-api-utilities` |
| UI | React (v18.3.1) + Polaris (v13.9.5) + Remix i18n |
| Extensions | Shopify UI Extensions (v2025.7.0) — buyer-subscriptions, admin-subs-action |
| Job Queue | Custom Job framework (in-memory Inline/InProcess, Google Cloud Tasks in prod) |
| Testing | Vitest (v3.2.4) + `@shopify/react-testing` + MSW |
| Forms/Validation | `@rvf/remix` (v7.1.5) + Zod (v3.25.67) |

## Entry Points
- `package.json` scripts:
  - `dev`: `dotenv -c development pnpm shopify app dev`
  - `start`: `remix-serve ./build/server/index.js`
  - `setup`: `prisma generate && prisma migrate deploy`
  - `test`: `LC_ALL=en_US.UTF-8 TZ=UTC dotenv -c test vitest`
  - `type-check`: `tsc --project tsconfig.json && tsc --project extensions/*/tsconfig.json`
- `app/entry.server.tsx` — SSR entry (i18n, CSP headers, 5s timeout)
- `app/shopify.server.ts` — Shopify app config:
  - `apiVersion: ApiVersion.Unstable`
  - `authPathPrefix: '/auth'`
  - `distribution: AppDistribution.AppStore`
  - `scopes: process.env.SCOPES?.split(',')`
  - AfterAuth hook → `AfterAuthService` (creates billing schedule + settings metaobject)
- `shopify.web.toml` — `roles = ["frontend", "backend"]`, `webhooks_path = "/webhooks/cli"`

## Route Map

### Webhook Routes (`/webhooks/*`)
| File | Webhook Topic | Action |
|------|---------------|--------|
| `app/routes/webhooks.app.uninstalled.tsx` | APP_UNINSTALLED | Enqueue `DisableShopJob` |
| `app/routes/webhooks.cli.tsx` | CLI catch-all | Only handles APP_UNINSTALLED, logs others |
| `app/routes/webhooks.customer_redact.ts` | CUSTOMERS_DATA_REQUEST, CUSTOMERS_REDACT | Return 200 (no data stored) |
| `app/routes/webhooks.shop_redact.ts` | SHOP_REDACT | Enqueue `DeleteBillingScheduleJob` |
| `app/routes/webhooks.subscription_contracts.create.tsx` | SUBSCRIPTION_CONTRACTS_CREATE | Enqueue `CustomerSendEmailJob` + `TagSubscriptionOrderJob` |
| `app/routes/webhooks.subscription_contracts.activate.tsx` | SUBSCRIPTION_CONTRACTS_ACTIVATE | Log only |
| `app/routes/webhooks.subscription_contracts.cancel.tsx` | SUBSCRIPTION_CONTRACTS_CANCEL | Enqueue `CustomerSendEmailJob` + `MerchantSendEmailJob` |
| `app/routes/webhooks.subscription_contracts.pause.tsx` | SUBSCRIPTION_CONTRACTS_PAUSE | Log only |
| `app/routes/webhooks.subscription_billing_cycles.skip.tsx` | SUBSCRIPTION_BILLING_CYCLES_SKIP | Enqueue `CustomerSendEmailJob` |
| `app/routes/webhooks.subscription_billing_attempts.success.tsx` | SUBSCRIPTION_BILLING_ATTEMPTS_SUCCESS | Enqueue `DunningStopJob` + `TagSubscriptionOrderJob` |
| `app/routes/webhooks.subscription_billing_attempts.failure.tsx` | SUBSCRIPTION_BILLING_ATTEMPTS_FAILURE | Enqueue `DunningStartJob` |
| `app/routes/webhooks.selling_plan_groups.create_or_update.tsx` | SELLING_PLAN_GROUPS_CREATE/UPDATE | Enqueue `CreateSellingPlanTranslationsJob` |

### Internal Routes
| File | Route | Description |
|------|-------|-------------|
| `app/routes/internal.jobs.run.tsx` | `/internal/jobs/run` | **Unauthenticated job execution endpoint** |
| `app/routes/services.ping.tsx` | `/services/ping` | Health check (DB connection test) |
| `app/routes/maintenance._index/route.tsx` | `/maintenance` | Maintenance page (always 503) |
| `app/routes/missing-scopes._index/route.tsx` | `/missing-scopes` | Dev-only missing scopes warning |
| `app/routes/customerAccount.emails.ts` | `/customerAccount/emails` | Customer pause/resume email endpoint (session token auth) |

### Admin App Routes (`/app/*`)
| File | Route | Description |
|------|-------|-------------|
| `app/routes/app/route.tsx` | `/app` | App layout (Polaris, NavMenu, i18n) |
| `app/routes/app._index/route.tsx` | `/app` | Contracts list (paginated table) |
| `app/routes/app.contracts.$id._index/route.tsx` | `/app/contracts/$id` | Contract detail page |
| `app/routes/app.contracts.$id.bill-contract/route.ts` | `.../bill-contract` | POST — Bill contract (manual charge) |
| `app/routes/app.contracts.$id.cancel/route.ts` | `.../cancel` | POST — Cancel contract |
| `app/routes/app.contracts.$id.pause/route.ts` | `.../pause` | POST — Pause contract |
| `app/routes/app.contracts.$id.resume/route.ts` | `.../resume` | POST — Resume contract |
| `app/routes/app.contracts.$id.payment-update/route.ts` | `.../payment-update` | POST — Send payment method update email |
| `app/routes/app.contracts.$id.address-update/route.ts` | `.../address-update` | POST — Update delivery address via SubscriptionContractDraft |
| `app/routes/app.contracts.$id.poll-bill-attempt/route.ts` | `.../poll-bill-attempt` | POST — Poll billing attempt readiness |
| `app/routes/app.contracts.bulk-operation.ts` | `.../bulk-operation` | POST — Bulk pause/activate/cancel via bulk mutations |
| `app/routes/app.plans._index/route.tsx` | `/app/plans` | Selling plans list |
| `app/routes/app.plans.$id/route.tsx` | `/app/plans/$id` | Plan create/edit form |
| `app/routes/app.plans.$id.delete/route.tsx` | `.../delete` | POST — Delete selling plan |
| `app/routes/app.settings._index/route.tsx` | `/app/settings` | Billing failure settings (metaobject) |

### Auth Routes
| File | Route | Description |
|------|-------|-------------|
| `app/routes/auth.$.jsx` | `/auth/*` | Shopify OAuth (SDK-handled) |
| `app/routes/auth.login/route.tsx` | `/auth/login` | Login page |

## Auth Model
1. **Admin Auth**: Shopify OAuth via `@shopify/shopify-app-remix` SDK
   - `authenticate.admin(request)` on all `/app/*` routes
   - `authenticate.webhook(request)` on all `/webhooks/*` routes — **HMAC verification**

2. **Webhook HMAC Verification**: 
   - All webhook handlers call `authenticate.webhook(request)` which:
     - Verifies HMAC-SHA256 signature (`X-Shopify-Hmac-Sha256` header)
     - Validates Shopify shop domain
     - Checks for required headers (topic, webhook ID, etc.)
   - Uses `apiVersion: "unstable"` for webhook API

3. **Customer Account Auth** (`/customerAccount/emails`):
   - Uses `authenticate.public.customerAccount(request)` — session token verification
   - Extracts `sub` (customer GID) and `dest` (shop domain) from session token

## Data Flow: Job Execution (`/internal/jobs/run`)

```
External Request (NO AUTH)
  → POST /internal/jobs/run
    → jobs.execute(request)
      → Parse JSON: { jobName, parameters }
      → addShopToContext(request, context) — extract shop from parameters
      → registry.get(jobName) — lookup job class by name
      → Reflect.construct(JobClass, [parameters])
      → instance.run()
        → perform() — execute job logic
        → isTerminal(error) — decide retry or stop
```

### Available Jobs (Registry)
| Job Class | Queue | Purpose |
|-----------|-------|---------|
| `ChargeBillingCyclesJob` | billing | Charge all billable billing cycles |
| `RebillSubscriptionJob` | rebilling | Charge a specific subscription contract |
| `RecurringBillingChargeJob` | — | Scheduler — triggers ScheduleShopsToChargeBillingCyclesJob |
| `ScheduleShopsToChargeBillingCyclesJob` | billing | Schedule shops for billing based on timezone |
| `DunningStartJob` | webhooks | Handle billing attempt failure |
| `DunningStopJob` | webhooks | Stop dunning on billing attempt success |
| `DisableShopJob` | webhooks | Disable shop on uninstall |
| `DeleteBillingScheduleJob` | webhooks | Delete billing schedule on shop redact |
| `CustomerSendEmailJob` | webhooks | Send customer email |
| `MerchantSendEmailJob` | webhooks | Send merchant email |
| `EnqueueInventoryFailureEmailJob` | — | Enqueue inventory failure email |
| `SendInventoryFailureEmailJob` | — | Send inventory failure email |
| `TagSubscriptionOrderJob` | webhooks | Tag orders |
| `CreateSellingPlanTranslationsJob` | webhooks | Create plan translations |
| `AddFieldsToMetaobjectJob` | migrations | Migration — add fields to metaobjects |
| `EnqueueAddFieldsToMetaobjectJob` | migrations | Enqueue AddFieldsToMetaobjectJob |
| `TransitionFailedContractsToActiveJob` | migrations | Migration — reactivate failed contracts |
| `EnqueueTransitionFailedContractsToActiveJob` | migrations | Enqueue TransitionFailedContractsToActiveJob |

## Scheduler Config
| Environment | Scheduler | Notes |
|-------------|-----------|-------|
| Production | `INLINE` | Jobs run synchronously in request context |
| Development | `INLINE` | Jobs run synchronously in request context |
| Test | `TEST` | Jobs captured as Request objects for testing |
| Production (Cloud Tasks) | `CLOUD_TASKS` | When configured, uses Google Cloud Tasks |
  - Config: `location`, `projectId`, `queuePrefix`, `callbackUrl`, `serviceAccountEmail`, `audience`
  - Each job runs as POST to `callbackUrl` with base64-encoded JSON body
  - OIDC token auth with `serviceAccountEmail` + `audience`

## SubscriptionContractDraft Flow
```
Merchant edits subscription (POST /app/contracts/$id/edit)
  → buildDraftFromContract(shopDomain, contractId, graphql)
    → admin.graphql(SubscriptionContractUpdateMutation)
    → returns SubscriptionContractDraft instance (with draftId)
  → draft.addLine(line) — add subscription line
  → draft.removeLine(lineId) — remove line
  → draft.updateLine(lineId, {quantity, currentPrice, pricingPolicy})
  → draft.update({deliveryPolicy, billingPolicy}) — update draft settings
  → draft.updateAddress(address, deliveryMethodName)
  → draft.update(draftUpdateInput) — update address/billing/delivery
  → draft.getDiscounts() — query existing discounts
  → draft.removeDiscount(discountId) — remove discount
  → draft.commit() — commit draft (+ auto-remove invalid discounts)
```

## Key Files
| File | Purpose |
|------|---------|
| `app/lib/jobs/Job.ts` | Abstract Job class (run/perform/terminate logic) |
| `app/lib/jobs/JobRunner.ts` | Job registry + dispatcher (execute/enqueue/register) |
| `app/lib/jobs/schedulers/Scheduler.ts` | Abstract Scheduler interface |
| `app/lib/jobs/schedulers/InlineScheduler.ts` | In-process synchronous scheduler |
| `app/lib/jobs/schedulers/CloudTaskScheduler.ts` | Google Cloud Tasks scheduler |
| `app/lib/jobs/schedulers/TestScheduler.ts` | Test scheduler (captures requests) |
| `app/models/SubscriptionContractDraft/SubscriptionContractDraft.ts` | Draft wrapper class (add/remove/update/commit lines, discounts) |
| `app/models/SubscriptionContract/SubscriptionContract.server.ts` | Contract queries, rebill details |
| `app/models/DunningTracker/DunningTracker.server.ts` | Dunning tracking (upsert, markCompleted) |
| `app/services/DunningService.ts` | Dunning orchestration (retry/penultimate/final) |
| `app/services/FinalAttemptDunningService.ts` | Final attempt (cancel/pause/skip + emails) |
| `app/services/RetryDunningService.ts` | Retry (schedule RebillSubscriptionJob + payment failure email) |
| `app/services/PenultimateAttemptDunningService.ts` | Penultimate attempt (schedule + email) |
| `app/services/InventoryService.ts` | Inventory error handling |
| `app/graphql/*.ts` | GraphQL operations (60+ queries/mutations) |
| `app/context/ShopContext.tsx` | React context for shop info |

## Security Headers (entry.server.tsx)
- `X-Content-Type-Options: nosniff`
- `X-Download-Options: noopen`
- `X-Permitted-Cross-Domain-Policies: none`
- `Referrer-Policy: origin-when-cross-origin`
- Content-Security-Policy:
  - `default-src 'self'`
  - `script-src 'self' 'unsafe-inline' https://cdn.shopify.com`
  - `connect-src 'self' https://atlas.shopifysvc.com https://extensions.shopifycdn.com`
  - `upgrade-insecure-requests`
- `Strict-Transport-Security: max-age=631138519; includeSubDomains`

## Access Scopes (shopify.app.toml)
```
customer_read_customers, customer_read_orders, customer_read_own_subscription_contracts,
customer_write_customers, customer_write_own_subscription_contracts, read_all_orders,
read_locales, read_locations, read_themes, write_customer_payment_methods,
write_customers, write_metaobject_definitions, write_metaobjects, write_orders,
write_own_subscription_contracts, write_products, write_translations, read_analytics
```
