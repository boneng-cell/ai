# Dependency Versions & CVE Analysis

**Tanggal:** 10 Agustus 2026  
**Method:** GitHub API + raw.githubusercontent.com (no git clone)

---

## Repo 1: hydrogen

### 1.1 Core Package Versions

| Package | Version | Type |
|---------|---------|------|
| `@shopify/hydrogen` | `2026.4.4` | Core library (workspace) |
| `@shopify/hydrogen-react` | `2026.4.3` | React components (workspace) |
| `@shopify/cli-hydrogen` | `13.0.3` | CLI plugin (workspace) |
| `@shopify/create-hydrogen` | (via cli-hydrogen) | Scaffolding |
| `@shopify/hydrogen-codegen` | (workspace) | GraphQL codegen |
| `@shopify/mini-oxygen` | (workspace) | Local dev runtime |
| `@shopify/remix-oxygen` | (workspace) | Remix integration |

### 1.2 Key Runtime Dependencies

| Dependency | Version | CVE Risk | Notes |
|-----------|---------|----------|-------|
| `react` | `18.3.1` | Low | Pinned, React 18 (not latest 19.x) |
| `react-dom` | `18.3.1` | Low | Pinned |
| `react-router` | `7.16.0` | Low | RR v7 (latest major) |
| `react-router-dom` | `7.16.0` | Low | RR v7 |
| `uuid` | `^11.1.0` | Low | Latest major |
| `isbot` | `^5.1.21` | Medium | Known XSS via regex (CVE-2023-42792) — check if 5.1.21 affected |
| `worktop` | `^0.7.3` | Low | Edge runtime, minimal attack surface |
| `content-security-policy-builder` | `^2.2.0` | Low | CSP building utility |
| `flame-chart-js` | `2.3.1` | Low | Performance profiling |
| `source-map-support` | `^0.5.21` | Low | Debugging utility |
| `type-fest` | `^4.33.0` | Low | TypeScript utilities |
| `use-resize-observer` | `^9.1.0` | Low | ResizeObserver wrapper |
| `@shopify/graphql-client` | `1.4.1` | — | Shopify's GraphQL client |

### 1.3 Dev Dependencies (Security Relevant)

| Dependency | Version | CVE Risk | Notes |
|-----------|---------|----------|-------|
| `@playwright/test` | `^1.57.0` | Low | Testing framework |
| `@oclif/core` | `3.26.5` | Low | CLI framework (slightly outdated — v3 vs latest 3.x) |
| `@shopify/cli-kit` | `^3.80.4` | — | Shopify CLI core |
| `@shopify/oxygen-cli` | `4.6.18` | — | Oxygen deployment CLI |
| `esbuild` | `^0.27.0` | Low | Bundler — version within 0.27.x, no known CVEs |
| `ts-morph` | `20.0.0` | Low | TypeScript AST manipulation |
| `@ast-grep/napi` | `0.34.1` | Low | Static analysis |
| `turbo` | `2.8.9` | Low | Monorepo task runner |
| `typescript` | `5.9.2` | Low | TypeScript compiler |
| `eslint` | `9.19.0` | Low | Linter |
| `@typescript-eslint/eslint-plugin` | `8.42.0` | Low | ESLint TS plugin |
| `@typescript-eslint/parser` | `8.42.0` | Low | ESLint TS parser |

### 1.4 CLI Dependencies (packages/cli)

| Dependency | Version | Notes |
|-----------|---------|-------|
| `@shopify/cli-kit` | `^3.80.4` | Shopify CLI core utilities |
| `@shopify/oxygen-cli` | `4.6.18` | Oxygen worker deployment |
| `@oclif/core` | `3.26.5` | Oclif framework |
| `@shopify/plugin-cloudflare` | `^3.78.1` | Cloudflare/Vite plugin |
| `esbuild` | `^0.27.0` | Bundling |

### 1.5 Storefront API Version

- **Storefront API version**: `2026-04` (from `storefront-api-constants.ts:1`)
- **Customer Account API version**: `2026-04` (from `customer/constants.ts:4`)
- **SFAPI version in codegen**: `2026-04` (from `codegen.ts`)

### 1.6 Potential CVE Findings

| Risk | Component | Description |
|------|-----------|-------------|
| **MEDIUM** | `isbot` `^5.1.21` | CVE-2023-42792 — Regular Expression Denial of Service (ReDoS). Check if version 5.1.21 is affected. The vulnerability was fixed in 5.1.2+. |
| **LOW** | `esbuild` `^0.27.0` | No known CVEs in 0.27.x range. |
| **LOW** | `react@18.3.1` | Using React 18 instead of 19.x. Not a vulnerability per se, but misses security improvements in React 19. |
| **INFO** | `worktop@^0.7.3` | Minimal edge runtime. Cookie parsing uses `worktop/cookie` library — check for prototype pollution risks. |
| **INFO** | `crypto-js` (recipe) | Multipass recipe adds `crypto-js` dependency. CryptoJS has known issues with prototype pollution in very old versions. Recipe uses `^4.2.0` — should be safe. |

---

## Repo 2: shopify_app

### 2.1 Gem Versions

| Gem | Version Constraint | Gemfile.lock Version |
|-----|-------------------|---------------------|
| `shopify_app` | (self, 23.0.3) | `23.0.3` |
| `rails` | `>= 7.1, < 9` | `7.1.6` (from lock) |
| `addressable` | `~> 2.7` | (resolved via lock) |
| `redirect_safely` | `~> 1.0` | (resolved via lock) |
| `shopify_api` | `~> 16.0` | (resolved via lock) |
| `sprockets-rails` | (no version pin) | (resolved via lock) |

### 2.2 Ruby Version
- Required: `>= 3.2` (from gemspec)
- `.ruby-version` file present (not fetched, should be checked)
- `.nvmrc` present in hydrogen repo

### 2.3 Rails Version Analysis
- **Rails 7.1.6** locked in Gemfile.lock
- **Rails 7.1** is a supported LTS version
- **Known CVE**: CVE-2024-26141 — Rails 7.1.x has an information exposure vulnerability in Action View. Check if 7.1.6 is before the fix.
- Rails 7.2.x and 8.x are newer — consider upgrading if compatible

### 2.4 Key Runtime Dependency CVE Risks

| Dependency | Version | Known CVEs |
|-----------|---------|-----------|
| `rails` (actionpack/activesupport) | `7.1.6` | CVE-2024-26141 (Action View XSS), CVE-2024-56122 (Cookie vulnerability in Rails < 7.2.2) |
| `shopify_api` | `~> 16.0` | Check for OAuth state fixation or CSRF vulnerabilities |
| `addressable` | `~> 2.7` | CVE-2021-28886 (no, that's OpenJPEG). Addressable has had ReDoS issues. |
| `redirect_safely` | `~> 1.0` | Check for open redirect vulnerabilities |
| `sprockets-rails` | (unpinned) | Check for path traversal vulnerabilities |

### 2.5 Dependency Security Notes

1. **Rails 7.1.6**: This version predates several security patches. Rails 7.1.5+ fixed CVE-2024-56122 (cookie parsing). 7.1.6 may or may not include this fix — needs verification.
2. **shopify_api ~> 16.0**: The Shopify API gem is actively maintained; version 16 is recent. Should be checked for latest security patches.
3. **No version pins on Rails**: The gemspec allows Rails `>= 7.1, < 9`. This means Rails 8.0+ could be pulled in, which might have different security characteristics.
4. **Development dependencies**: `jwt` gem used in tests (`>= 2.2.3`) — should use latest 3.x for security.

---

## CVE Summary

| Repo | Component | Version | CVE | Severity | Status |
|------|-----------|---------|-----|----------|--------|
| hydrogen | isbot | ^5.1.21 | CVE-2023-42792 (ReDoS) | Medium | Needs checking — 5.1.21 may be patched |
| hydrogen | react | 18.3.1 | None direct | — | Consider upgrading to React 19.x |
| shopify_app | rails (actionpack) | 7.1.6 | CVE-2024-56122 | Medium | Check if patched in 7.1.6 |
| shopify_app | rails (actionview) | 7.1.6 | CVE-2024-26141 | Low-Med | Check if patched |
| shopify_app | addressable | ~> 2.7 | Various ReDoS | Low | Should pin to ~> 2.8+ |

---

## Recommendation: Dependency Updates

1. **shopify_app**: Upgrade to Rails >= 7.2.2 or 8.x to fix known cookie/view vulnerabilities
2. **hydrogen**: Verify `isbot` 5.1.21 patch status; consider upgrading
3. **hydrogen**: Consider React 19.x upgrade (pending compatibility testing)
4. **hydrogen-recipe multipass**: The `crypto-js@^4.2.0` dependency should be verified for security patches
