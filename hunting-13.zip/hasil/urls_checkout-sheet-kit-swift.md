# URL / Domain / Endpoint Extraction — checkout-sheet-kit-swift

## Version
- Swift Package: **3.8.1** (from `MetaData.swift` and `podspec`)
- iOS deployment target: **13.0** (podspec) / **16.0** (for `ShopifyAcceleratedCheckouts` — `@available` annotations)
- Swift tools version: **5.9**
- API version (Storefront): **2026-04** (from `ShopifyAcceleratedCheckouts.swift:14`)

## Dependencies (from `Package.swift`)
| Package | URL | Version |
|---------|-----|---------|
| `SwiftLintPlugin` | `https://github.com/lukepistrol/SwiftLintPlugin` | `>=0.2.2` |
| `ViewInspector` | `https://github.com/nalexn/ViewInspector` | `>=0.10.0` |

### CocoaPods (from `podspec`)
- No external Swift Package dependencies in the main `ShopifyCheckoutSheetKit` target
- `ShopifyAcceleratedCheckouts` depends on `ShopifyCheckoutSheetKit/Core` and `ShopifyCheckoutSheetKit/AcceleratedCheckouts`

## All Endpoints & Domains

### Storefront API Endpoints
| URL / Pattern | File:Line | Description |
|---------------|-----------|-------------|
| `https://{storefrontDomain}/api/{apiVersion}/graphql.json` | `Sources/ShopifyAcceleratedCheckouts/Internal/StorefrontAPI/StorefrontAPI.swift:31` | Storefront GraphQL API for cart operations |
| `X-Shopify-Storefront-Access-Token` header | `StorefrontAPI.swift:33` | Storefront access token header |

### Checkout / Storefront URLs
| URL / Pattern | File:Line | Description |
|---------------|-----------|-------------|
| `CheckoutViewController(checkout: url, delegate:)` | `Sources/ShopifyCheckoutSheetKit/ShopifyCheckoutSheetKit.swift:56` | Public `present(checkout:from:)` |
| `CheckoutWebView.for(checkout: url, recovery:, entryPoint:)` | `Sources/ShopifyCheckoutSheetKit/CheckoutWebView.swift:42` | WebView creation / caching |
| URL with `?payment=shop_pay` appended | `Wallets/ShopPay/ShopPayViewController.swift:48` | Shop Pay checkout URL modification |
| `multipass` substring check in URL | `Sources/ShopifyCheckoutSheetKit/CheckoutURL.swift:18` | Multipass URL detection |
| `order_id` query param extraction | `Sources/ShopifyCheckoutSheetKit/CheckoutWebView.swift:403` | Order ID from confirmation URL |
| `thank[_-]you` regex on path components | `Sources/ShopifyCheckoutSheetKit/CheckoutURL.swift:21` | Thank-you page detection |

### Deep Link / Universal Link Handling
| URL | File:Line | Description |
|-----|-----------|-------------|
| `applinks:yourdomain.com` (entitlements) | `documentation/universal_links.md` | iOS Universal Links associated domains |
| `.well-known/apple-app-site-association` | `documentation/universal_links.md` | Apple AASA file (must be on custom domain, NOT `*.myshopify.com`) |

### WebView Navigation Delegate (CheckoutWebView.swift)
| Behavior | File:Line |
|----------|-----------|
| `decidePolicyFor navigationAction` intercepts external + deep links | `CheckoutWebView.swift:271` |
| `open_externally=true` or `open_externally=1` query param → cancel nav + emit `checkoutDidClickLink` | `CheckoutWebView.swift:336` |
| `decidePolicyFor navigationResponse` → HTTP status code check (401/404/410/5xx) | `CheckoutWebView.swift:290` |
| `WKNavigationDelegate` `didStartProvisionalNavigation` / `didFinish` / `didFail` | `CheckoutWebView.swift:347-390` |
| Cache timeout: 5 minutes (stale after) | `CheckoutWebView.swift:421` |

### External URL Opening
| URL | File:Line | Description |
|-----|-----------|-------------|
| `UIApplication.shared.canOpenURL(url)` → `UIApplication.shared.open(url)` | `CheckoutDelegate.swift:85` | Default `checkoutDidClickLink` fallback opens external URLs |
| Same pattern in `CheckoutViewController.swift:162` → `CheckoutDelegateWrapper.checkoutDidClickLink` | `CheckoutViewController.swift:162` | SwiftUI wrapper fallback |

### Domains
| Domain | File:Line | Description |
|--------|-----------|-------------|
| `myshopify.com` | `Sources/ShopifyAcceleratedCheckouts/ShopifyAcceleratedCheckouts+Configuration.swift:17` | Storefront domain format: `my-shop.myshopify.com` |
| `shopify.com` | N/A (Apple Pay domain is user-provided via `merchantIdentifier`) | Apple Pay merchant domain (configured by consumer app) |
| `developer.apple.com` | `ApplePayConfiguration.swift:99` | Apple Pay merchant identifier docs |
| `shopify.dev` | `Configuration.swift`, `StorefrontAPI.swift` | Shopify developer docs references |
| `github.com/Shopify/checkout-sheet-kit-swift` | `podspec` | Package source / changelog links |
| `github.com/Shopify/checkout-sheet-kit-swift.git` | `podspec` | Git source for CocoaPods |
| `applinks:` | `documentation/universal_links.md` | Universal Links entitlements format |

### Debug / Internal URLs
| URL | File:Line | Context |
|-----|-----------|---------|
| `https://{your_storefront_domain}/.well-known/apple-app-site-association` | `documentation/universal_links.md` | AASA file validation URL |
| `https://www.example.com/cart` | `documentation/universal_links.md` | Test URL for universal links |

### Documentation URLs (README / Docs)
| URL | File |
|-----|------|
| `https://shopify.dev/docs/custom-storefronts/mobile-kit` | README references (via RN repo) |
| `https://developer.apple.com/documentation/xcode/supporting-universal-links-in-your-app` | universal_links.md |
| `https://developer.apple.com/documentation/technotes/tn3155-debugging-universal-links` | universal_links.md |

## Deep Link / WebView / URL-Handling File Map (Swift)

| File | Purpose |
|------|---------|
| `Sources/ShopifyCheckoutSheetKit/CheckoutURL.swift` | URL classification: `isDeepLink()`, `isMultipassURL()`, `isConfirmationPage()`, `isBlank()` |
| `Sources/ShopifyCheckoutSheetKit/CheckoutWebView.swift` | `WKNavigationDelegate` — intercepts external links, deep links, `open_externally` param; handles HTTP errors (401/404/410/5xx); 5-min cache |
| `Sources/ShopifyCheckoutSheetKit/CheckoutWebViewController.swift` |UIViewController wrapping WKWebView; `presentFallbackViewController()` on error recovery |
| `Sources/ShopifyCheckoutSheetKit/CheckoutViewController.swift` | `UINavigationController` containing `CheckoutWebViewController`; `CheckoutDelegateWrapper` opens external URLs via `UIApplication.shared.open()` |
| `Sources/ShopifyCheckoutSheetKit/CheckoutDelegate.swift` | Protocol: `checkoutDidClickLink(url:)` — default impl calls `UIApplication.shared.canOpenURL()` + `.open()` |
| `Sources/ShopifyCheckoutSheetKit/CheckoutBridge.swift` | WKScriptMessageHandler + JS injection (`window.MobileCheckoutSdk.dispatchMessage`) |
| `Sources/ShopifyCheckoutSheetKit/MessageHandler.swift` | `WKScriptMessageHandler` wrapper |
| `Sources/ShopifyCheckoutSheetKit/ShopifyCheckoutSheetKit.swift` | Public API: `present(checkout:from:)`, `preload(checkout:)`, `invalidate()` |
| `Sources/ShopifyCheckoutSheetKit/Configuration.swift` | Configuration including `platform`, `colorScheme`, `preloading` |
| `Sources/ShopifyCheckoutSheetKit/Internal/Extensions/URL.swift` | URL query param append helper (`appendQueryParam`) |
| `Sources/ShopifyCheckoutSheetKit/Logger.swift` | `OSLogger` — subsystem `com.shopify.checkoutsheetkit` |
| `documentation/universal_links.md` | Universal Links setup guide |
| `Samples/MobileBuyIntegration/MobileBuyIntegration/AppDelegate.swift` | Sample AppDelegate for universal link handling |
| `Sources/ShopifyAcceleratedCheckouts/ShopifyAcceleratedCheckouts.swift` | Accelerated Checkouts entry; `apiVersion = "2026-04"` |
| `Sources/ShopifyAcceleratedCheckouts/Internal/StorefrontAPI/StorefrontAPI.swift` | GraphQL client + `https://{storefrontDomain}/api/{apiVersion}/graphql.json` |
| `Sources/ShopifyAcceleratedCheckouts/Wallets/ShopPay/ShopPayViewController.swift` | Shop Pay checkout URL modification |
| `Sources/ShopifyAcceleratedCheckouts/Wallets/ApplePay/ApplePayViewController.swift` | Apple Pay flow (no direct URL opening) |
| `Sources/ShopifyAcceleratedCheckouts/Wallets/WalletController.swift` | `getTopViewController()` for presenting checkout |
| `Sources/ShopifyAcceleratedCheckouts/Wallets/ApplePay/Data/PassKitFactory.swift` | Apple Pay data mapping (no URL handling) |
| `Sources/ShopifyAcceleratedCheckouts/Internal/Models/CheckoutIdentifier.swift` | Checkout ID model (enum: cart/variant/invariant) |
