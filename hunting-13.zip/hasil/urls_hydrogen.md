# URL / Domain / Endpoint Extraction — hydrogen

**Repo:** https://github.com/Shopify/hydrogen  
**Tanggal:** 10 Agustus 2026  
**Branch:** main

---

## 1. Dokumentasi & Situs Web

| No | URL | Sumber |
|----|-----|--------|
| 1 | `https://hydrogen.shopify.dev` | README.md:5 |
| 2 | `https://shopify.dev/custom-storefronts/hydrogen` | README.md:13 |
| 3 | `https://npmcharts.com/compare/@shopify/hydrogen` | README.md:4 |
| 4 | `https://shopify.dev/hydrogen` | README.md:61 |
| 5 | `https://shopify.dev/docs/api/storefront` | storefront.ts (docs links) |
| 6 | `https://shopify.dev/docs/api/customer` | customer.ts:5 |
| 7 | `https://shopify.dev/docs/api/customer` | customer.ts types doc |
| 8 | `https://shopify.dev/api/usage/versioning#release-schedule` | README.md:49 |
| 9 | `https://shopify.dev/api/storefront` | storefront-client.ts |
| 10 | `https://shopify.dev/docs/api/storefront#authentication` | storefront-client.ts |
| 11 | `https://shopify.dev/apps/auth/oauth/delegate-access-tokens` | storefront-client.ts |
| 12 | `https://shopify.dev/docs/api/storefront` | codegen.ts docs |
| 13 | `https://shopify.dev/docs/api/customer` | codegen.ts docs |
| 14 | `https://github.com/Shopify/hydrogen` | README.md |
| 15 | `https://github.com/Shopify/hydrogen-v1` | README.md:64 |
| 16 | `https://github.com/Shopify/hydrogen/blob/main/packages/cli/` | README.md:71 |
| 17 | `https://github.com/Shopify/hydrogen/blob/main/packages/hydrogen/` | README.md:70 |
| 18 | `https://npmcharts.com/compare/@shopify/hydrogen?minimal=true` | README.md:3 |

---

## 2. API Endpoints & Domain Patterns

### 2.1 Storefront API
| Endpoint | Pattern | File/Sumber |
|----------|---------|-------------|
| Storefront API URL | `${domain}/api/${API_VERSION}/graphql.json` | storefront-client.ts:73 |
| API Version (default) | `2026-04` | storefront-api-constants.ts:1 |
| SFAPI Proxy regex | `/api/(?:unstable\|2\d{3}-\d{2})/graphql.json` | utils/request.ts (SFAPI_RE) |
| MCP endpoint regex | `/api/mcp` | utils/request.ts (MCP_RE) |
| Storefront ID header | `Shopify-Storefront-Id` | constants.ts |
| Storefront private token header | `X-Shopify-Storefront-Private-Token` | storefront-client.ts |
| Storefront public token header | `X-Shopify-Storefront-Access-Token` | storefront-client.ts |

### 2.2 Customer Account API
| Endpoint | Pattern | File/Sumber |
|----------|---------|-------------|
| CA Base URL | `https://shopify.com/${shopId}` | customer-account-helper.ts:5 |
| CA Auth Base URL | `https://shopify.com/authentication/${shopId}` | customer-account-helper.ts:6 |
| GraphQL endpoint | `https://shopify.com/${shopId}/account/customer/api/${apiVersion}/graphql` | customer-account-helper.ts:9 |
| OAuth authorize | `https://shopify.com/authentication/${shopId}/oauth/authorize` | customer-account-helper.ts:12 |
| OAuth token exchange | `https://shopify.com/authentication/${shopId}/oauth/token` | customer-account-helper.ts:14 |
| Logout URL | `https://shopify.com/authentication/${shopId}/logout` | customer-account-helper.ts:16 |
| Login scope | `openid email customer-account-api:full` | customer-account-helper.ts:15 |
| Default CA API version | `2026-04` | customer/constants.ts:4 |
| Customer API client ID | `30243aa5-17c1-465a-8493-944bcc4e88aa` | customer/constants.ts:8 |

### 2.3 Multipass
| Endpoint | Pattern | File/Sumber |
|----------|---------|-------------|
| Client multipass | POST `/account/login/multipass` | multipass.ts:29 |
| Server multipass route | GET/POST `/account/login/multipass/${token}` | multipassify.server.ts:42-43 |
| Multipass secret env | `PRIVATE_SHOPIFY_STORE_MULTIPASS_SECRET` | multipass route |
| Multipass spec | https://shopify.dev/api/multipass | multipassify.server.ts:5 |

### 2.4 Analytics & Tracking
| Endpoint | Pattern | File/Sumber |
|----------|---------|-------------|
| Perf-kit CDN | `cdn.shopify.com/shopifycloud/perf-kit` | storefront.ts fixtures |
| Monorail batch | `/produce_batch` | storefront.ts fixtures |
| Perf-kit produce | `/v1/produce` | storefront.ts fixtures |
| SFAPI GraphQL | `/api/unstable/graphql.json` | useShopifyCookies.tsx |
| Unique token header | `X-Shopify-UniqueToken` | tracking-utils.ts |
| Visit token header | `X-Shopify-VisitToken` | tracking-utils.ts |
| Storefront-Y header | `Shopify-Storefront-Y` | constants.ts |
| Storefront-S header | `Shopify-Storefront-S` | constants.ts |

### 2.5 Development & Testing
| Domain/URL | Sumber |
|-------------|--------|
| `mock.shop` | storefront-client.ts (MOCK_SHOP_DOMAIN) |
| `.tryhydrogen.dev` | customer.ts (HYDROGEN_TUNNEL_DOMAIN_SUFFIX) |
| `http://localhost:3000` | README.md:38 |
| `https://hydrogen-preview.myshopify.com` | codegen.ts:11 |
| `http://localhost:3100-3200` | server.ts (DevServer port range) |
| `localhost` | useShopifyCookies.tsx (domain reset) |

### 2.6 Shopify Admin/Dev URLs
| URL | Sumber |
|-----|--------|
| `https://admin.${mydomain}` | FrameAncestors CSP |
| `https://cdn.shopify.com/shopifycloud/app-bridge.js` | App Bridge |

---

## 3. Environment Variables (URLs/Domains)

| Env Var | Deskripsi | File |
|---------|----------|------|
| `SESSION_SECRET` | Cookie session encryption key | templates/skeleton/.env |
| `PUBLIC_STORE_DOMAIN` | Store domain | types.d.ts:6 |
| `PRIVATE_STOREFRONT_API_TOKEN` | Private Storefront API token | createHydrogenContext.ts |
| `PUBLIC_STOREFRONT_API_TOKEN` | Public Storefront API token | createHydrogenContext.ts |
| `PUBLIC_STOREFRONT_ID` | Storefront ID | types.d.ts |
| `PUBLIC_CUSTOMER_ACCOUNT_API_CLIENT_ID` | CA API client ID | types.d.ts |
| `PUBLIC_CUSTOMER_ACCOUNT_API_URL` | CA API base URL | types.d.ts |
| `PUBLIC_CHECKOUT_DOMAIN` | Checkout domain | types.d.ts |
| `SHOP_ID` | Shopify shop ID | types.d.ts |
| `PRIVATE_SHOPIFY_STORE_MULTIPASS_SECRET` | Multipass secret | env.d.ts recipe |

---

## 4. Redirect & Return Parameters

| Param | Usage | File |
|-------|-------|------|
| `return_to` | URL-encoded redirect target after login | get-redirect-url.ts:12 |
| `redirect` | Alternative redirect param | get-redirect-url.ts:12 |
| `acr_values` | OIDC authentication context | account_.login.tsx |
| `login_hint` | Pre-fill login email | account_.login.tsx |
| `login_hint_mode` | Login hint mode | account_.login.tsx |
| `locale` | Locale override | account_.login.tsx |
| `oauth_recovery` | OAuth state recovery flag | customer.ts:56 |
| `host` | Base64-encoded shop host | account_.login.tsx (via ShopifyAPI) |

---

## 5. Internal Routes

| Route | Method | Handler | Purpose |
|-------|--------|---------|---------|
| `/` | GET | `routes/_index.tsx` | Home page |
| `/cart` | GET/POST | `routes/cart.tsx` | Cart management |
| `/cart.$lines` | GET | `routes/cart.$lines.tsx` | Preloaded cart |
| `/products/$handle` | GET | `routes/products.$handle.tsx` | Product detail |
| `/collections/$handle` | GET | `routes/collections.$handle.tsx` | Collection listing |
| `/collections.all` | GET | `routes/collections.all.tsx` | All collections |
| `/account` | GET | `routes/account.tsx` | Account layout |
| `/account/authorize` | GET | `routes/account_.authorize.tsx` | OAuth callback |
| `/account/login` | GET/POST | `routes/account_.login.tsx` | Login page |
| `/account/login/multipass` | POST | `routes/account_.login.multipass.tsx` | Multipass endpoint |
| `/account/register` | GET/POST | `routes/account_.register.tsx` | Registration |
| `/account/recover` | GET/POST | `routes/account_.recover.tsx` | Password recovery |
| `/account/reset/$id/$resetToken` | GET/POST | `routes/account_.reset.$id.tsx` | Password reset |
| `/account/logout` | GET/POST | `routes/account_.logout.tsx` | Logout |
| `/account/orders` | GET | `routes/account.orders._index.tsx` | Orders list |
| `/account/orders/$id` | GET | `routes/account.orders.$id.tsx` | Order detail |
| `/account/profile` | GET/PUT | `routes/account.profile.tsx` | Profile management |
| `/account/addresses` | GET | `routes/account.addresses.tsx` | Address book |
| `/discount/$code` | GET | `routes/discount.$code.tsx` | Discount redirect |
| `/sitemap.$type.$page.xml` | GET | `routes/sitemap.$type.$page.xml.tsx` | Sitemap |
| `/[robots.txt]` | GET | `routes/[robots.txt].tsx` | robots.txt |
| `/[sitemap.xml]` | GET | `routes/[sitemap.xml].tsx` | Sitemap index |
| `/blogs/$blogHandle/$articleHandle` | GET | Blog article | Article detail |
| `/pages/$handle` | GET | `routes/pages.$handle.tsx` | Page content |
| `/search` | GET | `routes/search.tsx` | Search results |
| `/$` | GET | `routes/$.tsx` | Catch-all route |
| `/graphiql` | GET | virtual route | GraphQL IDE |

### 2.6 App Bridge / Admin Integration

| Route | Handler |
|-------|---------|
| `/app` | App admin entry |
| `/account/login/multipass/{token}` | Shopify multipass auth |
