# URL Extraction — shop-chat-agent

## Route Endpoints (App Routes)

| Route | Method | Description | Auth |
|-------|--------|-------------|------|
| `/` | GET | Index page (landing) | Public |
| `/app` | GET | App layout wrapper | Shopify OAuth (`authenticate.admin`) |
| `/app/_index` | GET | App home page (Polaris UI) | Shopify OAuth |
| `/chat` | GET, POST | SSE chat endpoint with Claude + MCP tools | Public (CORS-enabled) |
| `/chat?history=true&conversation_id=XYZ` | GET | Fetch conversation history | Public (CORS-enabled) |
| `/auth/$` | * | Shopify OAuth flow (handled by SDK) | Shopify SDK |
| `/auth/callback` | GET | Customer OAuth2 callback (PKCE) | Public |
| `/auth/token-status` | GET, OPTIONS | Check customer token status | Public (CORS-enabled) |
| `/api/webhooks` | POST | Shopify webhooks (APP_UNINSTALLED) | HMAC verified by Shopify SDK |

## External URLs & Domains

### App & Redirects
- `https://shop-chat-agent.com` — Application URL (shopify.app.toml)
- `https://shop-chat-agent.com/api/auth` — Auth redirect URL (shopify.app.toml)
- `https://shop-chat-agent.com/callback` — Customer auth redirect URI (shopify.app.toml `[customer_authentication]`)
- `https://localhost:3458/auth/callback` — Dev redirect URL (.env.example)

### CDN & Assets
- `https://cdn.shopify.com/` — Shopify CDN (preconnect in root.jsx)
- `https://cdn.shopify.com/static/fonts/inter/v4/styles.css` — Inter font CSS

### AI Provider
- `https://api.anthropic.com` — Anthropic Claude API (via `@anthropic-ai/sdk`)
- Model: `claude-sonnet-4-20250514`

### MCP Endpoints (Dynamic)
- `<shopDomain>/api/mcp` — Storefront MCP endpoint (JSON-RPC 2.0 `tools/list`, `tools/call`)
- `<accountHostUrl>/customer/api/mcp` — Customer MCP endpoint (JSON-RPC 2.0)
- `<accountHostUrl>` = `shopDomain` with `.myshopify.com` → `.account.myshopify.com`

### Customer Account API Discovery (Dynamic)
- `https://<hostname>/.well-known/customer-account-api` — Returns `mcp_api` URL
- `https://<hostname>/.well-known/openid-configuration` — Returns `authorization_endpoint` and `token_endpoint`

### Documentation & Specs
- `https://modelcontextprotocol.io/` — MCP specification
- `https://shopify.dev/docs/apps/build/storefront-mcp` — Shopify Storefront MCP dev docs

## GraphQL Endpoints
- Admin GraphQL API (via `@shopify/shopify-app-react-router` SDK)
- Storefront MCP API (via JSON-RPC, not GraphQL)

## Database
- SQLite via Prisma (`file:dev.sqlite`)
- Tables: Session, CustomerToken, CodeVerifier, Conversation, Message, CustomerAccountUrls
