# Security Findings — shop-chat-agent

## 1. `/chat` Endpoint Analysis

### Route File
`app/routes/chat.jsx`

### Endpoints
1. **GET /chat** — Handles two modes:
   - History fetch: `?history=true&conversation_id=XYZ` → returns JSON with conversation history
   - SSE streaming: requires `Accept: text/event-stream` header → returns SSE stream
   - All other requests → 400 "apiUnsupported" error
2. **POST /chat** — Always returns SSE stream (chat session)

### CORS Configuration (Critical)
```js
function getCorsHeaders(request) {
  const origin = request.headers.get("Origin") || "*";
  return {
    "Access-Control-Allow-Origin": origin,  // Reflects ANY origin
    "Access-Control-Allow-Credentials": "true",
    "Access-Control-Allow-Methods": "GET, POST, OPTIONS",
    "Access-Control-Allow-Headers": requestHeaders,  // Reflects ANY request headers
  };
}
```
**VULNERABILITY**: The CORS policy reflects the `Origin` header from the request without validation, combined with `Access-Control-Allow-Credentials: true`. This allows any website to make authenticated CORS requests to the `/chat` endpoint.

### conversationId Handling
```js
const conversationId = body.conversation_id || Date.now().toString();
```
- If no `conversation_id` is provided, a new one is generated using `Date.now().toString()`
- This is a timestamp-based ID, which is predictable
- **No validation** that the `conversation_id` belongs to the requesting origin/shop

### Origin Header Handling (Critical)
```js
const shopDomain = request.headers.get("Origin");
```
**VULNERABILITY**: The `Origin` header is used as the shop domain with NO validation:
1. The server fetches `https://${hostname}/.well-known/customer-account-api` and `https://${hostname}/.well-known/openid-configuration` where `hostname` comes from the user-controlled `Origin` header
2. This is a **Server-Side Request Forgery (SSRF)** — an attacker can set `Origin: https://evil.com` to force the server to make requests to arbitrary domains
3. The MCP client endpoints are also derived from this unvalidated origin: `this.storefrontMcpEndpoint = `${hostUrl}/api/mcp`` and `this.customerMcpEndpoint = `${accountHostUrl}/customer/api/mcp`` where `accountHostUrl = hostUrl.replace(...)` 

### Error Handling
- `handleChatRequest` wraps everything in try/catch, returns 500 with `error.message`
- SSE stream errors go through `handleStreamingError()` which sends error details to client:
  - 401/auth errors → "Authentication failed with Claude API" + "Please check your API key"
  - 429/529/Overloaded → "Rate limit exceeded"
  - Other → "Failed to get response from Claude" + `error.message`
- Error messages may leak internal state but are relatively sanitized

## 2. db.server.js Analysis

### File: `app/db.server.js`

### Key Functions
1. **`storeCodeVerifier(state, verifier)`** — Stores PKCE code verifier with state as unique key, 10-min expiry
2. **`getCodeVerifier(state)`** — Retrieves and **deletes** code verifier (single-use)
3. **`storeCustomerToken(conversationId, accessToken, expiresAt)`** — Upserts customer token by conversationId
4. **`getCustomerToken(conversationId)`** — Returns non-expired token
5. **`createOrUpdateConversation(conversationId)`** — Creates or updates conversation
6. **`saveMessage(conversationId, role, content)`** — Saves message to conversation
7. **`getConversationHistory(conversationId)`** — Returns all messages ordered by creation time
8. **`storeCustomerAccountUrls({conversationId, mcpApiUrl, authorizationUrl, tokenUrl})`** — Upserts customer account URLs
9. **`getCustomerAccountUrls(conversationId)`** — Retrieves customer account URLs

### Security Observations
- **No input sanitization** on `conversationId` — it's used directly as a foreign key
- **`getCustomerToken`** filters by `expiresAt: { gt: new Date() }` — proper expiry check
- **CodeVerifier** is properly single-use (deleted after retrieval)
- **CustomerToken** expiry check exists but no token refresh mechanism for customer tokens

## 3. PKCE / Callback Analysis

### File: `app/auth.server.js`

### Authorization URL Generation (`generateAuthUrl`)
- State = `${conversationId}-${shopId}` — **hyphen-delimited**
  - `conversationId` comes from the chat route (timestamp string)
  - `shopId` comes from `X-Shopify-Shop-Id` header
  - **No HMAC signing** on state — vulnerable to tampering
- Code verifier generated with `crypto.getRandomValues(new UintArray(32))` — cryptographically secure
- PKCE: `code_challenge_method=S256` — proper
- Scope: `customer-account-mcp-api:full` — broad scope for MCP access

### Token Exchange (`exchangeCodeForToken` in `auth.callback.jsx`)
- Exchanges code for token at `token_endpoint` (from cached `.well-known/openid-configuration`)
- Sends `client_id`, `code`, `redirect_uri`, `code_verifier`
- `redirect_uri` comes from `process.env.REDIRECT_URL`
- Token stored with `expiresAt` computed from `expires_in`

### Callback Handling (`auth.callback.jsx` — loader)
- Parses `state` from URL: `const [conversationId, shopId] = state.split("-")`
- **BUG**: If `conversationId` contains a hyphen, the split will produce incorrect results
- Returns HTML that auto-closes the window (no redirect back to chat)

## 4. MCP Tools Exposed

### Configuration File: `.mcp.json` / `.cursor/mcp.json`
```json
{
  "mcpServers": {
    "shopify-dev-mcp": {
      "type": "stdio",
      "command": "npx",
      "args": ["-y", "@shopify/dev-mcp@latest"],
      "env": {
        "POLARIS_UNIFIED": "true",
        "LIQUID": "true"
      }
    }
  }
}
```

### MCP Client: `app/mcp-client.js`

Two MCP servers are connected:

1. **Storefront MCP** (`${hostUrl}/api/mcp`)
   - No authentication
   - Discovers tools via `tools/list` JSON-RPC call
   - Invokes tools via `tools/call` JSON-RPC call
   
2. **Customer MCP** (`${accountHostUrl}/customer/api/mcp`)
   - Authentication: Bearer token from `CustomerToken` database table
   - If 401 → generates auth URL for customer to authorize

### Tools (from README examples)
Based on README and `AppConfig.tools.productSearchName = "search_shop_catalog"`:
- `search_shop_catalog` — Product search
- `update_cart` — Cart management (add/remove/update)
- `get_cart` — Retrieve cart contents
- `search_shop_policies_and_faqs` — Policy/FAQ lookup
- `get_most_recent_order_status` — Recent order lookup
- `get_order_status` — Specific order by ID
- Checkout initiation (from cart tools)

**Note**: Tools are dynamically discovered — the actual tool list depends on what the MCP server exposes.

### MCP Client Security Observations
- `customerAccessToken` defaults to `""` and falls back to empty string
  ```js
  "Authorization": this.customerAccessToken || ""
  ```
  If no token exists, the Authorization header is an empty string — this may bypass authentication on some MCP servers
- Tool calls pass the `toolArgs` directly from Claude's output without validation — potential for injection if Claude is manipulated
- Error responses from MCP tools are returned to Claude, potentially leaking internal error details

## 5. Webhook Handler

### File: `app/routes/api.webhooks.jsx`
```js
export const action = async ({ request }) => {
  const { shop, session, topic } = await authenticate.webhook(request);
  switch (topic) {
    case 'APP_UNINSTALLED':
      if (session) {
        await db.session.deleteMany({where: {shop}});
      }
      break;
    default:
      throw new Response('Unhandled webhook topic', {status: 404});
  }
  return new Response();
};
```
- HMAC verification handled by Shopify SDK (`authenticate.webhook`)
- Only handles `APP_UNINSTALLED` — clean up sessions on uninstall
- All other topics return 404

## 6. Environment Configuration

### `.env.example`
```
CLAUDE_API_KEY=YOUR_CLAUDE_API_KEY
REDIRECT_URL=https://localhost:3458/auth/callback
SHOPIFY_API_KEY=YOUR_APP_CLIENT_ID
```

### Security Concern
- `SHOPIFY_API_SECRET` is used in `shopify.server.js` but NOT in `.env.example`
- The code defaults to empty string: `apiSecretKey: process.env.SHOPIFY_API_SECRET || ""`
- **If the secret is missing/empty, OAuth security is compromised**
