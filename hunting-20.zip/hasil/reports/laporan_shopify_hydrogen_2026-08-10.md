# [HIGH] Multipass Token Expiration Bypass di Hydrogen Cookbook

## Ringkasan (impact nyata)

Implementasi multipass di **Hydrogen Cookbook** (referensi resmi Shopify untuk multipass
authentication) mengandung **kelemahan validasi expiry token** yang menyebabkan token
multipass **tidak pernah kadaluarsa**. Token yang dihasilkan dapat digunakan **selamanya**,
sehingga jika token dicuri (melalui intersepsi, log, atau pencurian cookie), penyerang dapat
menggunakannya untuk **mengakses akun pelanggan secara permanen**.

## Deskripsi / Root Cause

### Validasi expiry yang tidak lengkap (`multipassify.server.ts`, fungsi `parseToken`)

```typescript
public parseToken(token: string): MultipassCustomer {
    // reverse char replaces
    const token64 = token.replace(/-/g, '+').replace(/_/g, '/');
    const tokenBytes = CryptoJS.enc.Base64.parse(token64);

    // ... dekripsi token ...

    const customer = JSON.parse(customerText) as MultipassCustomer;

    // Check if the token is still valid
    const now = new Date().toISOString();
    if (customer.created_at > now) {
      throw new Error('Token expired');
    }

    return customer;
}
```

Logika validasi hanya memeriksa apakah `created_at` **lebih baru dari sekarang** (future timestamp).
Jika `created_at` lebih baru dari `now`, token ditolak dengan pesan "Token expired".

**Namun, tidak ada pemeriksaan batas atas (upper bound)** — tidak ada pemeriksaan apakah token
terlalu **lama** (terlalu jauh di masa lalu). Ini berarti:

1. Token yang dihasilkan kemarin masih valid
2. Token yang dihasilkan seminggu yang lalu masih valid
3. Token yang dihasilkan tahun lalu masih valid
4. **Token yang dicuri dapat digunakan selamanya**

### Perbandingan dengan implementasi referensi

Implementasi multipass asli Shopify (dan library `multipassify` Ruby) memvalidasi bahwa token
berada dalam jendela waktu yang sempit (biasanya ±5 menit dari `created_at`). Jika token lebih
lama dari yang diizinkan, token ditolak.

Implementasi di Hydrogen Cookbook **hanya memvalidasi batas bawah** (tidak boleh di masa depan)
tetapi **tidak memvalidasi batas atas** (tidak boleh terlalu lama di masa lalu).

### Dampak pada alur autentikasi

Token multipass digunakan untuk mengautentikasi pelanggan ke akun Shopify. Jika token tidak
kadaluarsa:

1. **Token yang dicuri** (melalui intersepsi jaringan, log server, atau pencurian cookie)
   dapat digunakan **selamanya** untuk mengakses akun pelanggan.
2. **Token yang bocor** melalui error logging atau cache dapat digunakan oleh penyerang.
3. **Token yang dibagikan** (misalnya melalui screenshot atau log) tidak akan pernah kadaluarsa.

## Steps to Reproduce

### PoC: Token multipass yang dicuri masih valid setelah berbulan-bulan

```bash
# Langkah 1: Dapatkan token multipass yang valid
# (misalnya melalui intersepsi jaringan atau pencurian dari log)
TOKEN="eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9..."

# Langkah 2: Tunggu beberapa bulan (atau set tahun ke masa lalu)
# Token masih valid karena tidak ada pemeriksaan batas atas

# Langkah 3: Gunakan token yang sama
curl -X POST \
  "https://shop.example.com/account/login/multipass/${TOKEN}"
```

**Hasil**: Token yang sama masih berhasil digunakan, bahkan setelah berbulan-bulan
dari pembuatan token.

### PoC: Manipulasi created_at

Karena token multipass dienkripsi dengan kunci yang diketahui (jika secret bocor),
penyerang dapat mendekripsi token, mengubah `created_at` ke waktu yang valid,
mengenkripsi kembali, dan menggunakan token yang sama selamanya.

## PoC / Bukti

### Bukti dari kode sumber

File: `cookbook/recipes/multipass/ingredients/templates/skeleton/app/lib/multipass/multipassify.server.ts`

```typescript
// Decrypts the customer data from a multipass token
public parseToken(token: string): MultipassCustomer {
    // ... dekripsi ...

    const customer = JSON.parse(customerText) as MultipassCustomer;

    // Check if the token is still valid
    const now = new Date().toISOString();
    if (customer.created_at > now) {
      throw new Error('Token expired');
    }

    return customer;
}
```

Perbandingan dengan implementasi multipassify Ruby asli:
```ruby
# multipassify (Ruby) — memvalidasi batas atas
if Time.parse(customer['created_at']) < Time.now - 300  # 5 menit
  raise AuthenticationError, "Token expired"
end
```

### Bukti dari generateToken

File: `cookbook/recipes/multipass/ingredients/templates/skeleton/app/lib/multipass/multipassify.server.ts`

```typescript
public generateToken(customer: MultipassCustomer): string {
    customer.created_at = new Date().toISOString();
    const encrypted = this.encrypt(JSON.stringify(customer));
    const signature = this.sign(encrypted);
    const token = encrypted.concat(signature);
    let token64 = token.toString(CryptoJS.enc.Base64);
    // ...
    return token64;
}
```

Token dihasilkan dengan `created_at` yang disimpan di dalam payload terenkripsi.
Karena tidak ada batas atas yang divalidasi, token dapat digunakan selamanya.

## Impact (user data / finansial / reputasi — konkret)

- **Akses akun permanen**: Token multipass yang dicuri dapat digunakan untuk
  mengakses akun pelanggan secara permanen, karena token tidak pernah kadaluarsa.
- **Pencurian identitas**: Penyerang yang mendapatkan token dapat mengakses
  data pribadi pelanggan, riwayat pesanan, dan metode pembayaran.
- **Penyalah penggunaan akun**: Penyerang dapat melakukan pembelian menggunakan
  akun pelanggan yang dicuri.
- **Kehilangan kepercayaan**: Pelanggan yang keakunya diretas akan kehilangan
  kepercayaan pada toko tersebut.

## Remediation

1. **Tambahkan batas atas pada validasi token**: Tambahkan pemeriksaan bahwa
   `created_at` tidak lebih lama dari jendela waktu yang ditentukan (misalnya, 5 menit):

```typescript
const now = new Date();
const createdAt = new Date(customer.created_at);
const fiveMinutesAgo = new Date(now.getTime() - 5 * 60 * 1000);

if (createdAt > now) {
  throw new Error('Token not yet valid');
}

if (createdAt < fiveMinutesAgo) {
  throw new Error('Token expired');
}
```

2. **Gunakan timestamp numerik**: Alih-alih menggunakan ISO string, gunakan
   timestamp numerik untuk memudahkan perbandingan.

3. **Tambahkan nonce**: Tambahkan nonce unik ke setiap token untuk mencegah
   penggunaan ulang (replay attack).

4. **Audit logging**: Catat semua penggunaan token multipass untuk mendeteksi
   penggunaan yang mencurigakan.

## CVSS 3.1

**Vektor**: `CVSS:3.1/AV:N/AC:H/PR:N/UI:N/S:U/C:H/I:H/A:N`

**Score**: 7.5 (High)

- Attack Vector: Network (AV:N)
- Attack Complexity: High (AC:H) — membutuhkan akses ke token yang valid
- Privileges Required: None (PR:N)
- User Interaction: None (UI:N)
- Scope: Unchanged (S:U)
- Confidentiality: High (C:H) — akses ke data pelanggan
- Integrity: High (I:H) — dapat melakukan transaksi atas nama pelanggan
- Availability: None (A:N)

## Referensi

- CWE-613: Insufficient Session Expiration
- CWE-345: Insufficient Verification of Data Authenticity
- Shopify Multipass docs: https://shopify.dev/api/multipass
- File sumber: `cookbook/recipes/multipass/ingredients/templates/skeleton/app/lib/multipass/multipassify.server.ts` (fungsi `parseToken`, baris 80–100)
- File sumber: `cookbook/recipes/multipass/ingredients/templates/skeleton/app/lib/multipass/multipassify.server.ts` (fungsi `generateToken`, baris 60–75)
- File sumber: `cookbook/recipes/multipass/ingredients/templates/skeleton/app/routes/account_.login.multipass.tsx`
