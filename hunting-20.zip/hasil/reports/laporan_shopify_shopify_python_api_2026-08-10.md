# [MEDIUM] JWT Session Token Tanpa Validasi Expiry di shopify_python_api

## Ringkasan (impact nyata)

Library `shopify_python_api` — library resmi Shopify untuk mengakses Admin API dengan Python —
mengizinkan **JWT session token tanpa klaim `exp` (expiration)** untuk diterima dan diverifikasi.
Karena `exp` tidak termasuk dalam daftar klaim wajib (`REQUIRED_FIELDS`), token JWT yang tidak
memiliki klaim kedaluwarsa akan **diterima selamanya**, sehingga jika token dicuri, penyerang
dapat menggunakannya untuk **mengakses API Shopify secara permanen**.

## Deskripsi / Root Cause

### `exp` tidak termasuk dalam REQUIRED_FIELDS (`shopify/session_token.py`)

```python
ALGORITHM = "HS256"
PREFIX = "Bearer "
REQUIRED_FIELDS = ["iss", "dest", "sub", "jti", "sid"]
LEEWAY_SECONDS = 10

def _decode_session_token(session_token, api_key, secret):
    try:
        return jwt.decode(
            session_token,
            secret,
            audience=api_key,
            algorithms=[ALGORITHM],
            leeway=LEEWAY_SECONDS,
            options={"require": REQUIRED_FIELDS},
        )
    except jwt.exceptions.PyJWTError as exception:
        six.raise_from(SessionTokenError(str(exception)), exception)
```

`REQUIRED_FIELDS` hanya berisi `["iss", "dest", "sub", "jti", "sid"]` — **tidak termasuk `exp`**.
Dengan opsi `options={"require": REQUIRED_FIELDS}`, PyJWT hanya memaksa keberadaan klaim yang
tercantum. Karena `exp` tidak termasuk, token JWT **tanpa klaim `exp`** akan diterima.

### Dampaknya

PyJWT secara default **memvalidasi** klaim `exp` jika klaim tersebut **ada** dalam token.
Jika `exp` tidak ada, PyJWT tidak akan melakukan validasi kedaluwarsa. Ini berarti:

1. Token JWT tanpa `exp` akan **diterima selamanya**
2. Token JWT yang dicuri (atau yang dibuat jika secret bocir) tanpa `exp` tidak akan pernah kadaluarsa
3. Ini melanggar prinsip **defense in depth** — seharusnya `exp` selalu diperlukan

### Perbandingan dengan implementasi lain

Library Shopify API lainnya (Ruby, Node.js) **secara eksplisit memvalidasi** `exp`:
- Ruby `shopify_app`: memvalidasi `exp` dan `nbf`
- Node.js `shopify-api`: memvalidasi `exp` dengan `clockTimestampTolerance`

Python library ini **tidak memvalidasi** `exp` secara eksplisit, dan bahkan **tidak memaksa**
keberadaan `exp` dalam token.

### Timestamp future tidak divalidasi (`shopify/session.py`)

```python
@classmethod
def validate_params(cls, params):
    one_day = 24 * 60 * 60
    if int(params.get("timestamp", 0)) < time.time() - one_day:
        return False
    return cls.validate_hmac(params)
```

Pemeriksaan timestamp hanya memvalidasi bahwa timestamp **tidak terlalu lama di masa lalu**
(tidak lebih dari 1 hari). **Tidak ada pemeriksaan** bahwa timestamp **tidak di masa depan**.
Penyerang dapat menggunakan timestamp yang sangat besar (di masa depan) untuk melewati
pemeriksaan ini.

## Steps to Reproduce

### PoC 1: JWT tanpa exp diterima

```python
import jwt
import time
from shopify.session_token import decode_from_header

# Buat JWT tanpa klaim exp
secret = "known_secret"
api_key = "known_api_key"
payload = {
    "iss": "https://shop.myshopify.com",
    "dest": "https://shop.myshopify.com",
    "sub": "123456789",
    "jti": "unique-token-id",
    "sid": "session-id",
    # Perhatikan: tidak ada klaim "exp"
}

token = jwt.encode(payload, secret, algorithm="HS256", audience=api_key)

# Dekode token — akan berhasil meskipun tidak ada exp
decoded = decode_from_header(f"Bearer {token}", api_key, secret)
print(decoded)  # Berhasil, tidak ada error
```

### PoC 2: Timestamp future tidak ditolak

```python
from shopify.session import Session

# Timestamp di masa depan (10 tahun dari sekarang)
future_timestamp = int(time.time()) + 315360000  # 10 tahun

params = {
    "hmac": "valid_hmac",
    "timestamp": str(future_timestamp),
    "code": "auth_code",
    "shop": "shop.myshopify.com",
}

# validate_params akan mengembalikan True meskipun timestamp di masa depan
result = Session.validate_params(params)
print(result)  # True — seharusnya False
```

## PoC / Bukti

### Bukti dari kode sumber

File: `shopify/session_token.py`
```python
REQUIRED_FIELDS = ["iss", "dest", "sub", "jti", "sid"]
# ...
options={"require": REQUIRED_FIELDS},
```

`exp` tidak termasuk dalam `REQUIRED_FIELDS`.

File: `shopify/session.py`
```python
@classmethod
def validate_params(cls, params):
    one_day = 24 * 60 * 60
    if int(params.get("timestamp", 0)) < time.time() - one_day:
        return False
    return cls.validate_hmac(params)
```

Hanya memeriksa `timestamp < time.time() - one_day`. Tidak ada pemeriksaan
`timestamp > time.time() + leeway`.

## Impact (user data / finansial / reputasi — konkret)

- **Akses API permanen**: Token JWT tanpa `exp` dapat digunakan selamanya untuk
  mengakses Shopify Admin API, termasuk membuat perubahan pada produk, pesanan,
  dan data pelanggan.
- **Pencurian token**: Jika token dicuri (melalui log, intersepsi, atau pencurian
  memori), penyerang dapat menggunakannya tanpa batas waktu.
- **Replay attack**: Timestamp future yang tidak divalidasi memungkinkan penyerang
  untuk menggunakan kembali permintaan OAuth yang dicegat dengan timestamp
  yang dimanipulasi.

## Remediation

1. **Tambahkan `exp` ke REQUIRED_FIELDS**:
```python
REQUIRED_FIELDS = ["iss", "dest", "sub", "jti", "sid", "exp"]
```

2. **Validasi timestamp future**:
```python
@classmethod
def validate_params(cls, params):
    one_day = 24 * 60 * 60
    timestamp = int(params.get("timestamp", 0))
    if timestamp < time.time() - one_day:
        return False
    if timestamp > time.time() + 300:  # 5 menit toleransi
        return False
    return cls.validate_hmac(params)
```

3. **Gunakan `options={"require": ["exp"], "verify_exp": True}`** secara eksplisit
   untuk memastikan PyJWT memvalidasi klaim `exp`.

## CVSS 3.1

**Vektor**: `CVSS:3.1/AV:N/AC:H/PR:N/UI:N/S:U/C:H/I:N/A:N`

**Score**: 5.9 (Medium)

- Attack Vector: Network (AV:N)
- Attack Complexity: High (AC:H) — membutuhkan akses ke token yang valid
- Privileges Required: None (PR:N)
- User Interaction: None (UI:N)
- Scope: Unchanged (S:U)
- Confidentiality: High (C:H) — akses ke data Shopify
- Integrity: None (I:N)
- Availability: None (A:N)

## Referensi

- CWE-613: Insufficient Session Expiration
- CWE-287: Improper Authentication
- PyJWT docs: https://pyjwt.readthedocs.io/en/stable/
- File sumber: `shopify/session_token.py` (baris 10–15, 30–40)
- File sumber: `shopify/session.py` (baris 100–110, `validate_params`)
