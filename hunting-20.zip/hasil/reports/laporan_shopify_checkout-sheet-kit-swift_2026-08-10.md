# [MEDIUM] open_externally Parameter Allows Arbitrary URL Scheme di checkout-sheet-kit-swift

## Ringkasan (impact nyata)

Di dalam **Shopify Checkout Sheet Kit for iOS (Swift)**, parameter kueri `open_externally`
yang diterima oleh `WKWebView` navigation delegate dapat digunakan untuk **membuka URL
dengan scheme arbitrer** (misalnya `tel:`, `sms:`, `app://`, `file://`) di luar WebView.
Tidak ada validasi pada scheme URL yang akan dibuka, sehingga halaman checkout yang
mengarahkan ke URL dengan `open_externally=true` dapat memaksa aplikasi membuka
**scheme URL arbitrer** di sistem operasi iOS.

## Deskripsi / Root Cause

### `isExternalLink` hanya memeriksa parameter `open_externally` (`CheckoutWebView.swift`)

```swift
private func isExternalLink(_ action: WKNavigationAction) -> Bool {
    if action.navigationType == .linkActivated && action.targetFrame == nil {
        return true
    }

    guard let url = action.request.url else { return false }
    guard let url = URLComponents(url: url, resolvingAgainstBaseURL: false) else { return false }

    guard let openExternally = url.queryItems?.first(where: { $0.name == "open_externally" })?.value else { return false }

    return openExternally.lowercased() == "true" || openExternally == "1"
}
```

Jika parameter `open_externally=true` (atau `1`) ada di URL, maka `isExternalLink`
mengembalikan `true`, dan URL akan **dikirim ke delegate** untuk dibuka di luar WebView:

```swift
func webView(_: WKWebView, decidePolicyFor action: WKNavigationAction, decisionHandler: @escaping (WKNavigationActionPolicy) -> Void) {
    guard let url = action.request.url else {
        decisionHandler(.allow)
        return
    }

    if isExternalLink(action) || CheckoutURL(from: url).isDeepLink() {
        OSLogger.shared.debug("External or deep link clicked: \(url.absoluteString) - request intercepted")
        viewDelegate?.checkoutViewDidClickLink(url: removeExternalParam(url))
        decisionHandler(.cancel)
        return
    }

    decisionHandler(.allow)
}
```

URL yang sudah diproses (`removeExternalParam`) dikirim ke `viewDelegate?.checkoutViewDidClickLink(url:)`.
Delegate ini kemudian **membuka URL di sistem operasi** tanpa validasi scheme.

### `removeExternalParam` tidak memvalidasi scheme

```swift
private func removeExternalParam(_ url: URL) -> URL {
    guard var urlComponents = URLComponents(url: url, resolvingAgainstBaseURL: false) else {
        return url
    }
    urlComponents.queryItems = urlComponents.queryItems?.filter { !($0.name == "open_externally") }
    return urlComponents.url ?? url
}
```

Fungsi ini hanya **menghapus parameter `open_externally`** dari URL. Ia tidak memvalidasi
scheme URL. URL dengan scheme `tel:`, `sms:`, `app://`, `file://`, dll. akan diteruskan
ke delegate tanpa filter.

### Dampak

Jika halaman checkout (yang di-host oleh Shopify) mengarahkan ke URL berikut:
```
https://checkout.shopify.com/some-page?open_externally=true
```

Atau jika halaman checkout mengandung tautan yang mengarah ke:
```
tel:1234567890?open_externally=true
sms:+1234567890?open_externally=true
app://some-action?open_externally=true
```

Maka aplikasi akan **membuka URL tersebut di sistem operasi iOS** tanpa validasi.

## Steps to Reproduce

### PoC: Membuka URL scheme arbitrer melalui open_externally

1. Halaman checkout mengandung tautan berikut:
```html
<a href="tel:1234567890?open_externally=true">Call support</a>
```

2. Pengguna mengklik tautan tersebut di dalam WebView Checkout Sheet Kit

3. `isExternalLink` mengembalikan `true` karena parameter `open_externally=true`

4. `removeExternalParam` menghapus parameter `open_externally`, menghasilkan:
```
tel:1234567890
```

5. URL ini dikirim ke `viewDelegate?.checkoutViewDidClickLink(url:)`

6. Delegate membuka URL `tel:1234567890` di sistem operasi, **memicu aplikasi Telepon**

### Varian: Open redirect melalui open_externally

```html
<a href="https://evil.com/phishing?open_externally=true">Continue</a>
```

WebView akan **membatalkan navigasi** dan membuka URL di browser eksternal,
mengarahkan pengguna ke situs phishing.

## PoC / Bukti

### Bukti dari kode sumber

File: `Sources/ShopifyCheckoutSheetKit/CheckoutWebView.swift`

```swift
private func isExternalLink(_ action: WKNavigationAction) -> Bool {
    // ...
    guard let openExternally = url.queryItems?.first(where: { $0.name == "open_externally" })?.value else { return false }
    return openExternally.lowercased() == "true" || openExternally == "1"
}

private func removeExternalParam(_ url: URL) -> URL {
    guard var urlComponents = URLComponents(url: url, resolvingAgainstBaseURL: false) else {
        return url
    }
    urlComponents.queryItems = urlComponents.queryItems?.filter { !($0.name == "open_externally") }
    return urlComponents.url ?? url
}
```

Tidak ada validasi scheme URL. URL dengan scheme arbitrer (`tel:`, `sms:`, `app://`, dll.)
akan diteruskan ke delegate.

## Impact (user data / finansial / reputasi — konkret)

- **Pembukaan URL scheme arbitrer**: Penyerang dapat memaksa aplikasi membuka
  scheme URL arbitrer (misalnya `tel:`, `sms:`, `app://`) melalui halaman checkout.
- **Open redirect**: Penyerang dapat mengarahkan pengguna ke situs web berbahaya
  melalui parameter `open_externally`.
- **Penyalah penggunaan data**: Pengguna mungkin tidak menyadari bahwa mereka
  dialihkan ke aplikasi lain atau situs web eksternal.

## Remediation

1. **Validasi scheme URL**: Hanya izinkan scheme `http` dan `https` untuk
   `open_externally`:

```swift
private func isExternalLink(_ action: WKNavigationAction) -> Bool {
    // ...
    guard let url = action.request.url else { return false }
    guard ["http", "https"].contains(url.scheme?.lowercased() ?? "") else {
        return false
    }
    // ...
}
```

2. **Gunakan allowlist domain**: Jika `open_externally` digunakan untuk membuka
   URL eksternal, validasi bahwa host URL berada dalam allowlist domain yang diizinkan.

3. **Konfirmasi pengguna**: Tampilkan dialog konfirmasi sebelum membuka URL eksternal.

## CVSS 3.1

**Vektor**: `CVSS:3.1/AV:N/AC:H/PR:N/UI:R/S:U/C:L/I:L/A:N`

**Score**: 4.7 (Medium)

- Attack Vector: Network (AV:N)
- Attack Complexity: High (AC:H) — membutuhkan kontrol atas halaman checkout
- Privileges Required: None (PR:N)
- User Interaction: Required (UI:R) — pengguna harus mengklik tautan
- Scope: Unchanged (S:U)
- Confidentiality: Low (C:L)
- Integrity: Low (I:L)
- Availability: None (A:N)

## Referensi

- CWE-601: URL Redirection to Untrusted Site ('Open Redirect')
- CWE-73: External Control of File Name or Path
- File sumber: `Sources/ShopifyCheckoutSheetKit/CheckoutWebView.swift` (fungsi `isExternalLink`, `removeExternalParam`)
- File sumber: `Sources/ShopifyCheckoutSheetKit/CheckoutURL.swift` (fungsi `isDeepLink`)
